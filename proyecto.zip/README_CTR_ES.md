# CTR Video Player — edición Old 3DS

Esta es una personalización del proyecto Video Player for 3DS. El motor de reproducción y sus bibliotecas originales se conservan; los cambios de esta edición se centran en la identidad de la aplicación y en preparar una compilación reproducible.

## Compatibilidad y conversión recomendada

Para una Nintendo 3DS/2DS antigua, empieza con vídeos de **400×240**, vídeo **MPEG-4 Part 2** y audio **Vorbis** dentro de un archivo MKV. El rendimiento depende del vídeo, la tasa de bits y la carga del sistema; no se garantiza 30 FPS.

Ejemplo con FFmpeg:

```bash
ffmpeg -i "entrada.mp4" -c:v mpeg4 -q:v 8 -s 400x240 -c:a libvorbis "salida_3ds.mkv"
```

## Compilación

El proyecto incluye bibliotecas estáticas propias en `library/lib` y sus encabezados en `library/include`. Se necesita devkitARM/devkitPro para compilar el `.3dsx`.

El flujo de GitHub Actions genera el `.3dsx` y el `.smdh` como artefactos. La generación de `.cia` requiere además `makerom` y `bannertool`; no se debe confundir un CIA original incluido en `updater/` con una compilación de esta edición.

## Estado

- Identidad y metadatos de CTR Video Player personalizados.
- Icono personalizado.
- Bibliotecas multimedia incluidas en el proyecto.
- Compilación automática `.3dsx` configurada; pendiente de validación real en GitHub Actions y en consola.
- El decodificador no ha sido reescrito ni optimizado específicamente en esta personalización.
