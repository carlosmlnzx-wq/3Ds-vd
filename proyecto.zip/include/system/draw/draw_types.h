#if !defined(DEF_DRAW_TYPES_H)
#define DEF_DRAW_TYPES_H
#include <stdbool.h>
#include <stdint.h>
#include "citro2d.h"
#include "citro3d.h"
#include "system/util/log_enum_types.h"

#define DEF_DRAW_DMA_ENABLE					/*(bool)(*/true/*)*/	//Enable DMA in draw module for faster processing.
#define DEF_DRAW_MAX_NUM_OF_SPRITE_SHEETS	(uint32_t)(128)
#define DEF_DRAW_MIN_TEXTURE_SIZE			(uint16_t)(16)
#define DEF_DRAW_MAX_TEXTURE_SIZE			(uint16_t)(1024)

#define DEF_DRAW_RED						(uint32_t)(0xFF0000FF)
#define DEF_DRAW_MAROON						(uint32_t)(0xFF000080)
#define DEF_DRAW_BROWN						(uint32_t)(0xFF2A2AA5)
#define DEF_DRAW_PINK						(uint32_t)(0xFFCBC0FF)
#define DEF_DRAW_ORANGE						(uint32_t)(0xFF00A5FF)
#define DEF_DRAW_YELLOW						(uint32_t)(0xFF00FFFF)
#define DEF_DRAW_LIME						(uint32_t)(0xFF00FF00)
#define DEF_DRAW_GREEN						(uint32_t)(0xFF008000)
#define DEF_DRAW_OLIVE						(uint32_t)(0xFF008080)
#define DEF_DRAW_CYAN						(uint32_t)(0xFFFFFF00)
#define DEF_DRAW_AQUA						(uint32_t)(0xFFD4FF7F)
#define DEF_DRAW_LIGHT_BLUE					(uint32_t)(0xFFE6D8AD)
#define DEF_DRAW_BLUE						(uint32_t)(0xFFFF0000)
#define DEF_DRAW_DARK_BLUE					(uint32_t)(0xFF8B0000)
#define DEF_DRAW_PURPLE						(uint32_t)(0xFF800080)
#define DEF_DRAW_MAGENTA					(uint32_t)(0xFFFF00FF)
#define DEF_DRAW_BLACK						(uint32_t)(0xFF000000)
#define DEF_DRAW_WHITE						(uint32_t)(0xFFFFFFFF)
#define DEF_DRAW_GRAY						(uint32_t)(0xFF808080)
#define DEF_DRAW_SILVER						(uint32_t)(0xFFC0C0C0)
#define DEF_DRAW_WEAK_RED					(uint32_t)(0x500000FF)
#define DEF_DRAW_WEAK_MAROON				(uint32_t)(0x50000080)
#define DEF_DRAW_WEAK_BROWN					(uint32_t)(0x502A2AA5)
#define DEF_DRAW_WEAK_PINK					(uint32_t)(0x50CBC0FF)
#define DEF_DRAW_WEAK_ORANGE				(uint32_t)(0x5000A5FF)
#define DEF_DRAW_WEAK_YELLOW				(uint32_t)(0x5000FFFF)
#define DEF_DRAW_WEAK_LIME					(uint32_t)(0x5000FF00)
#define DEF_DRAW_WEAK_GREEN					(uint32_t)(0x50008000)
#define DEF_DRAW_WEAK_OLIVE					(uint32_t)(0x50008080)
#define DEF_DRAW_WEAK_CYAN					(uint32_t)(0x50FFFF00)
#define DEF_DRAW_WEAK_AQUA					(uint32_t)(0x50D4FF7F)
#define DEF_DRAW_WEAK_LIGHT_BLUE			(uint32_t)(0x50E6D8AD)
#define DEF_DRAW_WEAK_BLUE					(uint32_t)(0x50FF0000)
#define DEF_DRAW_WEAK_DARK_BLUE				(uint32_t)(0x508B0000)
#define DEF_DRAW_WEAK_PURPLE				(uint32_t)(0x50800080)
#define DEF_DRAW_WEAK_MAGENTA				(uint32_t)(0x50FF00FF)
#define DEF_DRAW_WEAK_BLACK					(uint32_t)(0x50000000)
#define DEF_DRAW_WEAK_WHITE					(uint32_t)(0x50FFFFFF)
#define DEF_DRAW_WEAK_GRAY					(uint32_t)(0x50808080)
#define DEF_DRAW_WEAK_SILVER				(uint32_t)(0x50C0C0C0)
#define DEF_DRAW_NO_COLOR					(uint32_t)(0x00000000)

#define DEF_DRAW_NORMAL_SCALE_AND_SPACE		1.0, 1.0, 0.04, 0.01
#define DEF_DRAW_NORMAL_SCALE_AND_COMPACT	1.0, 1.0, 0.00, -0.15

typedef enum
{
	DRAW_SCREEN_INVALID	= -1,

	DRAW_SCREEN_TOP_LEFT,	//Top screen for left eye.
	DRAW_SCREEN_BOTTOM,		//Bottom screen.
	DRAW_SCREEN_TOP_RIGHT,	//Top screen for right eye, this is used when 3D mode is enabled.

	DRAW_SCREEN_MAX,
} Draw_screen;

DEF_LOG_ENUM_DEBUG
(
	Draw_screen,
	DRAW_SCREEN_INVALID,
	DRAW_SCREEN_TOP_LEFT,
	DRAW_SCREEN_BOTTOM,
	DRAW_SCREEN_TOP_RIGHT,
	DRAW_SCREEN_MAX
)

typedef enum
{
	DRAW_X_ALIGN_INVALID = -1,

	DRAW_X_ALIGN_LEFT,		//Align text left (default).
	DRAW_X_ALIGN_CENTER,	//Align text center.
	DRAW_X_ALIGN_RIGHT,		//Align text right.

	DRAW_X_ALIGN_MAX,
} Draw_text_align_x;

DEF_LOG_ENUM_DEBUG
(
	Draw_text_align_x,
	DRAW_X_ALIGN_INVALID,
	DRAW_X_ALIGN_LEFT,
	DRAW_X_ALIGN_CENTER,
	DRAW_X_ALIGN_RIGHT,
	DRAW_X_ALIGN_MAX
)

typedef enum
{
	DRAW_Y_ALIGN_INVALID = -1,

	DRAW_Y_ALIGN_TOP,		//Align text top (default).
	DRAW_Y_ALIGN_CENTER,	//Align text center.
	DRAW_Y_ALIGN_BOTTOM,	//Align text bottom.

	DRAW_Y_ALIGN_MAX,
} Draw_text_align_y;

DEF_LOG_ENUM_DEBUG
(
	Draw_text_align_y,
	DRAW_Y_ALIGN_INVALID,
	DRAW_Y_ALIGN_TOP,
	DRAW_Y_ALIGN_CENTER,
	DRAW_Y_ALIGN_BOTTOM,
	DRAW_Y_ALIGN_MAX
)

typedef enum
{
	DRAW_BACKGROUND_INVALID = -1,

	DRAW_BACKGROUND_NONE,				//No background texture (default).
	DRAW_BACKGROUND_ENTIRE_BOX,			//Draw background texture in entire box (allow text overflow).
	DRAW_BACKGROUND_UNDER_TEXT,			//Only draw background texture under text.
	DRAW_BACKGROUND_ENTIRE_BOX_CROP,	//Draw background texture in entire box and crop text outside of it (disallow text overflow).

	DRAW_BACKGROUND_MAX,
} Draw_background;

DEF_LOG_ENUM_DEBUG
(
	Draw_background,
	DRAW_BACKGROUND_INVALID,
	DRAW_BACKGROUND_NONE,
	DRAW_BACKGROUND_ENTIRE_BOX,
	DRAW_BACKGROUND_UNDER_TEXT,
	DRAW_BACKGROUND_ENTIRE_BOX_CROP,
	DRAW_BACKGROUND_MAX
)

typedef enum
{
	DRAW_VISIBILITY_INVALID = -1,

	DRAW_VISIBILITY_INVISIBLE,				//Element is invisible.
	DRAW_VISIBILITY_PARTIALLY_VISIBLE,		//Element is partially visible (therefore partially invisible).
	DRAW_VISIBILITY_FULLY_VISIBLE,			//Element is fully visible.

	DRAW_VISIBILITY_MAX,
} Draw_visibility;

typedef struct
{
	C2D_Image c2d;				//Texture data.
	Tex3DS_SubTexture* subtex;	//Subtexture data.
	bool selected;				//Whether this texture is selected.
	double x;					//X (horizontal) position.
	double y;					//Y (vertical) position.
	double x_size;				//Texture drawn width.
	double y_size;				//Texture drawn height.
} Draw_image_data;

typedef struct
{
	uint32_t image_width;		//Image width.
	uint32_t image_height;		//Image height.
	uint16_t num_of_images;		//Number of textures.
	Draw_image_data* images;	//Textures.
} Draw_large_image_data;

#endif //!defined(DEF_DRAW_TYPES_H)
