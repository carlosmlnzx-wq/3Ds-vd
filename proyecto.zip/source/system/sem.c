//Includes.
#include "system/sem.h"

#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#include "3ds.h"

#include "system/menu.h"
#include "system/draw/draw.h"
#include "system/draw/exfont.h"
#include "system/util/converter.h"
#include "system/util/cpu_usage.h"
#include "system/util/curl.h"
#include "system/util/encoder.h"
#include "system/util/err.h"
#include "system/util/file.h"
#include "system/util/gpu_usage.h"
#include "system/util/hid.h"
#include "system/util/httpc.h"
#include "system/util/hw_config.h"
#include "system/util/log.h"
#include "system/util/net_usage.h"
#include "system/util/nvs_usage.h"
#include "system/util/ram_usage.h"
#include "system/util/str.h"
#include "system/util/sync.h"
#include "system/util/thread_types.h"
#include "system/util/util.h"
#include "system/util/watch.h"
#include "ftp_daemon.h"
#include "video_player.h"

//Defines.
#define CHECK_INTERNET_URL					/*(const char*)(*/"http://network-test.debian.org/nm"/*)*/
#define CHECK_INTERNET_SUCCESS_TEXT			(const char*)("NetworkManager is online")
#define CHECK_INTERNET_INTERVAL_MS			(uint64_t)(10000)

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
#define UPDATE_FILE_PREFIX					/*(const char*)(*/"Vid_"/*)*/
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#define UPDATE_FLASH_INTERVAL_MS			(uint64_t)(50)		//Interval for flash mode update.
#define UPDATE_SYSTEM_INFO_INTERVAL_MS		(uint64_t)(250)		//Interval for system info update.
#define UPDATE_DRAW_INTERVAL_MS				(uint64_t)(1000)	//Interval for draw update (to update time on screen).

#define BATTERY_ESTIMATE_MIN_DIFF			(double)(0.25)		//Minimum battery level difference to perform remaining time estimation.

//System UI.
#define HID_SYSTEM_UI_SEL(k)				(bool)((DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN((*Draw_get_bot_ui_button()), (k))) || DEF_HID_PHY_PR((k).start))
#define HID_SYSTEM_UI_CFM(k)				(bool)(((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN((*Draw_get_bot_ui_button()), (k))) || (DEF_HID_PR_EM((k).start, 1) || DEF_HID_HD((k).start)))
#define HID_SYSTEM_UI_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch) && DEF_HID_PHY_NP((k).start))
//Sub menu selection.
#define HID_SUB_MENU_SEL(k, id)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_menu_button[id], (k)))
#define HID_SUB_MENU_CFM(k, id)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_menu_button[id], (k)))
#define HID_SUB_MENU_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Back to sub menu selection.
#define HID_BACK_SEL(k)						(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_back_button, (k)))
#define HID_BACK_CFM(k)						(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_back_button, (k)))
#define HID_BACK_DESEL(k)					(bool)(DEF_HID_PHY_NP((k).touch))
//Scroll mode.
#define HID_SCROLL_MODE_SEL(k)				(bool)(DEF_HID_PHY_HE((k).touch) && ((abs((k).touch_x_initial - (k).touch_x) > 6) || (abs((k).touch_y_initial - (k).touch_y) > 6)) && !HID_SCROLL_MODE_DESEL((k)))
#define HID_SCROLL_MODE_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch) || sem_screen_brightness_bar.selected || sem_screen_off_time_bar.selected || sem_sleep_time_bar.selected || sem_scroll_speed_bar.selected || sem_scroll_bar.selected)
//Scroll bar.
#define HID_SCROLL_BAR_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_scroll_bar, (k)))
#define HID_SCROLL_BAR_CFM(k)				(bool)(HID_SCROLL_BAR_SEL((k)) || (DEF_HID_PHY_HE((k).touch) && sem_scroll_bar.selected))
#define HID_SCROLL_BAR_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
//Updater: Edition list (.3dsx and .cia).
#define HID_UPDATE_3DSX_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_3dsx_button, (k)))
#define HID_UPDATE_3DSX_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_3dsx_button, (k)))
#define HID_UPDATE_3DSX_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
#define HID_UPDATE_CIA_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_cia_button, (k)))
#define HID_UPDATE_CIA_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_cia_button, (k)))
#define HID_UPDATE_CIA_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Updater: Download and install an update.
#define HID_UPDATE_DL_INSTALL_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_dl_install_button, (k)))
#define HID_UPDATE_DL_INSTALL_CFM(k)		(bool)(((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_dl_install_button, (k))) || (DEF_HID_PR_EM((k).x, 1) || DEF_HID_HD((k).x)))
#define HID_UPDATE_DL_INSTALL_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch) && DEF_HID_PHY_NP((k).x))
//Updater: Close app to apply.
#define HID_UPDATE_CLOSE_APP_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_close_app_button, (k)))
#define HID_UPDATE_CLOSE_APP_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_close_app_button, (k)))
#define HID_UPDATE_CLOSE_APP_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
//Language: English.
#define HID_LANG_EN_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_english_button, (k)))
#define HID_LANG_EN_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_english_button, (k)))
#define HID_LANG_EN_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Japanese.
#define HID_LANG_JP_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_japanese_button, (k)))
#define HID_LANG_JP_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_japanese_button, (k)))
#define HID_LANG_JP_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Hungarian.
#define HID_LANG_HU_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_hungarian_button, (k)))
#define HID_LANG_HU_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_hungarian_button, (k)))
#define HID_LANG_HU_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Simplified Chinese.
#define HID_LANG_ZHS_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_chinese_button, (k)))
#define HID_LANG_ZHS_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_chinese_button, (k)))
#define HID_LANG_ZHS_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Italian.
#define HID_LANG_IT_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_italian_button, (k)))
#define HID_LANG_IT_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_italian_button, (k)))
#define HID_LANG_IT_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Spanish.
#define HID_LANG_ES_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_spanish_button, (k)))
#define HID_LANG_ES_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_spanish_button, (k)))
#define HID_LANG_ES_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Romanian.
#define HID_LANG_RO_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_romanian_button, (k)))
#define HID_LANG_RO_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_romanian_button, (k)))
#define HID_LANG_RO_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Polish.
#define HID_LANG_PO_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_polish_button, (k)))
#define HID_LANG_PO_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_polish_button, (k)))
#define HID_LANG_PO_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: Ryukyuan.
#define HID_LANG_RYU_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_ryukyuan_button, (k)))
#define HID_LANG_RYU_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_ryukyuan_button, (k)))
#define HID_LANG_RYU_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Language: German.
#define HID_LANG_DE_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_german_button, (k)))
#define HID_LANG_DE_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_german_button, (k)))
#define HID_LANG_DE_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Night mode on.
#define HID_LCD_NIGHT_ON_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_night_mode_on_button, (k)))
#define HID_LCD_NIGHT_ON_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_night_mode_on_button, (k)))
#define HID_LCD_NIGHT_ON_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Night mode off.
#define HID_LCD_NIGHT_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_night_mode_off_button, (k)))
#define HID_LCD_NIGHT_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_night_mode_off_button, (k)))
#define HID_LCD_NIGHT_OFF_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Flash mode.
#define HID_LCD_FLASH_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_flash_mode_button, (k)))
#define HID_LCD_FLASH_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_flash_mode_button, (k)))
#define HID_LCD_FLASH_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Brightness level bar.
#define HID_LCD_BRIGHTNESS_BAR_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && (DEF_HID_INIT_IN(sem_screen_brightness_bar, (k)) || DEF_HID_INIT_IN(sem_screen_brightness_slider, (k))))
#define HID_LCD_BRIGHTNESS_BAR_CFM(k)		(bool)(HID_LCD_BRIGHTNESS_BAR_SEL((k)) || (DEF_HID_PHY_HE((k).touch) && sem_screen_brightness_bar.selected))
#define HID_LCD_BRIGHTNESS_BAR_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Turn off LCD time bar.
#define HID_LCD_LCD_OFF_BAR_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && (DEF_HID_INIT_IN(sem_screen_off_time_bar, (k)) || DEF_HID_INIT_IN(sem_screen_off_time_slider, (k))))
#define HID_LCD_LCD_OFF_BAR_CFM(k)			(bool)(HID_LCD_LCD_OFF_BAR_SEL((k)) || (DEF_HID_PHY_HE((k).touch) && sem_screen_off_time_bar.selected))
#define HID_LCD_LCD_OFF_BAR_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Sleep time bar.
#define HID_LCD_SLEEP_BAR_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && (DEF_HID_INIT_IN(sem_sleep_time_bar, (k)) || DEF_HID_INIT_IN(sem_sleep_time_slider, (k))))
#define HID_LCD_SLEEP_BAR_CFM(k)			(bool)(HID_LCD_SLEEP_BAR_SEL((k)) || (DEF_HID_PHY_HE((k).touch) && sem_sleep_time_bar.selected))
#define HID_LCD_SLEEP_BAR_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: 800px mode.
#define HID_LCD_800PX_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_800px_mode_button, (k)))
#define HID_LCD_800PX_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_800px_mode_button, (k)))
#define HID_LCD_800PX_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: 3D mode.
#define HID_LCD_3D_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_3d_mode_button, (k)))
#define HID_LCD_3D_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_3d_mode_button, (k)))
#define HID_LCD_3D_DESEL(k)					(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: 400px mode.
#define HID_LCD_400PX_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_400px_mode_button, (k)))
#define HID_LCD_400PX_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_400px_mode_button, (k)))
#define HID_LCD_400PX_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//LCD: Auto mode.
#define HID_LCD_AUTO_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_auto_mode_button, (k)))
#define HID_LCD_AUTO_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_auto_mode_button, (k)))
#define HID_LCD_AUTO_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Control: Scroll speed bar.
#define HID_CTRL_SCROLL_SPEED_BAR_SEL(k)	(bool)(DEF_HID_PHY_PR((k).touch) && (DEF_HID_INIT_IN(sem_scroll_speed_bar, (k)) || DEF_HID_INIT_IN(sem_scroll_speed_slider, (k))))
#define HID_CTRL_SCROLL_SPEED_BAR_CFM(k)	(bool)(HID_CTRL_SCROLL_SPEED_BAR_SEL((k)) || (DEF_HID_PHY_HE((k).touch) && sem_scroll_speed_bar.selected))
#define HID_CTRL_SCROLL_SPEED_BAR_DESEL(k)	(bool)(DEF_HID_PHY_NP((k).touch))
//Font: Font loading (all fonts).
#define HID_FONT_LOAD_ALL_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_load_all_ex_font_button, (k)))
#define HID_FONT_LOAD_ALL_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_load_all_ex_font_button, (k)))
#define HID_FONT_LOAD_ALL_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
//Font: Font unloading (all fonts except basic latin).
#define HID_FONT_UNLOAD_ALL_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_unload_all_ex_font_button, (k)))
#define HID_FONT_UNLOAD_ALL_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_unload_all_ex_font_button, (k)))
#define HID_FONT_UNLOAD_ALL_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Font: Loading or unloading (selected font).
#define HID_FONT_LOAD_UNLOAD_SEL(k, id)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_ex_font_button[id], (k)))
#define HID_FONT_LOAD_UNLOAD_CFM(k, id)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_ex_font_button[id], (k)))
#define HID_FONT_LOAD_UNLOAD_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Wireless: Wi-Fi on.
#define HID_WIRELESS_WIFI_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_wifi_on_button, (k)))
#define HID_WIRELESS_WIFI_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_wifi_on_button, (k)))
#define HID_WIRELESS_WIFI_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Wireless: Wi-Fi off.
#define HID_WIRELESS_WIFI_OFF_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_wifi_off_button, (k)))
#define HID_WIRELESS_WIFI_OFF_CFM(k)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_wifi_off_button, (k)))
#define HID_WIRELESS_WIFI_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Sending app info on.
#define HID_ADVANCED_SEND_INFO_ON_SEL(k)	(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_allow_send_info_button, (k)))
#define HID_ADVANCED_SEND_INFO_ON_CFM(k)	(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_allow_send_info_button, (k)))
#define HID_ADVANCED_SEND_INFO_ON_DESEL(k)	(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Sending app info off.
#define HID_ADVANCED_SEND_INFO_OFF_SEL(k)	(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_deny_send_info_button, (k)))
#define HID_ADVANCED_SEND_INFO_OFF_CFM(k)	(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_deny_send_info_button, (k)))
#define HID_ADVANCED_SEND_INFO_OFF_DESEL(k)	(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Debug on.
#define HID_ADVANCED_DEBUG_ON_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_debug_mode_on_button, (k)))
#define HID_ADVANCED_DEBUG_ON_CFM(k)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_debug_mode_on_button, (k)))
#define HID_ADVANCED_DEBUG_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Debug off.
#define HID_ADVANCED_DEBUG_OFF_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_debug_mode_off_button, (k)))
#define HID_ADVANCED_DEBUG_OFF_CFM(k)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_debug_mode_off_button, (k)))
#define HID_ADVANCED_DEBUG_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Fake model.
#define HID_ADVANCED_FAKE_MODEL_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_use_fake_model_button, (k)))
#define HID_ADVANCED_FAKE_MODEL_CFM(k)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_use_fake_model_button, (k)))
#define HID_ADVANCED_FAKE_MODEL_DESEL(k)	(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: Log dump.
#define HID_ADVANCED_LOG_DUMP_SEL(k)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_dump_log_button, (k)))
#define HID_ADVANCED_LOG_DUMP_CFM(k)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_dump_log_button, (k)))
#define HID_ADVANCED_LOG_DUMP_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#if DEF_CPU_USAGE_API_ENABLE
//Advanced: CPU monitor on.
#define HID_ADVANCED_CPU_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_cpu_usage_on_button, (k)))
#define HID_ADVANCED_CPU_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_cpu_usage_on_button, (k)))
#define HID_ADVANCED_CPU_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: CPU monitor off.
#define HID_ADVANCED_CPU_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_cpu_usage_off_button, (k)))
#define HID_ADVANCED_CPU_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_cpu_usage_off_button, (k)))
#define HID_ADVANCED_CPU_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //DEF_CPU_USAGE_API_ENABLE
#if DEF_GPU_USAGE_API_ENABLE
//Advanced: GPU monitor on.
#define HID_ADVANCED_GPU_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_gpu_usage_on_button, (k)))
#define HID_ADVANCED_GPU_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_gpu_usage_on_button, (k)))
#define HID_ADVANCED_GPU_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: GPU monitor off.
#define HID_ADVANCED_GPU_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_gpu_usage_off_button, (k)))
#define HID_ADVANCED_GPU_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_gpu_usage_off_button, (k)))
#define HID_ADVANCED_GPU_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //DEF_GPU_USAGE_API_ENABLE
#if DEF_NET_USAGE_API_ENABLE
//Advanced: NET monitor on.
#define HID_ADVANCED_NET_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_net_usage_on_button, (k)))
#define HID_ADVANCED_NET_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_net_usage_on_button, (k)))
#define HID_ADVANCED_NET_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: NET monitor off.
#define HID_ADVANCED_NET_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_net_usage_off_button, (k)))
#define HID_ADVANCED_NET_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_net_usage_off_button, (k)))
#define HID_ADVANCED_NET_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //DEF_NET_USAGE_API_ENABLE
#if DEF_NVS_USAGE_API_ENABLE
//Advanced: NVS monitor on.
#define HID_ADVANCED_NVS_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_nvs_usage_on_button, (k)))
#define HID_ADVANCED_NVS_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_nvs_usage_on_button, (k)))
#define HID_ADVANCED_NVS_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: NVS monitor off.
#define HID_ADVANCED_NVS_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_nvs_usage_off_button, (k)))
#define HID_ADVANCED_NVS_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_nvs_usage_off_button, (k)))
#define HID_ADVANCED_NVS_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //DEF_NVS_USAGE_API_ENABLE
#if DEF_RAM_USAGE_API_ENABLE
//Advanced: RAM monitor on.
#define HID_ADVANCED_RAM_ON_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_ram_usage_on_button, (k)))
#define HID_ADVANCED_RAM_ON_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_ram_usage_on_button, (k)))
#define HID_ADVANCED_RAM_ON_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
//Advanced: RAM monitor off.
#define HID_ADVANCED_RAM_OFF_SEL(k)			(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_monitor_ram_usage_off_button, (k)))
#define HID_ADVANCED_RAM_OFF_CFM(k)			(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_monitor_ram_usage_off_button, (k)))
#define HID_ADVANCED_RAM_OFF_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))
#endif //DEF_RAM_USAGE_API_ENABLE
//Battery: Eco on.
#define HID_BAT_ECO_ON_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_eco_mode_on_button, (k)))
#define HID_BAT_ECO_ON_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_eco_mode_on_button, (k)))
#define HID_BAT_ECO_ON_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Battery: Eco off.
#define HID_BAT_ECO_OFF_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_eco_mode_off_button, (k)))
#define HID_BAT_ECO_OFF_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_eco_mode_off_button, (k)))
#define HID_BAT_ECO_OFF_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
//Screen recording: Both LCDs.
#define HID_REC_BOTH_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_record_both_lcd_button, (k)))
#define HID_REC_BOTH_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_record_both_lcd_button, (k)))
#define HID_REC_BOTH_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Screen recording: Top LCD.
#define HID_REC_TOP_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_record_top_lcd_button, (k)))
#define HID_REC_TOP_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_record_top_lcd_button, (k)))
#define HID_REC_TOP_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
//Screen recording: Bottom LCD.
#define HID_REC_BOT_SEL(k)					(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN(sem_record_bottom_lcd_button, (k)))
#define HID_REC_BOT_CFM(k)					(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN(sem_record_bottom_lcd_button, (k)))
#define HID_REC_BOT_DESEL(k)				(bool)(DEF_HID_PHY_NP((k).touch))
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
//License: Full license (app).
#define HID_LICENSE_FULL_SEL(k)				(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN((*sem_license_this_app.button), (k)))
#define HID_LICENSE_FULL_CFM(k)				(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN((*sem_license_this_app.button), (k)))
#define HID_LICENSE_FULL_DESEL(k)			(bool)(DEF_HID_PHY_NP((k).touch))
//License: Full license (lib).
#define HID_LICENSE_LIB_FULL_SEL(k, id)		(bool)(DEF_HID_PHY_PR((k).touch) && DEF_HID_INIT_IN((*sem_licenses[id].button), (k)))
#define HID_LICENSE_LIB_FULL_CFM(k, id)		(bool)((DEF_HID_PR_EM((k).touch, 1) || DEF_HID_HD((k).touch)) && DEF_HID_INIT_LAST_IN((*sem_licenses[id].button), (k)))
#define HID_LICENSE_LIB_FULL_DESEL(k)		(bool)(DEF_HID_PHY_NP((k).touch))

#define SCROLL_BAR_Y_END					(double)(225)	//Y end offset for scroll bar in px.
#define SCROLL_BAR_X						(double)(312.5)	//X offset for scroll bar in px.
#define SCROLL_BAR_Y						(double)(0)		//Y offset for scroll bar in px.
#define SCROLL_BAR_WIDTH					(double)(7.5)	//Element width for scroll bar in px.
#define SCROLL_BAR_HEIGHT					(double)(40)	//Element height for scroll bar in px.

#define SUB_MENU_X_START					(double)(0)		//X start offset for sub menu in px.
#define SUB_MENU_Y_START					(double)(0)		//Y start offset for sub menu in px.
#define SUB_MENU_X_END						(double)(320)	//X end offset for sub menu in px.
#define SUB_MENU_Y_END						(double)(225)	//Y end offset for sub menu in px.
#define SUB_MENU_X							(double)(10)	//X offset for sub menu in px.
#define SUB_MENU_Y							(double)(0)		//Y offset for sub menu in px.
#define SUB_MENU_SPACE_Y					(double)(5)		//Element spacing for sub menu (for Y direction) in px.
#define SUB_MENU_WIDTH						(double)(300)	//Element width for sub menu in px.
#define SUB_MENU_HEIGHT						(double)(20)	//Element height for sub menu in px.

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
#define UPDATER_X_START						(double)(0)		//X start offset for updater in px.
#define UPDATER_Y_START						(double)(0)		//Y start offset for updater in px.
#define UPDATER_X_END						(double)(320)	//X end offset for updater in px.
#define UPDATER_Y_END						(double)(225)	//Y end offset for updater in px.
#define UPDATER_X							(double)(10)	//X offset for updater in px.
#define UPDATER_Y							(double)(30)	//Y offset for updater in px.
#define UPDATER_SPACE_Y						(double)(5)		//Element spacing for updater (for Y direction) in px.
	#define UPDATER_STATUS_WIDTH				(double)(300)	//Element width for status in px.
	#define UPDATER_STATUS_HEIGHT				(double)(15)	//Element height for status in px.
	#define UPDATER_STATUS_SUCCESS_HEIGHT		(double)(30)	//Element height for status (when update successfully finished) in px.
	#define UPDATER_CLOSE_WIDTH					(double)(300)	//Element width for close button in px.
	#define UPDATER_CLOSE_HEIGHT				(double)(15)	//Element height for close button in px.
	#define UPDATER_EDITION_SPACE_X				(double)(20)	//Element spacing for edition button (for X direction) in px.
	#define UPDATER_EDITION_WIDTH				(double)(140)	//Element width for edition button in px.
	#define UPDATER_EDITION_HEIGHT				(double)(15)	//Element height for edition button in px.
	#define UPDATER_3DSX_PATH_WIDTH				(double)(300)	//Element width for 3dsx install path in px.
	#define UPDATER_3DSX_PATH_HEIGHT			(double)(20)	//Element height for 3dsx install path in px.
	#define UPDATER_INSTALL_WIDTH				(double)(300)	//Element width for install button in px.
	#define UPDATER_INSTALL_HEIGHT				(double)(20)	//Element height for install button in px.
	#define UPDATER_PATCH_NOTE_WIDTH			(double)(300)	//Element width for patch note in px.
	#define UPDATER_PATCH_NOTE_HEIGHT			(double)(190)	//Element height for patch note in px.
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#define LANG_X_START						(double)(0)		//X start offset for lang in px.
#define LANG_Y_START						(double)(0)		//Y start offset for lang in px.
#define LANG_X_END							(double)(320)	//X end offset for lang in px.
#define LANG_Y_END							(double)(225)	//Y end offset for lang in px.
#define LANG_X								(double)(10)	//X offset for lang in px.
#define LANG_Y								(double)(30)	//Y offset for lang in px.
#define LANG_SPACE_Y						(double)(5)		//Element spacing for lang (for Y direction) in px.
#define LANG_WIDTH							(double)(300)	//Element width for lang in px.
#define LANG_HEIGHT							(double)(20)	//Element height for lang in px.

#define LCD_X_START							(double)(0)		//X start offset for LCD in px.
#define LCD_Y_START							(double)(0)		//Y start offset for LCD in px.
#define LCD_X_END							(double)(320)	//X end offset for LCD in px.
#define LCD_Y_END							(double)(225)	//Y end offset for LCD in px.
#define LCD_X								(double)(10)	//X offset for LCD in px.
#define LCD_Y								(double)(30)	//Y offset for LCD in px.
#define LCD_SPACE_Y							(double)(5)		//Element spacing for LCD (for Y direction) in px.

#define CONTROL_X_START						(double)(0)		//X start offset for control in px.
#define CONTROL_Y_START						(double)(0)		//Y start offset for control in px.
#define CONTROL_X_END						(double)(320)	//X end offset for control in px.
#define CONTROL_Y_END						(double)(225)	//Y end offset for control in px.
#define CONTROL_X							(double)(10)	//X offset for control in px.
#define CONTROL_Y							(double)(30)	//Y offset for control in px.
#define CONTROL_SPACE_Y						(double)(5)		//Element spacing for control (for Y direction) in px.

#define FONT_X_START						(double)(0)		//X start offset for font in px.
#define FONT_Y_START						(double)(0)		//Y start offset for font in px.
#define FONT_X_END							(double)(320)	//X end offset for font in px.
#define FONT_Y_END							(double)(225)	//Y end offset for font in px.
#define FONT_X								(double)(10)	//X offset for font in px.
#define FONT_Y								(double)(30)	//Y offset for font in px.
#define FONT_SPACE_Y						(double)(0)		//Element spacing for font (for Y direction) in px.
#define FONT_WIDTH							(double)(300)	//Element width for font in px.
#define FONT_HEIGHT							(double)(20)	//Element height for font in px.

#define WIFI_X_START						(double)(0)		//X start offset for Wi-Fi in px.
#define WIFI_Y_START						(double)(0)		//Y start offset for Wi-Fi in px.
#define WIFI_X_END							(double)(320)	//X end offset for Wi-Fi in px.
#define WIFI_Y_END							(double)(225)	//Y end offset for Wi-Fi in px.
#define WIFI_X								(double)(10)	//X offset for Wi-Fi in px.
#define WIFI_Y								(double)(30)	//Y offset for Wi-Fi in px.
#define WIFI_SPACE_Y						(double)(5)		//Element spacing for Wi-Fi (for Y direction) in px.

#define ADVANCED_X_START					(double)(0)		//X start offset for advanced in px.
#define ADVANCED_Y_START					(double)(0)		//Y start offset for advanced in px.
#define ADVANCED_X_END						(double)(320)	//X end offset for advanced in px.
#define ADVANCED_Y_END						(double)(225)	//Y end offset for advanced in px.
#define ADVANCED_X							(double)(10)	//X offset for advanced in px.
#define ADVANCED_Y							(double)(30)	//Y offset for advanced in px.
#define ADVANCED_SPACE_Y					(double)(5)		//Element spacing for advanced (for Y direction) in px.
	#define ADVANCED_FAKE_MODEL_SPACE_Y		(double)(20)	//Element spacing for fake model (for Y direction) in px.

#define BATTERY_X_START						(double)(0)		//X start offset for battery in px.
#define BATTERY_Y_START						(double)(0)		//Y start offset for battery in px.
#define BATTERY_X_END						(double)(320)	//X end offset for battery in px.
#define BATTERY_Y_END						(double)(225)	//Y end offset for battery in px.
#define BATTERY_X							(double)(10)	//X offset for battery in px.
#define BATTERY_Y							(double)(30)	//Y offset for battery in px.
#define BATTERY_SPACE_Y						(double)(5)		//Element spacing for battery (for Y direction) in px.

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
#define RECORDING_X_START					(double)(0)		//X start offset for recording in px.
#define RECORDING_Y_START					(double)(0)		//Y start offset for recording in px.
#define RECORDING_X_END						(double)(320)	//X end offset for recording in px.
#define RECORDING_Y_END						(double)(225)	//Y end offset for recording in px.
#define RECORDING_X							(double)(10)	//X offset for recording in px.
#define RECORDING_Y							(double)(30)	//Y offset for recording in px.
#define RECORDING_SPACE_Y					(double)(5)		//Element spacing for recording (for Y direction) in px.
	// #define RECORDING_UNAVAILABLE_WIDTH		(double)(300)	//Element width for unavailable notice in px.
	#define RECORDING_UNAVAILABLE_HEIGHT	(double)(45)	//Element height for unavailable notice in px.
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

#define LICENSE_X_START						(double)(0)		//X start offset for license in px.
#define LICENSE_Y_START						(double)(0)		//Y start offset for license in px.
#define LICENSE_X_END						(double)(320)	//X end offset for license in px.
#define LICENSE_Y_END						(double)(225)	//Y end offset for license in px.
#define LICENSE_X							(double)(10)	//X offset for license in px.
#define LICENSE_Y							(double)(30)	//Y offset for license in px.
#define LICENSE_SPACE_Y						(double)(5)		//Element spacing for license (for Y direction) in px.
#define LICENSE_WIDTH						(double)(300)	//Element width for lang in px.
#define LICENSE_HEIGHT						(double)(15)	//Element height for lang in px.
	#define LICENSE_SUB_APP_SPACE_X			(double)(5)		//Element spacing for sub app name (for X direction) in px.

#define SUB_TITLE_WIDTH						(double)(300)	//Element width for sub title in px.
#define SUB_TITLE_HEIGHT					(double)(10)	//Element height for sub title in px.

#define SELECT_HEIGHT						(double)(20)	//Element height for select button in px.
#define SELECT_1_WIDTH						(double)(300)	//Element width for select button 1 in px.
#define SELECT_2_WIDTH						(double)(140)	//Element width for select button 2 in px.
#define SELECT_2_SPACE_X					(double)(20)	//Element spacing for select button 2 (for X direction) in px.
#define SELECT_4_WIDTH						(double)(70)	//Element width for select button 4 in px.
#define SELECT_4_SPACE_X					(double)(6.7)	//Element spacing for select button 4 (for X direction) in px.

#define SLIDER_BAR_WIDTH					(double)(300)	//Element width for slider bar in px.
#define SLIDER_BAR_HEIGHT					(double)(20)	//Element height for slider bar in px.
	#define SLIDER_WIDTH					(double)(300)	//Element width for slider (excluding bar) in px.
	#define SLIDER_HEIGHT					(double)(7)		//Element height for slider (excluding bar) in px.
	#define BAR_WIDTH						(double)(10)	//Element width for bar (excluding slider) in px.
	#define BAR_HEIGHT						(double)(20)	//Element height for bar (excluding slider) in px.

#define INFO_BAR_WIDTH						(double)(300)	//Element width for info bar in px.
#define INFO_BAR_HEIGHT						(double)(5)		//Element height for info bar in px.

#define FONT_SIZE_SELECT					(float)(16.50)	//Font size for select buttons.
#define FONT_SIZE_SUB_TITLE					(float)(15.00)	//Font size for subtitle messages.
#define FONT_SIZE_SUB_MENU					(float)(22.50)	//Font size for sub menu messages.
#define FONT_SIZE_BACK						(float)(16.50)	//Font size for back buttons.
#if !((DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER) && (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER))
#define FONT_SIZE_DISABLED_MSG				(float)(22.50)	//Font size for disabled messages.
#endif //!((DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER) && (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER))
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
//Updater.
#define FONT_SIZE_UPDATER_STATE				(float)(15.00)	//Font size for state messages.
#define FONT_SIZE_UPDATER_CLOSE				(float)(14.00)	//Font size for close app messages.
#define FONT_SIZE_UPDATER_PATCH_NOTE		(float)(14.00)	//Font size for patch note.
#define FONT_SIZE_UPDATER_EDITION			(float)(18.00)	//Font size for edition messages.
#define FONT_SIZE_UPDATER_INSTALL			(float)(18.00)	//Font size for install button messages.
#define FONT_SIZE_UPDATER_3DSX_PATH			(float)(15.00)	//Font size for 3dsx download path messages.
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
//Languages.
#define FONT_SIZE_LANG						(float)(22.50)	//Font size for each language button.
#define FONT_SIZE_LANG_CN_DE_WORKAROUND		(float)(19.50)	//Font size for chinese button in German (temporal workaround).
//Font.
#define FONT_SIZE_FONT_NAME					(float)(13.50)	//Font size for font names.
//Wireless.
#define FONT_SIZE_WIRELESS_SSID				(float)(12.75)	//Font size for connected SSID.
//Screen recording.
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
#define FONT_SIZE_REC_UNAVAILABLE			(float)(15.00)	//Font size for recording unavailable messages.
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
#define FONT_SIZE_LICENSE					(float)(15.00)	//Font size for license name.

//Typedefs.
typedef enum
{
	MSG_UPDATE,
	MSG_LANGUAGES,
	MSG_LCD,
	MSG_CONTROL,
	MSG_FONT,
	MSG_WIFI,
	MSG_ADVANCED,
	MSG_BATTERY,
	MSG_8,										//No longer used, it was MSG_CHECK_UPDATE.
	MSG_ENGLISH,
	MSG_JAPANESE,
	MSG_NIGHT_MODE,
	MSG_ON,
	MSG_OFF,
	MSG_FLASH,
	MSG_BRIGHTNESS,
	MSG_LCD_OFF_TIME_0,
	MSG_LCD_OFF_TIME_1,
	MSG_SCROLL_SPEED,
	MSG_19,										//No longer used, it was MSG_JAPANESE_FONT.
	MSG_20,										//No longer used, it was MSG_CHINESE_FONT.
	MSG_21,										//No longer used, it was MSG_KOREAN_FONT.
	MSG_22,										//No longer used, it was MSG_TAIWANESE_FONT.
	MSG_LOAD_ALL_FONT,
	MSG_UNLOAD_ALL_FONT,
	MSG_SEND_INFO_MODE,
	MSG_ALLOW,
	MSG_DENY,
	MSG_DEBUG_MODE,
	MSG_ECO_MODE,
	MSG_BACK,
	MSG_CHECKING_UPDATE,
	MSG_CHECKING_UPDATE_FAILED,
	MSG_UP_TO_DATE,
	MSG_NEW_VERSION_AVAILABLE,
	MSG_35,										//No longer used, it was MSG_CLOSE_UPDATER/MSG_BACK_TO_PATCH_NOTE.
	MSG_36,										//No longer used, it was MSG_SELECT_EDITION.
	MSG_3DSX,
	MSG_CIA,
	MSG_FILE_PATH,
	MSG_DOWNLOADING,
	MSG_INSTALLING,
	MSG_SUCCESS,
	MSG_FAILURE,
	MSG_44,										//No longer used, it was MSG_RESTART.
	MSG_DL_INSTALL,
	MSG_CLOSE_APP,
	MSG_WIFI_MODE,
	MSG_CONNECTED_SSID,
	MSG_RECORDING,
	MSG_RECORD_BOTH_LCD,
	MSG_RECORD_TOP_LCD,
	MSG_RECORD_BOTTOM_LCD,
	MSG_STOP_RECORDING,
	MSG_LCD_MODE,
	MSG_CANNOT_RECORD,
	MSG_800PX,
	MSG_3D,
	MSG_400PX,
	MSG_HUNGARIAN,
	MSG_CHINESE,
	MSG_ITALIAN,
	MSG_FAKE_MODEL,
	MSG_SPANISH,
	MSG_ROMANIAN,
	MSG_POLISH,
	MSG_CPU_USAGE_MONITOR,
	MSG_DUMP_LOGS,
	MSG_RYUKYUAN,
	MSG_AUTO,
	MSG_SLEEP_TIME,
	MSG_GERMAN,
	MSG_GPU_USAGE_MONITOR,
	MSG_NET_USAGE_MONITOR,
	MSG_NVS_USAGE_MONITOR,
	MSG_RAM_USAGE_MONITOR,
	MSG_FAKE_MODEL_OLD_3DS,
	MSG_FAKE_MODEL_OLD_3DS_XL,
	MSG_FAKE_MODEL_OLD_2DS,
	MSG_FAKE_MODEL_NEW_3DS,
	MSG_FAKE_MODEL_NEW_3DS_XL,
	MSG_FAKE_MODEL_NEW_2DS_XL,
	MSG_BATTERY_LEVEL,
	MSG_BATTERY_VOLTAGE,
	MSG_BATTERY_TEMPERATURE,
	MSG_BATTERY_REMAINING_CHARGE,
	MSG_BATTERY_REMAINING_DISCHARGE,
	MSG_BATTERY_FULL,
	MSG_BATTERY_REMAINING_CALCULATING,
	MSG_LICENSE,

	MSG_MAX,
} Sem_msg;

typedef enum
{
	MENU_TOP = -1,

	MENU_UPDATE,		//Updater menu is displayed.
	MENU_LANGUAGES,		//Languages menu is displayed.
	MENU_LCD,			//LCD menu is displayed.
	MENU_CONTROL,		//Control menu is displayed.
	MENU_FONT,			//Font menu is displayed.
	MENU_WIFI,			//Wi-Fi menu is displayed.
	MENU_ADVANCED,		//Advanced menu is displayed.
	MENU_BATTERY,		//Battery menu is displayed.
	MENU_RECORDING,		//Screen recording menu is displayed.
	MENU_LICENSE,		//License menu is displayed.

	MENU_MAX,
} Sem_menu;

typedef enum
{
	RECORD_BOTH,		//Record both screen.
	RECORD_TOP,			//Only record top screen.
	RECORD_BOTTOM,		//Only record bottom screen.

	RECORD_MAX,
} Sem_record;

typedef enum
{
	EDITION_NONE = -1,

	EDITION_3DSX,		//.3dsx.
	EDITION_CIA,		//.cia.

	EDITION_MAX,
} Sem_edition;

typedef enum
{
	UPDATE_STATE_UPDATE_FAILURE = -2,	//Downloading/installing has failed.
	UPDATE_STATE_CHECK_FAILURE = -1,	//Downloading update info has failed.

	UPDATE_STATE_CHECKING,				//Checking (downloading) for update info.
	UPDATE_STATE_CHECK_SUCCESS,			//Update info has successfully retrieved.
	UPDATE_STATE_DOWNLOADING,			//Downloading update.
	UPDATE_STATE_INSTALLING,			//Installing update (for .cia).
	UPDATE_STATE_UPDATE_SUCCESS,		//Update has successfully finished.
} Sem_update_state;

typedef enum
{
	UPDATE_DATA_NEWEST_VERSION,									//Newest version.

	UPDATE_DATA_AVAILABLE_BASE,
	UPDATE_DATA_3DSX_AVAILABLE = UPDATE_DATA_AVAILABLE_BASE,	//Whether .3dsx is available.
	UPDATE_DATA_CIA_AVAILABLE,									//Whether .cia is available.

	UPDATE_DATA_URL_BASE,
	UPDATE_DATA_3DSX_URL = UPDATE_DATA_URL_BASE,				//Download URL for .3dsx.
	UPDATE_DATA_CIA_URL,										//Download URL for .cia.

	UPDATE_DATA_PATCH_NOTE,										//Patch note.

	UPDATE_DATA_MAX,
} Sem_update_data;

typedef struct
{
	bool is_connect_test_success;
	uint8_t wifi_state;
	Sem_model fake_model;
} Sem_internal_state;

typedef struct
{
	Sem_msg msg;		//Message ID to display.
	Sem_menu menu_id;	//Menu ID to use.
} Sem_sub_menu;

typedef struct
{
	bool* is_available;			//Whether this edition is available.
	Sem_msg msg;				//Message ID to display.
	Sem_edition edition_id;		//Edition ID to use.
	Draw_image_data* button;	//Button to use.
} Sem_updater_edition;

typedef struct
{
	const char* lang;			//Language name.
	Sem_msg msg;				//Message ID to display.
	Draw_image_data* button;	//Button to use.
} Sem_language;

typedef struct
{
	const Util_lib_info* lib_info;	//Library information.
	Draw_image_data* button;		//Button to use.
} Sem_license;

typedef struct
{
	uint32_t color;				//Button color when it's NOT selected.
	uint32_t selected_color;	//Button color when it's selected.
	Sem_msg msg;				//Message ID for the button.
	Draw_image_data* button;	//Button to use.
} Sem_select_1;

typedef struct
{
	Sem_select_1 left;			//Left element.
	Sem_select_1 right;			//Right element.
} Sem_select_2;

typedef struct
{
	Sem_select_1 left;			//Left element.
	Sem_select_1 center_left;	//Center left element.
	Sem_select_1 center_right;	//Center right element.
	Sem_select_1 right;			//Right element.
} Sem_select_4;

typedef struct
{
	uint32_t color;				//Slider bar color when it's NOT selected.
	uint32_t selected_color;	//Slider bar color when it's selected.
	uint32_t slider_color;		//Slider color.
	Draw_image_data* bar;		//Slider bar to use.
	Draw_image_data* slider;	//Slider to use.
} Sem_slider;

typedef struct
{
	uint32_t color;					//Background bar color.
	uint32_t active_color_left;		//Left side foreground bar color.
	uint32_t active_color_right;	//Right side foreground bar color.
} Sem_bar;

typedef struct
{
	bool is_charging;			//Whether charging.
	double level;				//Battery level in %.
} Sem_battery_history;

typedef struct
{
	uint32_t index;				//Next index.
	uint32_t count;				//Valid data count.
	uint64_t timestamp;			//Last timestamp.
	double estimated_time;		//Estimated remaining charge/discharge time in minutes.
	Sem_battery_history history[30];	//History data.
} Sem_battery_data;

//Prototypes.
static void Sem_scroll_bar(Draw_image_data* bar, double current_pos, double min_pos);
static void Sem_sub_menu_button(const Sem_sub_menu* sub_menu, double x, double y, uint32_t color);
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static void Sem_updater_status(Sem_update_state state, bool is_new_ver_available, const Str_data* additional_text, double x, double y, uint32_t color);
static void Sem_updater_close_button(Draw_image_data* button, Sem_msg msg_id, double x, double y, uint32_t color);
static void Sem_updater_edition_button(const Sem_updater_edition* edition, Sem_edition selected_edition, double x, double y, uint32_t color, uint32_t disabled_color, uint32_t selected_color);
static void Sem_updater_3dsx_path(Sem_msg msg_id, const Str_data* path, double x, double y, uint32_t color);
static void Sem_updater_install_button(Draw_image_data* button, Sem_msg msg_id, double x, double y, uint32_t color);
static void Sem_updater_patch_note(const Str_data* patch_note, double x, double y, uint32_t color);
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static void Sem_language_button(const Sem_language* language, const char* current_lang, double x, double y, uint32_t color, uint32_t selected_color);
static void Sem_font_button(Draw_image_data* button, uint8_t index, uint32_t color, double x, double y);
static void Sem_license_button(const Sem_license* license, double x, double y, uint32_t color);
static void Sem_sub_title(const Str_data* msg, double x, double y, uint32_t color, double x_start, double x_end, double y_start, double y_end);
static void Sem_select_button_1(const Sem_select_1* select, bool is_active, double x, double y, uint32_t color,
uint32_t selected_color, double x_start, double x_end, double y_start, double y_end);
static void Sem_select_button_2(const Sem_select_2* select, uint8_t active_index, double x, double y, const uint32_t color[2],
const uint32_t selected_color[2], double x_start, double x_end, double y_start, double y_end);
static void Sem_select_button_4(const Sem_select_4* select, uint8_t active_index, double x, double y, const uint32_t color[4],
const uint32_t selected_color[4], double x_start, double x_end, double y_start, double y_end);
static void Sem_slider_bar(const Sem_slider* slider, double min, double max, double current,
double x, double y, double x_start, double x_end, double y_start, double y_end);
static void Sem_info_bar(const Sem_bar* bar, double min, double max, double current,
double x, double y, double x_start, double x_end, double y_start, double y_end);
static double Sem_estimate_battery_time(bool was_charging, bool is_charging, double battery_level);
static void Sem_get_system_info(void);
static void Sem_open_web(const char* url);
static void Sem_worker_callback(void);
void Sem_hw_config_thread(void* arg);

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
void Sem_encode_thread(void* arg);
void Sem_record_thread(void* arg);
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
void Sem_check_connectivity_thread(void* arg);
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
void Sem_update_thread(void* arg);
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

//Variables.
static bool sem_main_run = false;
static bool sem_already_init = false;
static bool sem_thread_run = false;
static bool sem_thread_suspend = false;
static bool sem_reload_msg_request = false;
static bool sem_scroll_mode = false;
static bool sem_dump_log_request = false;
static bool sem_should_wifi_enabled = false;
static double sem_y_offset = 0;
static double sem_y_min = 0;
static double sem_touch_x_move_left = 0;
static double sem_touch_y_move_left = 0;
static const char* sem_model_name[6] = { "OLD 3DS", "OLD 3DS XL", "OLD 2DS", "NEW 3DS", "NEW 3DS XL", "NEW 2DS XL", };
static Str_data sem_msg[MSG_MAX] = { 0, };
static Str_data sem_newest_ver_data[UPDATE_DATA_MAX] = { 0, };
static Sync_data sem_config_state_mutex = { 0, };
static Thread sem_hw_config_thread = NULL;
static Draw_image_data sem_back_button = { 0, }, sem_scroll_bar = { 0, }, sem_menu_button[MENU_MAX] = { 0, }, sem_english_button = { 0, },
sem_japanese_button = { 0, }, sem_hungarian_button = { 0, }, sem_chinese_button = { 0, }, sem_italian_button = { 0, },
sem_spanish_button = { 0, }, sem_romanian_button = { 0, }, sem_polish_button = { 0, }, sem_ryukyuan_button = { 0, }, sem_german_button = { 0, },
sem_night_mode_on_button = { 0, }, sem_night_mode_off_button = { 0, }, sem_flash_mode_button = { 0, }, sem_screen_brightness_slider = { 0, },
sem_screen_brightness_bar = { 0, }, sem_screen_off_time_slider = { 0, }, sem_screen_off_time_bar = { 0, }, sem_sleep_time_slider = { 0, },
sem_sleep_time_bar = { 0, }, sem_800px_mode_button = { 0, }, sem_3d_mode_button = { 0, }, sem_400px_mode_button = { 0, },
sem_auto_mode_button = { 0, }, sem_scroll_speed_slider = { 0, }, sem_scroll_speed_bar = { 0, }, sem_load_all_ex_font_button = { 0, },
sem_unload_all_ex_font_button = { 0, }, sem_ex_font_button[DEF_EXFONT_NUM_OF_FONT_NAME] = { 0, }, sem_wifi_on_button = { 0, },
sem_wifi_off_button = { 0, }, sem_allow_send_info_button = { 0, }, sem_deny_send_info_button = { 0, }, sem_debug_mode_on_button = { 0, },
sem_debug_mode_off_button = { 0, }, sem_eco_mode_on_button = { 0, }, sem_eco_mode_off_button = { 0, }, sem_record_both_lcd_button = { 0, },
sem_record_top_lcd_button = { 0, }, sem_record_bottom_lcd_button = { 0, }, sem_use_fake_model_button = { 0, }, sem_dump_log_button = { 0, },
sem_license_this_app_button = { 0, }, sem_license_buttons[DEF_UTIL_LIB_INFO_COUNT] = { 0, };
static Sem_menu sem_selected_menu_mode = MENU_TOP;
static Sem_internal_state sem_internal_state = { 0, };
static Sem_state sem_state = { 0, };
static Sem_config sem_config = { 0, };
static Sem_battery_data sem_battery_data = { 0, };
static Sem_license sem_licenses[DEF_UTIL_LIB_INFO_COUNT] = { 0, };

#if DEF_CPU_USAGE_API_ENABLE
static bool sem_is_cpu_usage_monitor_running = false;
static bool sem_should_cpu_usage_monitor_running = false;
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
static bool sem_is_gpu_usage_monitor_running = false;
static bool sem_should_gpu_usage_monitor_running = false;
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
static bool sem_is_net_usage_monitor_running = false;
static bool sem_should_net_usage_monitor_running = false;
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
static bool sem_is_nvs_usage_monitor_running = false;
static bool sem_should_nvs_usage_monitor_running = false;
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
static bool sem_is_ram_usage_monitor_running = false;
static bool sem_should_ram_usage_monitor_running = false;
#endif //DEF_RAM_USAGE_API_ENABLE

#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
static Thread sem_check_connectivity_thread = NULL;
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static bool sem_check_update_request = false;
static bool sem_new_version_available = false;
static bool sem_dl_file_request = false;
static bool sem_is_3dsx_available = false;
static bool sem_is_cia_available = false;
static uint32_t sem_installed_size = 0;
static uint32_t sem_total_cia_size = 0;
static uint32_t sem_dled_size = 0;
static Thread sem_update_thread = NULL;
static Draw_image_data sem_3dsx_button = { 0, }, sem_cia_button = { 0, }, sem_dl_install_button = { 0, }, sem_close_app_button = { 0, };
static Sem_edition sem_selected_edition = EDITION_NONE;
static Sem_update_state sem_update_progress = UPDATE_STATE_CHECK_FAILURE;
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#if DEF_CPU_USAGE_API_ENABLE
static Draw_image_data sem_monitor_cpu_usage_on_button = { 0, }, sem_monitor_cpu_usage_off_button = { 0, };
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
static Draw_image_data sem_monitor_gpu_usage_on_button = { 0, }, sem_monitor_gpu_usage_off_button = { 0, };
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
static Draw_image_data sem_monitor_net_usage_on_button = { 0, }, sem_monitor_net_usage_off_button = { 0, };
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
static Draw_image_data sem_monitor_nvs_usage_on_button = { 0, }, sem_monitor_nvs_usage_off_button = { 0, };
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
static Draw_image_data sem_monitor_ram_usage_on_button = { 0, }, sem_monitor_ram_usage_off_button = { 0, };
#endif //DEF_RAM_USAGE_API_ENABLE

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
static bool sem_record_request = false;
static bool sem_encode_request = false;
static bool sem_wait_request = false;
static bool sem_stop_record_request = false;
static uint8_t* sem_yuv420p = NULL;
static uint16_t sem_rec_width = 400;
static uint16_t sem_rec_height = 480;
static Thread sem_record_thread = NULL, sem_encode_thread = NULL;
static Sem_record sem_selected_recording_mode = RECORD_BOTH;
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

static const Sem_sub_menu sem_sub_menus[] =
{
	{ .msg = MSG_LICENSE,	.menu_id = MENU_LICENSE,	},
	{ .msg = MSG_UPDATE,	.menu_id = MENU_UPDATE,		},
	{ .msg = MSG_LANGUAGES,	.menu_id = MENU_LANGUAGES,	},
	{ .msg = MSG_LCD,		.menu_id = MENU_LCD,		},
	{ .msg = MSG_CONTROL,	.menu_id = MENU_CONTROL,	},
	{ .msg = MSG_FONT,		.menu_id = MENU_FONT,		},
	{ .msg = MSG_WIFI,		.menu_id = MENU_WIFI,		},
	{ .msg = MSG_ADVANCED,	.menu_id = MENU_ADVANCED,	},
	{ .msg = MSG_BATTERY,	.menu_id = MENU_BATTERY,	},
	{ .msg = MSG_RECORDING,	.menu_id = MENU_RECORDING,	},
};
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static const Sem_updater_edition sem_updater_editions[] =
{
	{ .is_available = &sem_is_3dsx_available,	.msg = MSG_3DSX,	.edition_id = EDITION_3DSX,	.button = &sem_3dsx_button,	},
	{ .is_available = &sem_is_cia_available,	.msg = MSG_CIA,		.edition_id = EDITION_CIA,	.button = &sem_cia_button,	},
};
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static const Sem_language sem_languages[] =
{
	{ .lang = "en",		.msg = MSG_ENGLISH,		.button = &sem_english_button,		},
	{ .lang = "jp",		.msg = MSG_JAPANESE,	.button = &sem_japanese_button,		},
	{ .lang = "hu",		.msg = MSG_HUNGARIAN,	.button = &sem_hungarian_button,	},
	{ .lang = "zh-cn",	.msg = MSG_CHINESE,		.button = &sem_chinese_button,		},
	{ .lang = "it",		.msg = MSG_ITALIAN,		.button = &sem_italian_button,		},
	{ .lang = "es",		.msg = MSG_SPANISH,		.button = &sem_spanish_button,		},
	{ .lang = "ro",		.msg = MSG_ROMANIAN,	.button = &sem_romanian_button,		},
	{ .lang = "pl",		.msg = MSG_POLISH,		.button = &sem_polish_button,		},
	{ .lang = "ryu",	.msg = MSG_RYUKYUAN,	.button = &sem_ryukyuan_button,		},
	{ .lang = "de",		.msg = MSG_GERMAN,		.button = &sem_german_button,		},
};
static const Sem_select_2 sem_select_night_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_night_mode_on_button,	},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_night_mode_off_button,	},
};
static const Sem_select_1 sem_select_flash_mode =
{
	.color = DEF_DRAW_WEAK_RED,	.selected_color = DEF_DRAW_RED,	.msg = MSG_FLASH,		.button = &sem_flash_mode_button,
};
static const Sem_slider sem_slider_brightness =
{
	.color = DEF_DRAW_WEAK_LIME,		.selected_color = DEF_DRAW_LIME,			.slider_color = DEF_DRAW_WEAK_RED,
	.bar = &sem_screen_brightness_bar,	.slider = &sem_screen_brightness_slider,
};
static const Sem_slider sem_slider_lcd_off_time =
{
	.color = DEF_DRAW_WEAK_LIME,		.selected_color = DEF_DRAW_LIME,			.slider_color = DEF_DRAW_WEAK_RED,
	.bar = &sem_screen_off_time_bar,	.slider = &sem_screen_off_time_slider,
};
static const Sem_slider sem_slider_sleep_time =
{
	.color = DEF_DRAW_WEAK_LIME,		.selected_color = DEF_DRAW_LIME,			.slider_color = DEF_DRAW_WEAK_RED,
	.bar = &sem_sleep_time_bar,			.slider = &sem_sleep_time_slider,
};
static const Sem_select_4 sem_select_top_mode =
{
	.left =				{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_800PX,	.button = &sem_800px_mode_button,	},
	.center_left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_3D,		.button = &sem_3d_mode_button,		},
	.center_right =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_400PX,	.button = &sem_400px_mode_button,	},
	.right =			{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_AUTO,	.button = &sem_auto_mode_button,	},
};
static const Sem_slider sem_slider_scroll_speed =
{
	.color = DEF_DRAW_WEAK_LIME,		.selected_color = DEF_DRAW_LIME,			.slider_color = DEF_DRAW_WEAK_RED,
	.bar = &sem_scroll_speed_bar,		.slider = &sem_scroll_speed_slider,
};
static const Sem_select_2 sem_select_font_load =
{
	.left =		{ .color = DEF_DRAW_WEAK_RED,		.selected_color = DEF_DRAW_RED,		.msg = MSG_LOAD_ALL_FONT,		.button = &sem_load_all_ex_font_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_ORANGE,	.selected_color = DEF_DRAW_ORANGE,	.msg = MSG_UNLOAD_ALL_FONT,		.button = &sem_unload_all_ex_font_button,	},
};
static const Sem_select_2 sem_select_wifi_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_wifi_on_button,			},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_wifi_off_button,			},
};
static const Sem_select_2 sem_select_send_info_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ALLOW,	.button = &sem_allow_send_info_button,	},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_DENY,	.button = &sem_deny_send_info_button,	},
};
static const Sem_select_2 sem_select_debug_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_debug_mode_on_button,	},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_debug_mode_off_button,	},
};
static const Sem_select_1 sem_select_fake_mode[] =
{
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_OLD_3DS,		.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_OLD_3DS_XL,	.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_OLD_2DS,		.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_NEW_3DS,		.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_NEW_3DS_XL,	.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_FAKE_MODEL_NEW_2DS_XL,	.button = &sem_use_fake_model_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,						.button = &sem_use_fake_model_button,	},
};
static const Sem_select_1 sem_select_log_dump =
{
	.color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_DUMP_LOGS,	.button = &sem_dump_log_button,
};

#if DEF_CPU_USAGE_API_ENABLE
static const Sem_select_2 sem_select_cpu_monitor_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_monitor_cpu_usage_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_monitor_cpu_usage_off_button,	},
};
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
static const Sem_select_2 sem_select_gpu_monitor_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_monitor_gpu_usage_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_monitor_gpu_usage_off_button,	},
};
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
static const Sem_select_2 sem_select_net_monitor_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_monitor_net_usage_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_monitor_net_usage_off_button,	},
};
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
static const Sem_select_2 sem_select_nvs_monitor_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_monitor_nvs_usage_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_monitor_nvs_usage_off_button,	},
};
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
static const Sem_select_2 sem_select_ram_monitor_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_monitor_ram_usage_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_monitor_ram_usage_off_button,	},
};
#endif //DEF_RAM_USAGE_API_ENABLE

static const Sem_select_2 sem_select_eco_mode =
{
	.left =		{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_ON,		.button = &sem_eco_mode_on_button,		},
	.right =	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_OFF,		.button = &sem_eco_mode_off_button,		},
};
static const Sem_bar sem_bar_battery_level =
{
	.color = DEF_DRAW_GRAY,		.active_color_left = DEF_DRAW_RED,		.active_color_right = DEF_DRAW_BLUE,
};
static const Sem_bar sem_bar_battery_voltage =
{
	.color = DEF_DRAW_GRAY,		.active_color_left = DEF_DRAW_OLIVE,	.active_color_right = DEF_DRAW_ORANGE,
};
static const Sem_bar sem_bar_battery_temperature =
{
	.color = DEF_DRAW_GRAY,		.active_color_left = DEF_DRAW_CYAN,		.active_color_right = DEF_DRAW_RED,
};

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
static const Sem_select_1 sem_select_record_both[] =
{
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_RECORD_BOTH_LCD,		.button = &sem_record_both_lcd_button,		},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_STOP_RECORDING,		.button = &sem_record_both_lcd_button,		},
};
static const Sem_select_1 sem_select_record_top[] =
{
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_RECORD_TOP_LCD,		.button = &sem_record_top_lcd_button,		},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_STOP_RECORDING,		.button = &sem_record_top_lcd_button,		},
};
static const Sem_select_1 sem_select_record_bottom[] =
{
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_RECORD_BOTTOM_LCD,	.button = &sem_record_bottom_lcd_button,	},
	{ .color = DEF_DRAW_WEAK_CYAN,	.selected_color = DEF_DRAW_CYAN,	.msg = MSG_STOP_RECORDING,		.button = &sem_record_bottom_lcd_button,	},
};
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

static const Sem_license sem_license_this_app =
{
	.lib_info = (Util_lib_info[])
	{
		{ .name = "", .ver = "", .license = "GPLv3", .full_license_url = "https://raw.githubusercontent.com/Core-2-Extreme/Video_player_for_3DS/refs/heads/main/LICENSE", },
	},
	.button = &sem_license_this_app_button,
};

//Code.
bool Sem_query_init_flag(void)
{
	return sem_already_init;
}

bool Sem_query_running_flag(void)
{
	return sem_main_run;
}

void Sem_resume(void)
{
	sem_thread_suspend = false;
	sem_main_run = true;
	//Reset key state on scene change.
	Util_hid_reset_key_state(HID_KEY_BIT_ALL);
	Draw_set_refresh_needed(true);
	Menu_suspend();
}

void Sem_suspend(void)
{
	Menu_resume();
	sem_thread_suspend = true;
	sem_main_run = false;
}

uint32_t Sem_load_msg(const char* lang)
{
	char file_name[32] = { 0, };

	snprintf(file_name, sizeof(file_name), "sem_%s.txt", (lang ? lang : ""));
	return Util_load_msg(file_name, sem_msg, MSG_MAX);
}

void Sem_get_config(Sem_config* config)
{
	if(!sem_already_init)
		return;

	if(!config)
		return;

	Util_sync_lock(&sem_config_state_mutex, UINT64_MAX);
	memcpy(config, &sem_config, sizeof(Sem_config));
	Util_sync_unlock(&sem_config_state_mutex);
}

void Sem_set_config(Sem_config* new_config)
{
	bool reload_msg = false;

	if(!sem_already_init)
		return;

	if(!new_config)
		return;

	Util_sync_lock(&sem_config_state_mutex, UINT64_MAX);

	// if(sem_config.is_debug != new_config->is_debug)
		//Do nothing.
	// if(sem_config.is_send_info_allowed != new_config->is_send_info_allowed)
		//Do nothing.
	// if(sem_config.is_night != new_config->is_night)
		//Do nothing.
	// if(sem_config.is_flash != new_config->is_flash)
		//Do nothing, Sem_hw_config_thread() will do the job later.
	// if(sem_config.is_eco != new_config->is_eco)
		//Do nothing.
	if(sem_config.is_wifi_on != new_config->is_wifi_on)
	{
		//Send a request.
		sem_should_wifi_enabled = new_config->is_wifi_on;
		//Don't update config yet, Sem_hw_config_thread() will do the job later.
		new_config->is_wifi_on = sem_config.is_wifi_on;
	}
	// if(sem_config.is_top_lcd_on != new_config->is_top_lcd_on)
		//Do nothing, Sem_hw_config_thread() will do the job later.
	// if(sem_config.is_bottom_lcd_on != new_config->is_bottom_lcd_on)
		//Do nothing, Sem_hw_config_thread() will do the job later.
	if(sem_config.top_lcd_brightness != new_config->top_lcd_brightness)
	{
		//Do nothing (just validate the value), Sem_hw_config_thread() will do the job later.
		if(new_config->top_lcd_brightness > 180)
			new_config->top_lcd_brightness = 180;
	}
	if(sem_config.bottom_lcd_brightness != new_config->bottom_lcd_brightness)
	{
		//Do nothing (just validate the value), Sem_hw_config_thread() will do the job later.
		if(new_config->bottom_lcd_brightness > 180)
			new_config->bottom_lcd_brightness = 180;
	}
	if(sem_config.time_to_turn_off_lcd != new_config->time_to_turn_off_lcd)
	{
		//Do nothing (just validate the value), Sem_hw_config_thread() will do the job later.
		if(new_config->time_to_turn_off_lcd > 0 && (new_config->time_to_turn_off_lcd < 20 || new_config->time_to_turn_off_lcd > 600))
			new_config->time_to_turn_off_lcd = 150;
	}
	if(sem_config.time_to_enter_sleep != new_config->time_to_enter_sleep)
	{
		//Do nothing (just validate the value), Sem_hw_config_thread() will do the job later.
		if(new_config->time_to_enter_sleep > 0 && (new_config->time_to_enter_sleep < 20 || new_config->time_to_enter_sleep > 600))
			new_config->time_to_enter_sleep = 175;
	}
	// if(sem_config.scroll_speed != new_config->scroll_speed)
		//Do nothing.
	if(strncmp(sem_config.lang, new_config->lang, sizeof(sem_config.lang)) != 0)
	{
		//Validate the value and send a request if the value is valid.
		//Sem_worker_callback() will do the job.
		if(strcmp(new_config->lang, "jp") != 0 && strcmp(new_config->lang, "en") != 0
		&& strcmp(new_config->lang, "hu") != 0 && strcmp(new_config->lang, "zh-cn") != 0
		&& strcmp(new_config->lang, "it") != 0 && strcmp(new_config->lang, "es") != 0
		&& strcmp(new_config->lang, "ro") != 0 && strcmp(new_config->lang, "pl") != 0
		&& strcmp(new_config->lang, "ryu") != 0&& strcmp(new_config->lang, "de") != 0)
			snprintf(new_config->lang, sizeof(new_config->lang), "en");
		else
			reload_msg = true;
	}

	if(new_config->time_to_turn_off_lcd > 0 && new_config->time_to_enter_sleep > 0
	&& (new_config->time_to_turn_off_lcd > new_config->time_to_enter_sleep))
		new_config->time_to_enter_sleep = new_config->time_to_turn_off_lcd;

	memcpy(&sem_config, new_config, sizeof(Sem_config));
	if(reload_msg)
		sem_reload_msg_request = true;

	Util_sync_unlock(&sem_config_state_mutex);
}

void Sem_get_state(Sem_state* state)
{
	if(!sem_already_init)
		return;

	if(!state)
		return;

	Util_sync_lock(&sem_config_state_mutex, UINT64_MAX);
	memcpy(state, &sem_state, sizeof(Sem_state));
	Util_sync_unlock(&sem_config_state_mutex);
}

void Sem_init(void)
{
	DEF_LOG_STRING("Initializing...");
	bool wifi_state = true;
	uint8_t model = 0;
	uint8_t* read_cache = NULL;
	uint32_t read_size = 0;
	uint32_t result = DEF_ERR_OTHER;
	Str_data data[13] = { 0, };
	Sem_config config = { 0, };
	Sem_state state = { 0, };
	const Util_lib_info* lib_info = Util_get_lib_info();

	//Default values.
	config.is_debug = false;
	config.is_send_info_allowed = false;
	config.is_night = false;
	config.is_flash = false;
	config.is_eco = true;
	config.is_wifi_on = true;
	config.is_top_lcd_on = true;
	config.is_bottom_lcd_on = true;
	config.top_lcd_brightness = 100;
	config.bottom_lcd_brightness = 100;
	config.time_to_turn_off_lcd = 150;
	config.time_to_enter_sleep = 175;
	config.scroll_speed = 0.5;
	config.screen_mode = DEF_SEM_SCREEN_MODE_AUTO;
	memset(config.lang, 0x00, sizeof(config.lang));
	sem_config = config;

	state.is_charging = false;
	state.battery_temp = 0;
	state.free_ram = 0;
	state.free_linear_ram = 0;
	state.battery_level = 0;
	state.battery_voltage = 0;
	state.num_of_launch = 0;
	state.wifi_signal = DEF_SEM_WIFI_SIGNAL_DISABLED;
	state.console_model = DEF_SEM_MODEL_OLD3DS;
	state.time.years = 0;
	state.time.months = 0;
	state.time.days = 0;
	state.time.hours = 0;
	state.time.minutes = 0;
	state.time.seconds = 0;
	memset(state.connected_wifi, 0x00, sizeof(state.connected_wifi));
	memset(state.msg, 0x00, sizeof(state.msg));
	sem_state = state;

	sem_battery_data.index = 0;
	sem_battery_data.count = 0;
	sem_battery_data.timestamp = (osGetTime() - DEF_UTIL_S_TO_MS(60));
	sem_battery_data.estimated_time = -1;
	for(uint16_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_battery_data.history); i++)
		sem_battery_data.history[i].level = -1;

	for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
	{
		sem_licenses[i].button = &sem_license_buttons[i];
		sem_licenses[i].lib_info = &lib_info[i];
	}

	result = Util_sync_create(&sem_config_state_mutex, SYNC_TYPE_NON_RECURSIVE_MUTEX);
	if(result != DEF_SUCCESS)
	{
		DEF_LOG_RESULT(Util_sync_create, false, result);
		return;
	}

	for(uint32_t i = 0; i < UPDATE_DATA_MAX; i++)
		Util_str_init(&sem_newest_ver_data[i]);

	if(CFGU_GetSystemModel(&model) == DEF_SUCCESS)
	{
		if(model == CFG_MODEL_3DS)
			state.console_model = DEF_SEM_MODEL_OLD3DS;
		else if(model == CFG_MODEL_3DSXL)
			state.console_model = DEF_SEM_MODEL_OLD3DSXL;
		else if(model == CFG_MODEL_2DS)
			state.console_model = DEF_SEM_MODEL_OLD2DS;
		else if(model == CFG_MODEL_N3DS)
			state.console_model = DEF_SEM_MODEL_NEW3DS;
		else if(model == CFG_MODEL_N3DSXL)
			state.console_model = DEF_SEM_MODEL_NEW3DSXL;
		else if(model == CFG_MODEL_N2DSXL)
			state.console_model = DEF_SEM_MODEL_NEW2DSXL;

		DEF_LOG_FORMAT("Model: %s", sem_model_name[state.console_model]);
	}
	else
		DEF_LOG_STRING("Model: Unknown");

	if(Util_file_load_from_file("fake_model.txt", DEF_MENU_MAIN_DIR, &read_cache, 1, 0, &read_size) == DEF_SUCCESS && *read_cache < DEF_SEM_MODEL_MAX)
	{
		//Fake model config exists.
		state.console_model = *read_cache;
		sem_internal_state.fake_model = state.console_model;

		DEF_LOG_FORMAT("Using fake model: %s", sem_model_name[state.console_model]);

		free(read_cache);
		read_cache = NULL;
	}
	else
		sem_internal_state.fake_model = DEF_SEM_MODEL_MAX;//OFF.

	if(!DEF_SEM_MODEL_IS_NEW(state.console_model))
		osSetSpeedupEnable(false);

	DEF_LOG_RESULT_SMART(result, Util_file_load_from_file("settings.txt", DEF_MENU_MAIN_DIR, &read_cache, 0x1000, 0, &read_size), (result == DEF_SUCCESS), result)
	if (result == DEF_SUCCESS)
	{
		DEF_LOG_RESULT_SMART(result, Util_parse_file((char*)read_cache, 13, data), (result == DEF_SUCCESS), result);

		//If this fails, the settings file may come from older version.
		//To keep backward compatibility, try to parse with less elements.
		if(result != DEF_SUCCESS)
			DEF_LOG_RESULT_SMART(result, Util_parse_file((char*)read_cache, 12, data), (result == DEF_SUCCESS), result);

		if(result != DEF_SUCCESS)
			DEF_LOG_RESULT_SMART(result, Util_parse_file((char*)read_cache, 11, data), (result == DEF_SUCCESS), result);

		if(!Util_str_has_data(&data[11]))
		{
			Util_str_init(&data[11]);
			Util_str_set(&data[11], "175");//Screen mode default value.
		}
		if(!Util_str_has_data(&data[12]))
		{
			Util_str_init(&data[12]);
			Util_str_set(&data[12], "175");//Time to turn off LCDs default value.
		}

		if(!Util_str_has_data(&data[11]) || !Util_str_has_data(&data[12]))
			result = DEF_ERR_OUT_OF_MEMORY;

		if(result == DEF_SUCCESS)
		{
			uint8_t brightness = 0;
			uint8_t length = Util_min(data[0].length, (sizeof(config.lang) - 1));

			memcpy(config.lang, data[0].buffer, length);
			brightness = (uint8_t)strtoul(DEF_STR_NEVER_NULL(&data[1]), NULL, 10);
			config.time_to_turn_off_lcd = (uint16_t)strtoul(DEF_STR_NEVER_NULL(&data[2]), NULL, 10);
			config.scroll_speed = strtod(DEF_STR_NEVER_NULL(&data[3]), NULL);
			config.is_send_info_allowed = (strtoul(DEF_STR_NEVER_NULL(&data[4]), NULL, 10) != 0);
			state.num_of_launch = (uint32_t)strtoul(DEF_STR_NEVER_NULL(&data[5]), NULL, 10);
			config.is_night = (strtoul(DEF_STR_NEVER_NULL(&data[6]), NULL, 10) != 0);
			config.is_eco = (strtoul(DEF_STR_NEVER_NULL(&data[7]), NULL, 10) != 0);
			wifi_state = (strtoul(DEF_STR_NEVER_NULL(&data[8]), NULL, 10) != 0);
			//9 and 10 is no longer used.
			config.screen_mode = (Sem_screen_mode)strtoul(DEF_STR_NEVER_NULL(&data[11]), NULL, 10);
			config.time_to_enter_sleep = (uint16_t)strtoul(DEF_STR_NEVER_NULL(&data[12]), NULL, 10);

			if(strcmp(config.lang, "jp") != 0 && strcmp(config.lang, "en") != 0
			&& strcmp(config.lang, "hu") != 0 && strcmp(config.lang, "zh-cn") != 0
			&& strcmp(config.lang, "it") != 0 && strcmp(config.lang, "es") != 0
			&& strcmp(config.lang, "ro") != 0 && strcmp(config.lang, "pl") != 0
			&& strcmp(config.lang, "ryu") != 0 && strcmp(config.lang, "de") != 0)
				snprintf(config.lang, sizeof(config.lang), "en");

			if(brightness > 180)
				brightness = 100;

			config.top_lcd_brightness = brightness;
			config.bottom_lcd_brightness = brightness;

			if(config.time_to_turn_off_lcd > 0 && (config.time_to_turn_off_lcd < 20 || config.time_to_turn_off_lcd > 600))
				config.time_to_turn_off_lcd = 150;

			if(config.scroll_speed < 0.05 || config.scroll_speed > 2)
				config.scroll_speed = 0.5;

			if(config.screen_mode > DEF_SEM_SCREEN_MODE_3D)
				config.screen_mode = DEF_SEM_SCREEN_MODE_AUTO;

			if(config.time_to_enter_sleep > 0 && (config.time_to_enter_sleep < 20 || config.time_to_enter_sleep > 600))
				config.time_to_enter_sleep = 175;

			if(config.time_to_turn_off_lcd > 0 && config.time_to_enter_sleep > 0
			&& (config.time_to_turn_off_lcd > config.time_to_enter_sleep))
				config.time_to_enter_sleep = config.time_to_turn_off_lcd;

			sem_config = config;
		}
		free(read_cache);
		read_cache = NULL;
	}

	for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(data); i++)
		Util_str_free(&data[i]);

	config = sem_config;

	if(state.console_model == DEF_SEM_MODEL_OLD2DS && config.screen_mode == DEF_SEM_SCREEN_MODE_800PX)//OLD 2DS doesn't support high resolution mode.
		config.screen_mode = DEF_SEM_SCREEN_MODE_AUTO;

	if((state.console_model == DEF_SEM_MODEL_OLD2DS || state.console_model == DEF_SEM_MODEL_NEW2DSXL)
	&& config.screen_mode == DEF_SEM_SCREEN_MODE_3D)//2DSs don't support 3D mode.
		config.screen_mode = DEF_SEM_SCREEN_MODE_AUTO;

	result = Util_hw_config_set_wifi_state(wifi_state);
	if(result == DEF_SUCCESS || result == 0xC8A06C0D)
		config.is_wifi_on = wifi_state;

	sem_should_wifi_enabled = config.is_wifi_on;
	sem_config = config;
	sem_state = state;

	sem_thread_run = true;
	sem_hw_config_thread = threadCreate(Sem_hw_config_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_REALTIME, 1, false);
#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
	sem_check_connectivity_thread = threadCreate(Sem_check_connectivity_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_NORMAL, 1, false);
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
	sem_update_thread = threadCreate(Sem_update_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_NORMAL, 0, false);
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
	sem_record_thread = threadCreate(Sem_record_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_HIGH, 0, false);
	if(DEF_SEM_MODEL_IS_NEW(state.console_model))
		sem_encode_thread = threadCreate(Sem_encode_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_HIGH, 2, false);
	else
		sem_encode_thread = threadCreate(Sem_encode_thread, NULL, DEF_THREAD_STACKSIZE, DEF_THREAD_PRIORITY_HIGH, 1, false);
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

	sem_reload_msg_request = true;

	//Global.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_y_offset, sizeof(sem_y_offset));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_y_min, sizeof(sem_y_min));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_selected_menu_mode, sizeof(sem_selected_menu_mode));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_mode, sizeof(sem_scroll_mode));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_bar.selected, sizeof(sem_scroll_bar.selected));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_back_button.selected, sizeof(sem_back_button.selected));
	for(uint32_t i = 0; i < MENU_MAX; i++)
		Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_menu_button[i].selected, sizeof(sem_menu_button[i].selected));

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
	//Updater.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_dl_file_request, sizeof(sem_dl_file_request));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_check_update_request, sizeof(sem_check_update_request));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_selected_edition, sizeof(sem_selected_edition));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_installed_size, sizeof(sem_installed_size));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_dled_size, sizeof(sem_dled_size));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_3dsx_button.selected, sizeof(sem_3dsx_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_cia_button.selected, sizeof(sem_cia_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_dl_install_button.selected, sizeof(sem_dl_install_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_close_app_button.selected, sizeof(sem_close_app_button.selected));
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

	//Languages.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_reload_msg_request, sizeof(sem_reload_msg_request));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_english_button.selected, sizeof(sem_english_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_japanese_button.selected, sizeof(sem_japanese_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_hungarian_button.selected, sizeof(sem_hungarian_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_chinese_button.selected, sizeof(sem_chinese_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_italian_button.selected, sizeof(sem_italian_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_spanish_button.selected, sizeof(sem_spanish_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_romanian_button.selected, sizeof(sem_romanian_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_polish_button.selected, sizeof(sem_polish_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_ryukyuan_button.selected, sizeof(sem_ryukyuan_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_german_button.selected, sizeof(sem_german_button.selected));

	//LCD.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_night, sizeof(sem_config.is_night));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_flash, sizeof(sem_config.is_flash));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.top_lcd_brightness, sizeof(sem_config.top_lcd_brightness));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.bottom_lcd_brightness, sizeof(sem_config.bottom_lcd_brightness));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.time_to_turn_off_lcd, sizeof(sem_config.time_to_turn_off_lcd));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.time_to_enter_sleep, sizeof(sem_config.time_to_enter_sleep));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.screen_mode, sizeof(sem_config.screen_mode));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_night_mode_on_button.selected, sizeof(sem_night_mode_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_night_mode_off_button.selected, sizeof(sem_night_mode_off_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_flash_mode_button.selected, sizeof(sem_flash_mode_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_screen_brightness_bar.selected, sizeof(sem_screen_brightness_bar.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_screen_off_time_bar.selected, sizeof(sem_screen_off_time_bar.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_sleep_time_bar.selected, sizeof(sem_sleep_time_bar.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_800px_mode_button.selected, sizeof(sem_800px_mode_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_3d_mode_button.selected, sizeof(sem_3d_mode_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_400px_mode_button.selected, sizeof(sem_400px_mode_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_auto_mode_button.selected, sizeof(sem_auto_mode_button.selected));

	//Scroll speed.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.scroll_speed, sizeof(sem_config.scroll_speed));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_speed_bar.selected, sizeof(sem_scroll_speed_bar.selected));

	//Font
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_load_all_ex_font_button.selected, sizeof(sem_load_all_ex_font_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_unload_all_ex_font_button.selected, sizeof(sem_unload_all_ex_font_button.selected));
	for(uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
		Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_ex_font_button[i].selected, sizeof(sem_ex_font_button[i].selected));

	//Wireless.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_wifi_on, sizeof(sem_config.is_wifi_on));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_wifi_on_button.selected, sizeof(sem_wifi_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_wifi_off_button.selected, sizeof(sem_wifi_off_button.selected));

	//Advanced settings.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_send_info_allowed, sizeof(sem_config.is_send_info_allowed));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_debug, sizeof(sem_config.is_debug));

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_allow_send_info_button.selected, sizeof(sem_allow_send_info_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_deny_send_info_button.selected, sizeof(sem_deny_send_info_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_debug_mode_on_button.selected, sizeof(sem_debug_mode_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_debug_mode_off_button.selected, sizeof(sem_debug_mode_off_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_use_fake_model_button.selected, sizeof(sem_use_fake_model_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_dump_log_button.selected, sizeof(sem_dump_log_button.selected));

#if DEF_CPU_USAGE_API_ENABLE
	//CPU usage.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_is_cpu_usage_monitor_running, sizeof(sem_is_cpu_usage_monitor_running));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_cpu_usage_on_button.selected, sizeof(sem_monitor_cpu_usage_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_cpu_usage_off_button.selected, sizeof(sem_monitor_cpu_usage_off_button.selected));
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
	//GPU usage.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_is_gpu_usage_monitor_running, sizeof(sem_is_gpu_usage_monitor_running));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_gpu_usage_on_button.selected, sizeof(sem_monitor_gpu_usage_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_gpu_usage_off_button.selected, sizeof(sem_monitor_gpu_usage_off_button.selected));
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
	//NET usage.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_is_net_usage_monitor_running, sizeof(sem_is_net_usage_monitor_running));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_net_usage_on_button.selected, sizeof(sem_monitor_net_usage_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_net_usage_off_button.selected, sizeof(sem_monitor_net_usage_off_button.selected));
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
	//NVS usage.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_is_nvs_usage_monitor_running, sizeof(sem_is_nvs_usage_monitor_running));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_nvs_usage_on_button.selected, sizeof(sem_monitor_nvs_usage_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_nvs_usage_off_button.selected, sizeof(sem_monitor_nvs_usage_off_button.selected));
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
	//RAM usage.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_is_ram_usage_monitor_running, sizeof(sem_is_ram_usage_monitor_running));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_ram_usage_on_button.selected, sizeof(sem_monitor_ram_usage_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_ram_usage_off_button.selected, sizeof(sem_monitor_ram_usage_off_button.selected));
#endif //DEF_RAM_USAGE_API_ENABLE

	//Battery.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_eco, sizeof(sem_config.is_eco));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_eco_mode_on_button.selected, sizeof(sem_eco_mode_on_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_eco_mode_off_button.selected, sizeof(sem_eco_mode_off_button.selected));

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
	//Screen recording.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_record_request, sizeof(sem_record_request));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_stop_record_request, sizeof(sem_stop_record_request));
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_record_both_lcd_button.selected, sizeof(sem_record_both_lcd_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_record_top_lcd_button.selected, sizeof(sem_record_top_lcd_button.selected));
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_record_bottom_lcd_button.selected, sizeof(sem_record_bottom_lcd_button.selected));

	//License.
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_license_this_app_button, sizeof(sem_license_this_app_button));
	for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
		Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &sem_license_buttons[i].selected, sizeof(sem_license_buttons[i].selected));

	DEF_LOG_RESULT_SMART(result, Menu_add_worker_thread_callback(Sem_worker_callback), result, result);

	Sem_resume();
	sem_already_init = true;

	Sem_get_system_info();

	DEF_LOG_STRING("Initialized.");
}

void Sem_draw_init(void)
{
	Util_watch_add(WATCH_HANDLE_SETTINGS_MENU, &Draw_get_bot_ui_button()->selected, sizeof(Draw_get_bot_ui_button()->selected));
	sem_back_button = Draw_get_empty_image();
	sem_scroll_bar = Draw_get_empty_image();
	sem_english_button = Draw_get_empty_image();
	sem_japanese_button = Draw_get_empty_image();
	sem_hungarian_button = Draw_get_empty_image();
	sem_chinese_button = Draw_get_empty_image();
	sem_italian_button = Draw_get_empty_image();
	sem_spanish_button = Draw_get_empty_image();
	sem_romanian_button = Draw_get_empty_image();
	sem_polish_button = Draw_get_empty_image();
	sem_ryukyuan_button = Draw_get_empty_image();
	sem_german_button = Draw_get_empty_image();
	sem_night_mode_on_button = Draw_get_empty_image();
	sem_night_mode_off_button = Draw_get_empty_image();
	sem_flash_mode_button = Draw_get_empty_image();
	sem_screen_brightness_slider = Draw_get_empty_image();
	sem_screen_brightness_bar = Draw_get_empty_image();
	sem_screen_off_time_slider = Draw_get_empty_image();
	sem_screen_off_time_bar = Draw_get_empty_image();
	sem_sleep_time_slider = Draw_get_empty_image();
	sem_sleep_time_bar = Draw_get_empty_image();
	sem_800px_mode_button = Draw_get_empty_image();
	sem_3d_mode_button = Draw_get_empty_image();
	sem_400px_mode_button = Draw_get_empty_image();
	sem_auto_mode_button = Draw_get_empty_image();
	sem_scroll_speed_slider = Draw_get_empty_image();
	sem_scroll_speed_bar = Draw_get_empty_image();
	sem_load_all_ex_font_button = Draw_get_empty_image();
	sem_unload_all_ex_font_button = Draw_get_empty_image();
	sem_wifi_on_button = Draw_get_empty_image();
	sem_wifi_off_button = Draw_get_empty_image();
	sem_allow_send_info_button = Draw_get_empty_image();
	sem_deny_send_info_button = Draw_get_empty_image();
	sem_debug_mode_on_button = Draw_get_empty_image();
	sem_debug_mode_off_button = Draw_get_empty_image();
	sem_eco_mode_on_button = Draw_get_empty_image();
	sem_eco_mode_off_button = Draw_get_empty_image();
	sem_record_both_lcd_button = Draw_get_empty_image();
	sem_record_top_lcd_button = Draw_get_empty_image();
	sem_record_bottom_lcd_button = Draw_get_empty_image();
	sem_use_fake_model_button = Draw_get_empty_image();
	sem_dump_log_button = Draw_get_empty_image();
	sem_license_this_app_button = Draw_get_empty_image();

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
	sem_3dsx_button = Draw_get_empty_image();
	sem_cia_button = Draw_get_empty_image();
	sem_dl_install_button = Draw_get_empty_image();
	sem_close_app_button = Draw_get_empty_image();
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#if DEF_CPU_USAGE_API_ENABLE
	sem_monitor_cpu_usage_on_button = Draw_get_empty_image();
	sem_monitor_cpu_usage_off_button = Draw_get_empty_image();
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
	sem_monitor_gpu_usage_on_button = Draw_get_empty_image();
	sem_monitor_gpu_usage_off_button = Draw_get_empty_image();
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
	sem_monitor_net_usage_on_button = Draw_get_empty_image();
	sem_monitor_net_usage_off_button = Draw_get_empty_image();
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
	sem_monitor_nvs_usage_on_button = Draw_get_empty_image();
	sem_monitor_nvs_usage_off_button = Draw_get_empty_image();
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
	sem_monitor_ram_usage_on_button = Draw_get_empty_image();
	sem_monitor_ram_usage_off_button = Draw_get_empty_image();
#endif //DEF_RAM_USAGE_API_ENABLE

	for(uint32_t i = 0; i < MENU_MAX; i++)
		sem_menu_button[i] = Draw_get_empty_image();
	for(uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
		sem_ex_font_button[i] = Draw_get_empty_image();
	for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
		sem_license_buttons[i] = Draw_get_empty_image();
}

void Sem_exit(void)
{
	DEF_LOG_STRING("Exiting...");
	uint8_t brightness = 0;
	uint32_t result = DEF_ERR_OTHER;
	Str_data data = { 0, };
	Sem_config config = { 0, };
	Sem_state state = { 0, };

	Sem_get_config(&config);
	Sem_get_state(&state);
	Util_str_init(&data);

	brightness = Util_max(config.top_lcd_brightness, config.bottom_lcd_brightness);
	state.num_of_launch++;

	Util_str_format_append(&data, "<0>%s</0>", config.lang);
	Util_str_format_append(&data, "<1>%" PRIu8 "</1>", brightness);
	Util_str_format_append(&data, "<2>%" PRIu16 "</2>", config.time_to_turn_off_lcd);
	Util_str_format_append(&data, "<3>%f</3>", config.scroll_speed);
	Util_str_format_append(&data, "<4>%" PRIu8 "</4>", config.is_send_info_allowed);
	Util_str_format_append(&data, "<5>%" PRIu32 "</5>", state.num_of_launch);
	Util_str_format_append(&data, "<6>%" PRIu8 "</6>", config.is_night);
	Util_str_format_append(&data, "<7>%" PRIu8 "</7>", config.is_eco);
	Util_str_format_append(&data, "<8>%" PRIu8 "</8>", config.is_wifi_on);
	//9 and 10 are no longer used.
	Util_str_format_append(&data, "<9>0</9><10>0</10>");
	Util_str_format_append(&data, "<11>%" PRIu8 "</11>", config.screen_mode);
	Util_str_format_append(&data, "<12>%" PRIu16 "</12>", config.time_to_enter_sleep);

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
	sem_stop_record_request = true;
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

	sem_already_init = false;
	sem_thread_suspend = false;
	sem_thread_run = false;
	Menu_remove_worker_thread_callback(Sem_worker_callback);

	//Save settings.
	DEF_LOG_RESULT_SMART(result, Util_file_save_to_file("settings.txt", DEF_MENU_MAIN_DIR, (uint8_t*)data.buffer, data.length, true), (result == DEF_SUCCESS), result);

	Util_str_free(&data);

	if(sem_internal_state.fake_model < DEF_SEM_MODEL_MAX)
	{
		//Fake mode has been configured, save it.
		DEF_LOG_RESULT_SMART(result, Util_file_save_to_file("fake_model.txt", DEF_MENU_MAIN_DIR, &sem_internal_state.fake_model, 1, true), (result == DEF_SUCCESS), result);
	}
	else
	{
		//Fake model has been turned off, delete the config file.
		DEF_LOG_RESULT_SMART(result, Util_file_delete_file("fake_model.txt", DEF_MENU_MAIN_DIR), (result == DEF_SUCCESS), result);
	}

	//Exit threads.
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
	DEF_LOG_RESULT_SMART(result, threadJoin(sem_update_thread, DEF_THREAD_WAIT_TIME), (result == DEF_SUCCESS), result);
	threadFree(sem_update_thread);
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
	DEF_LOG_RESULT_SMART(result, threadJoin(sem_encode_thread, DEF_THREAD_WAIT_TIME), (result == DEF_SUCCESS), result);
	DEF_LOG_RESULT_SMART(result, threadJoin(sem_record_thread, DEF_THREAD_WAIT_TIME), (result == DEF_SUCCESS), result);
	threadFree(sem_encode_thread);
	threadFree(sem_record_thread);
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

	DEF_LOG_RESULT_SMART(result, threadJoin(sem_hw_config_thread, DEF_THREAD_WAIT_TIME), (result == DEF_SUCCESS), result);
	threadFree(sem_hw_config_thread);

#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
	DEF_LOG_RESULT_SMART(result, threadJoin(sem_check_connectivity_thread, DEF_THREAD_WAIT_TIME), (result == DEF_SUCCESS), result);
	threadFree(sem_check_connectivity_thread);
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)

	for(uint32_t i = 0; i < UPDATE_DATA_MAX; i++)
		Util_str_free(&sem_newest_ver_data[i]);

	//Global.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &Draw_get_bot_ui_button()->selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_y_offset);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_y_min);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_selected_menu_mode);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_mode);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_bar.selected);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_back_button.selected);
	for(uint32_t i = 0; i < MENU_MAX; i++)
		Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_menu_button[i].selected);

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
	//Updater.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_dl_file_request);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_check_update_request);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_selected_edition);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_installed_size);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_dled_size);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_3dsx_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_cia_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_dl_install_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_close_app_button.selected);
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

	//Languages.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_reload_msg_request);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_english_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_japanese_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_hungarian_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_chinese_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_italian_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_spanish_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_romanian_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_polish_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_ryukyuan_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_german_button.selected);

	//LCD.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_night);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_flash);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.top_lcd_brightness);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.bottom_lcd_brightness);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.time_to_turn_off_lcd);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.time_to_enter_sleep);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.screen_mode);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_night_mode_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_night_mode_off_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_flash_mode_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_screen_brightness_bar.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_screen_off_time_bar.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_sleep_time_bar.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_800px_mode_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_3d_mode_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_400px_mode_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_auto_mode_button.selected);

	//Scroll speed.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.scroll_speed);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_scroll_speed_bar.selected);

	//Font.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_load_all_ex_font_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_unload_all_ex_font_button.selected);
	for(uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
		Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_ex_font_button[i].selected);

	//Wireless.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_wifi_on);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_wifi_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_wifi_off_button.selected);

	//Advanced settings.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_send_info_allowed);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_debug);

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_allow_send_info_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_deny_send_info_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_debug_mode_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_debug_mode_off_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_use_fake_model_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_dump_log_button.selected);

#if DEF_CPU_USAGE_API_ENABLE
	//CPU usage.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_is_cpu_usage_monitor_running);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_cpu_usage_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_cpu_usage_off_button.selected);
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
	//GPU usage.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_is_gpu_usage_monitor_running);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_gpu_usage_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_gpu_usage_off_button.selected);
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
	//NET usage.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_is_net_usage_monitor_running);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_net_usage_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_net_usage_off_button.selected);
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
	//NVS usage.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_is_nvs_usage_monitor_running);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_nvs_usage_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_nvs_usage_off_button.selected);
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
	//RAM usage.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_is_ram_usage_monitor_running);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_ram_usage_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_monitor_ram_usage_off_button.selected);
#endif //DEF_RAM_USAGE_API_ENABLE

	//Battery.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_config.is_eco);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_eco_mode_on_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_eco_mode_off_button.selected);

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
	//Screen recording.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_record_request);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_stop_record_request);
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_record_both_lcd_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_record_top_lcd_button.selected);
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_record_bottom_lcd_button.selected);

	//License.
	Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_license_this_app_button.selected);
	for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
		Util_watch_remove(WATCH_HANDLE_SETTINGS_MENU, &sem_license_buttons[i].selected);

	Util_sync_destroy(&sem_config_state_mutex);

	DEF_LOG_STRING("Exited.");
}

void Sem_main(void)
{
	uint32_t color = DEF_DRAW_BLACK;
	uint32_t color_x2[2] = { 0, };
	uint32_t red_x2[2] = { DEF_DRAW_RED, DEF_DRAW_RED, };
	uint32_t weak_color = DEF_DRAW_WEAK_BLACK;
	uint32_t back_color = DEF_DRAW_WHITE;
	Watch_handle_bit watch_handle_bit = (DEF_WATCH_HANDLE_BIT_GLOBAL | DEF_WATCH_HANDLE_BIT_SETTINGS_MENU);
	Sem_config config = { 0, };
	Sem_state state = { 0, };

	if(Util_err_query_show_flag())
		watch_handle_bit |= DEF_WATCH_HANDLE_BIT_ERR;
	if(Util_log_query_show_flag())
		watch_handle_bit |= DEF_WATCH_HANDLE_BIT_LOG;

	Sem_get_config(&config);
	Sem_get_state(&state);

	if (config.is_night)
	{
		color = DEF_DRAW_WHITE;
		weak_color = DEF_DRAW_WEAK_WHITE;
		back_color = DEF_DRAW_BLACK;
	}

	color_x2[0] = color;
	color_x2[1] = color;

	//Check if we should update the screen.
	if(Util_watch_is_changed(watch_handle_bit) || Draw_is_refresh_needed() || !config.is_eco)
	{
		double draw_x = 0;
		double draw_y = 0;
		Str_data format_str = { 0, };

		Draw_set_refresh_needed(false);
		Util_str_init(&format_str);
		Draw_frame_ready();
		Draw_screen_ready(DRAW_SCREEN_TOP_LEFT, back_color);

		if(Util_log_query_show_flag())
			Util_log_draw();

		Draw_top_ui(config.is_eco, state.is_charging, state.wifi_signal, state.battery_level, state.msg);

		if(config.is_debug)
			Draw_debug_info(config.is_night, state.free_ram, state.free_linear_ram);

		if(Util_cpu_usage_query_show_flag())
			Util_cpu_usage_draw();

		if(Util_gpu_usage_query_show_flag())
			Util_gpu_usage_draw();

		if(Util_net_usage_query_show_flag())
			Util_net_usage_draw();

		if(Util_nvs_usage_query_show_flag())
			Util_nvs_usage_draw();

		if(Util_ram_usage_query_show_flag())
			Util_ram_usage_draw();

		Draw_screen_ready(DRAW_SCREEN_BOTTOM, back_color);

		if (sem_selected_menu_mode > MENU_TOP && sem_selected_menu_mode < MENU_MAX)
		{
			draw_y = sem_y_offset;
			if (draw_y >= -30 && draw_y <= 240)
			{
				//Back.
				Draw_with_background(&sem_msg[MSG_BACK], 0.0, draw_y, FONT_SIZE_BACK, color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
				55, 25, DRAW_BACKGROUND_ENTIRE_BOX, &sem_back_button, (sem_back_button.selected ? DEF_DRAW_RED : DEF_DRAW_WEAK_RED));
			}
		}

		//Scroll bar.
		if (sem_y_min < 0)
			Sem_scroll_bar(&sem_scroll_bar, sem_y_offset, sem_y_min);

		if (sem_selected_menu_mode == MENU_TOP)
		{
			draw_x = SUB_MENU_X;
			draw_y = (sem_y_offset + SUB_MENU_Y);

			//Sub menus.
			for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_sub_menus); i++)
			{
				Sem_sub_menu_button(&sem_sub_menus[i], draw_x, draw_y, color);
				draw_y += (SUB_MENU_HEIGHT + SUB_MENU_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - SUB_MENU_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_UPDATE)
		{
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
			draw_x = UPDATER_X;
			draw_y = (sem_y_offset + UPDATER_Y);

			//Prepare additional status message.
			if(sem_update_progress == UPDATE_STATE_DOWNLOADING)
				Util_format_size(sem_dled_size, &format_str);
			else if(sem_update_progress == UPDATE_STATE_INSTALLING)
			{
				double installed_size_mb = (sem_installed_size / 1000.0 / 1000.0);
				double total_size_mb = (sem_total_cia_size / 1000.0 / 1000.0);

				Util_str_format(&format_str, "%.2f%%", (installed_size_mb / total_size_mb));
			}

			//Status.
			Sem_updater_status(sem_update_progress, sem_new_version_available, &format_str, draw_x, draw_y, color);
			if(sem_update_progress == UPDATE_STATE_UPDATE_SUCCESS)
				draw_y += (UPDATER_STATUS_SUCCESS_HEIGHT + UPDATER_SPACE_Y);
			else
				draw_y += (UPDATER_STATUS_HEIGHT + UPDATER_SPACE_Y);

			if(sem_update_progress == UPDATE_STATE_UPDATE_SUCCESS)
			{
				Sem_updater_close_button(&sem_close_app_button, MSG_CLOSE_APP, draw_x, draw_y, color);
				draw_y += (UPDATER_CLOSE_HEIGHT + UPDATER_SPACE_Y);
			}

			if(sem_update_progress == UPDATE_STATE_CHECK_SUCCESS || sem_update_progress == UPDATE_STATE_UPDATE_FAILURE)
			{
				//Edition selection.
				for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_updater_editions); i++)
				{
					Sem_updater_edition_button(&sem_updater_editions[i], sem_selected_edition, draw_x, draw_y, color, weak_color, DEF_DRAW_RED);
					draw_x += (UPDATER_EDITION_WIDTH + UPDATER_EDITION_SPACE_X);
					if((draw_x + UPDATER_EDITION_WIDTH) > UPDATER_X_END)
					{
						draw_x = UPDATER_X;
						draw_y += (UPDATER_EDITION_HEIGHT + UPDATER_SPACE_Y);
					}
				}
				draw_x = UPDATER_X;

				if(sem_selected_edition == EDITION_3DSX)
				{
					Util_str_format(&format_str, "sdmc:" DEF_MENU_MAIN_DIR "ver/%s%s.3dsx", UPDATE_FILE_PREFIX, DEF_STR_NEVER_NULL(&sem_newest_ver_data[UPDATE_DATA_NEWEST_VERSION]));

					Sem_updater_3dsx_path(MSG_FILE_PATH, &format_str, draw_x, draw_y, color);
					draw_y += (UPDATER_3DSX_PATH_HEIGHT + UPDATER_SPACE_Y);
				}

				//Install.
				for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_updater_editions); i++)
				{
					if(sem_updater_editions[i].edition_id == sem_selected_edition && sem_updater_editions[i].is_available)
					{
						Sem_updater_install_button(&sem_dl_install_button, MSG_DL_INSTALL, draw_x, draw_y, color);
						draw_y += (UPDATER_INSTALL_HEIGHT + UPDATER_SPACE_Y);
						break;
					}
				}
			}

			if(sem_update_progress != UPDATE_STATE_CHECK_FAILURE && sem_update_progress != UPDATE_STATE_CHECKING)
			{
				//Patch note.
				Sem_updater_patch_note(&sem_newest_ver_data[UPDATE_DATA_PATCH_NOTE], draw_x, draw_y, color);
				draw_y += (UPDATER_PATCH_NOTE_HEIGHT + UPDATER_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - UPDATER_Y_END), 0);
#else
			Draw_c("☢Updater is disabled\non this app.☢", 10, 25, FONT_SIZE_DISABLED_MSG, DEF_DRAW_RED);
			sem_y_min = 0;
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
		}
		else if (sem_selected_menu_mode == MENU_LANGUAGES)
		{
			draw_x = LANG_X;
			draw_y = (sem_y_offset + LANG_Y);

			//Languages.
			for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_languages); i++)
			{
				Sem_language_button(&sem_languages[i], config.lang, draw_x, draw_y, color, DEF_DRAW_RED);
				draw_y += (LANG_HEIGHT + LANG_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - LANG_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_LCD)
		{
			uint8_t brightness = Util_max(config.top_lcd_brightness, config.bottom_lcd_brightness);
			uint8_t top_mode_index = UINT8_MAX;
			uint32_t top_mode_color[4] = { color, color, color, color, };
			uint32_t top_mode_selected_color[4] = { DEF_DRAW_RED, DEF_DRAW_RED, DEF_DRAW_RED, DEF_DRAW_RED, };
			double bar_value = 0;

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
			if(sem_record_request && config.is_night)
			{
				for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(top_mode_color); i++)
					top_mode_color[i] = DEF_DRAW_WEAK_WHITE;
			}
			else if(sem_record_request)
			{
				for(uint8_t i = 0; i < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(top_mode_color); i++)
					top_mode_color[i] = DEF_DRAW_WEAK_BLACK;
			}
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

			if(state.console_model == DEF_SEM_MODEL_OLD2DS && config.is_night)
			{
				top_mode_color[0] = DEF_DRAW_WEAK_WHITE;
				top_mode_color[1] = DEF_DRAW_WEAK_WHITE;
			}
			else if(state.console_model == DEF_SEM_MODEL_OLD2DS)
			{
				top_mode_color[0] = DEF_DRAW_WEAK_BLACK;
				top_mode_color[1] = DEF_DRAW_WEAK_BLACK;
			}

			if(state.console_model == DEF_SEM_MODEL_NEW2DSXL && config.is_night)
				top_mode_color[1] = DEF_DRAW_WEAK_WHITE;
			else if(state.console_model == DEF_SEM_MODEL_NEW2DSXL)
				top_mode_color[1] = DEF_DRAW_WEAK_BLACK;

			switch(config.screen_mode)
			{
				case DEF_SEM_SCREEN_MODE_800PX:	{ top_mode_index = 0; break; }
				case DEF_SEM_SCREEN_MODE_3D:	{ top_mode_index = 1; break; }
				case DEF_SEM_SCREEN_MODE_400PX:	{ top_mode_index = 2; break; }
				case DEF_SEM_SCREEN_MODE_AUTO:	{ top_mode_index = 3; break; }
			}

			draw_x = LCD_X;
			draw_y = (sem_y_offset + LCD_Y);

			//Night mode.
			Sem_sub_title(&sem_msg[MSG_NIGHT_MODE], draw_x, draw_y, color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LCD_SPACE_Y);

			Sem_select_button_2(&sem_select_night_mode, !config.is_night, draw_x, draw_y,
			color_x2, red_x2, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SELECT_HEIGHT + LCD_SPACE_Y);

			//Flash.
			Sem_select_button_1(&sem_select_flash_mode, sem_config.is_flash, draw_x, draw_y,
			color, DEF_DRAW_RED, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SELECT_HEIGHT + LCD_SPACE_Y);

			//Screen brightness.
			Util_str_format(&format_str, "%s%" PRIu8, DEF_STR_NEVER_NULL(&sem_msg[MSG_BRIGHTNESS]), brightness);
			Sem_sub_title(&format_str, draw_x, draw_y, color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LCD_SPACE_Y);
			//Slider bar.
			Sem_slider_bar(&sem_slider_brightness, 0, 180, brightness, draw_x, draw_y, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SLIDER_BAR_HEIGHT + LCD_SPACE_Y);

			//Time to turn off LCDs.
			if(config.time_to_turn_off_lcd > 0)
			{
				bar_value = config.time_to_turn_off_lcd;
				Util_str_format(&format_str, "%s%" PRIu16, DEF_STR_NEVER_NULL(&sem_msg[MSG_LCD_OFF_TIME_0]), config.time_to_turn_off_lcd);
				Util_str_format_append(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_LCD_OFF_TIME_1]));
			}
			else
			{
				//Never turn off LCD automatically.
				bar_value = 600;
				Util_str_format(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_LCD_OFF_TIME_0]));
				Util_str_format_append(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_OFF]));
			}
			Sem_sub_title(&format_str, draw_x, draw_y, color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LCD_SPACE_Y);
			//Slider bar.
			Sem_slider_bar(&sem_slider_lcd_off_time, 20, 600, bar_value, draw_x, draw_y, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SLIDER_BAR_HEIGHT + LCD_SPACE_Y);

			//Time to enter sleep.
			if(config.time_to_enter_sleep > 0)
			{
				bar_value = config.time_to_enter_sleep;
				Util_str_format(&format_str, "%s%" PRIu16, DEF_STR_NEVER_NULL(&sem_msg[MSG_SLEEP_TIME]), config.time_to_enter_sleep);
				Util_str_format_append(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_LCD_OFF_TIME_1]));//MSG_LCD_OFF_TIME_1 is intentional.
			}
			else
			{
				//Never enter sleep automatically.
				bar_value = 600;
				Util_str_format(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_SLEEP_TIME]));
				Util_str_format_append(&format_str, "%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_OFF]));
			}
			Sem_sub_title(&format_str, draw_x, draw_y, color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LCD_SPACE_Y);
			//Slider bar.
			Sem_slider_bar(&sem_slider_sleep_time, 20, 600, bar_value, draw_x, draw_y, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SLIDER_BAR_HEIGHT + LCD_SPACE_Y);

			//Screen mode.
			Sem_sub_title(&sem_msg[MSG_LCD_MODE], draw_x, draw_y, color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LCD_SPACE_Y);

			Sem_select_button_4(&sem_select_top_mode, top_mode_index, draw_x, draw_y,
			top_mode_color, top_mode_selected_color, LCD_X_START, LCD_X_END, LCD_Y_START, LCD_Y_END);
			draw_y += (SELECT_HEIGHT + LCD_SPACE_Y);

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - LCD_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_CONTROL)
		{
			draw_x = CONTROL_X;
			draw_y = (sem_y_offset + CONTROL_Y);

			//Scroll speed.
			Util_str_format(&format_str, "%s%f", DEF_STR_NEVER_NULL(&sem_msg[MSG_SCROLL_SPEED]), config.scroll_speed);
			Sem_sub_title(&format_str, draw_x, draw_y, color, CONTROL_X_START, CONTROL_X_END, CONTROL_Y_START, CONTROL_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + CONTROL_SPACE_Y);
			//Slider bar.
			Sem_slider_bar(&sem_slider_scroll_speed, 0.05, 2.00, config.scroll_speed, draw_x, draw_y, CONTROL_X_START, CONTROL_X_END, CONTROL_Y_START, CONTROL_Y_END);
			draw_y += (SLIDER_BAR_HEIGHT + CONTROL_SPACE_Y);

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - CONTROL_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_FONT)
		{
			uint32_t load_color[2] = { color, color, };

			draw_x = FONT_X;
			draw_y = (sem_y_offset + FONT_Y);

			if(Exfont_is_unloading_external_font() || Exfont_is_loading_external_font())
			{
				load_color[0] = weak_color;
				load_color[1] = weak_color;
			}

			//Font loading.
			Sem_select_button_2(&sem_select_font_load, false, draw_x, draw_y,
			load_color, load_color, FONT_X_START, FONT_X_END, FONT_Y_START, FONT_Y_END);
			draw_y += (SELECT_HEIGHT + FONT_SPACE_Y);

			for (uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
			{
				uint32_t font_color = color;

				if (Exfont_is_unloading_external_font() || Exfont_is_loading_external_font())
				{
					if (Exfont_is_loaded_external_font(i))
						font_color = DEF_DRAW_WEAK_RED;
					else
						font_color = weak_color;
				}
				else if (Exfont_is_loaded_external_font(i))
					font_color = DEF_DRAW_RED;

				Sem_font_button(&sem_ex_font_button[i], i, font_color, draw_x, draw_y);
				draw_y += (FONT_HEIGHT + FONT_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - FONT_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_WIFI)
		{
			draw_x = WIFI_X;
			draw_y = (sem_y_offset + WIFI_Y);

			//Wi-Fi.
			Sem_sub_title(&sem_msg[MSG_WIFI_MODE], draw_x, draw_y, color, WIFI_X_START, WIFI_X_END, WIFI_Y_START, WIFI_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + WIFI_SPACE_Y);

			Sem_select_button_2(&sem_select_wifi_mode, !config.is_wifi_on, draw_x, draw_y,
			color_x2, red_x2, WIFI_X_START, WIFI_X_END, WIFI_Y_START, WIFI_Y_END);
			draw_y += (SELECT_HEIGHT + WIFI_SPACE_Y);

			//Connected SSID.
			Util_str_format(&format_str, "%s%s", DEF_STR_NEVER_NULL(&sem_msg[MSG_CONNECTED_SSID]), state.connected_wifi);
			Draw(&format_str, draw_x, draw_y, FONT_SIZE_WIRELESS_SSID, color);

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - WIFI_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_ADVANCED)
		{
			uint8_t fake_model_index = (sem_internal_state.fake_model < DEF_SEM_MODEL_MAX ? sem_internal_state.fake_model : DEF_SEM_MODEL_MAX);

			draw_x = ADVANCED_X;
			draw_y = (sem_y_offset + ADVANCED_Y);

			//Allow send app info.
			Sem_sub_title(&sem_msg[MSG_SEND_INFO_MODE], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_send_info_mode, !config.is_send_info_allowed, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);

			//Debug mode.
			Sem_sub_title(&sem_msg[MSG_DEBUG_MODE], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_debug_mode, !config.is_debug, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);

			//Fake model.
			Sem_sub_title(&sem_msg[MSG_FAKE_MODEL], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_FAKE_MODEL_SPACE_Y);

			Sem_select_button_1(&sem_select_fake_mode[fake_model_index], false, draw_x, draw_y,
			color, DEF_DRAW_RED, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_1(&sem_select_log_dump, sem_dump_log_request, draw_x, draw_y,
			color, DEF_DRAW_RED, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);

#if DEF_CPU_USAGE_API_ENABLE
			//CPU usage monitor.
			Sem_sub_title(&sem_msg[MSG_CPU_USAGE_MONITOR], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_cpu_monitor_mode, !sem_is_cpu_usage_monitor_running, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);
#endif //DEF_CPU_USAGE_API_ENABLE

#if DEF_GPU_USAGE_API_ENABLE
			//GPU usage monitor.
			Sem_sub_title(&sem_msg[MSG_GPU_USAGE_MONITOR], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_gpu_monitor_mode, !sem_is_gpu_usage_monitor_running, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);
#endif //DEF_GPU_USAGE_API_ENABLE

#if DEF_NET_USAGE_API_ENABLE
			//NET usage monitor.
			Sem_sub_title(&sem_msg[MSG_NET_USAGE_MONITOR], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_net_monitor_mode, !sem_is_net_usage_monitor_running, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);
#endif //DEF_NET_USAGE_API_ENABLE

#if DEF_NVS_USAGE_API_ENABLE
			//NVS usage monitor.
			Sem_sub_title(&sem_msg[MSG_NVS_USAGE_MONITOR], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_nvs_monitor_mode, !sem_is_nvs_usage_monitor_running, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);
#endif //DEF_NVS_USAGE_API_ENABLE

#if DEF_RAM_USAGE_API_ENABLE
			//RAM usage monitor.
			Sem_sub_title(&sem_msg[MSG_RAM_USAGE_MONITOR], draw_x, draw_y, color, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + ADVANCED_SPACE_Y);

			Sem_select_button_2(&sem_select_ram_monitor_mode, !sem_is_ram_usage_monitor_running, draw_x, draw_y,
			color_x2, red_x2, ADVANCED_X_START, ADVANCED_X_END, ADVANCED_Y_START, ADVANCED_Y_END);
			draw_y += (SELECT_HEIGHT + ADVANCED_SPACE_Y);
#endif //DEF_RAM_USAGE_API_ENABLE

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - ADVANCED_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_BATTERY)
		{
			uint8_t temp_f = ((state.battery_temp * 1.8) + 32);

			draw_x = BATTERY_X;
			draw_y = (sem_y_offset + BATTERY_Y);

			//Eco mode.
			Sem_sub_title(&sem_msg[MSG_ECO_MODE], draw_x, draw_y, color, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + BATTERY_SPACE_Y);

			Sem_select_button_2(&sem_select_eco_mode, !config.is_eco, draw_x, draw_y,
			color_x2, red_x2, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SELECT_HEIGHT + BATTERY_SPACE_Y);

			//Battery level.
			Util_str_format(&format_str, "%s%.2f%%", DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_LEVEL]), state.battery_level);
			Sem_sub_title(&format_str, draw_x, draw_y, color, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + BATTERY_SPACE_Y);

			Sem_info_bar(&sem_bar_battery_level, 0, 100, state.battery_level, draw_x, draw_y, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (INFO_BAR_HEIGHT + BATTERY_SPACE_Y);

			//Battery voltage.
			Util_str_format(&format_str, "%s%.2fV", DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_VOLTAGE]), state.battery_voltage);
			Sem_sub_title(&format_str, draw_x, draw_y, color, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + BATTERY_SPACE_Y);

			Sem_info_bar(&sem_bar_battery_voltage, 3.1, 4.2, state.battery_voltage, draw_x, draw_y, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (INFO_BAR_HEIGHT + BATTERY_SPACE_Y);

			//Battery temperature.
			Util_str_format(&format_str, "%s%" PRIu8 "°C/%" PRIu8 "°F",
			DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_TEMPERATURE]), state.battery_temp, temp_f);
			Sem_sub_title(&format_str, draw_x, draw_y, color, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + BATTERY_SPACE_Y);

			Sem_info_bar(&sem_bar_battery_temperature, 0, 50, state.battery_temp, draw_x, draw_y, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (INFO_BAR_HEIGHT + BATTERY_SPACE_Y);

			//Remaining time.
			if(state.battery_level >= 100)
				Util_str_set(&format_str, DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_FULL]));
			else if(state.battery_remaining < 0)
				Util_str_set(&format_str, DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_REMAINING_CALCULATING]));
			else
			{
				uint8_t hours = (state.battery_remaining / 60);
				uint8_t minutes = ((uint32_t)state.battery_remaining % 60);

				if(state.is_charging)
					Util_str_set(&format_str, DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_REMAINING_CHARGE]));
				else
					Util_str_set(&format_str, DEF_STR_NEVER_NULL(&sem_msg[MSG_BATTERY_REMAINING_DISCHARGE]));

				Util_str_format_append(&format_str, "%02" PRIu16 ":%02" PRIu16, hours, minutes);
			}
			Sem_sub_title(&format_str, draw_x, draw_y, color, BATTERY_X_START, BATTERY_X_END, BATTERY_Y_START, BATTERY_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + BATTERY_SPACE_Y);

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - BATTERY_Y_END), 0);
		}
		else if (sem_selected_menu_mode == MENU_RECORDING)
		{
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
			bool can_record = (config.screen_mode == DEF_SEM_SCREEN_MODE_400PX || config.screen_mode == DEF_SEM_SCREEN_MODE_3D);

			draw_x = RECORDING_X;
			draw_y = (sem_y_offset + RECORDING_Y);

			if(!can_record)
				color = (config.is_night ? DEF_DRAW_WEAK_WHITE : DEF_DRAW_WEAK_BLACK);

			//Record both screen.
			Sem_select_button_1(&sem_select_record_both[sem_record_request], false, draw_x, draw_y,
			color, color, RECORDING_X_START, RECORDING_X_END, RECORDING_Y_START, RECORDING_Y_END);
			draw_y += (SELECT_HEIGHT + RECORDING_SPACE_Y);

			//Record top screen.
			Sem_select_button_1(&sem_select_record_top[sem_record_request], false, draw_x, draw_y,
			color, color, RECORDING_X_START, RECORDING_X_END, RECORDING_Y_START, RECORDING_Y_END);
			draw_y += (SELECT_HEIGHT + RECORDING_SPACE_Y);

			//Record bottom screen.
			Sem_select_button_1(&sem_select_record_bottom[sem_record_request], false, draw_x, draw_y,
			color, color, RECORDING_X_START, RECORDING_X_END, RECORDING_Y_START, RECORDING_Y_END);
			draw_y += (SELECT_HEIGHT + RECORDING_SPACE_Y);

			if(!can_record)
			{
				Draw(&sem_msg[MSG_CANNOT_RECORD], draw_x, draw_y, FONT_SIZE_REC_UNAVAILABLE, DEF_DRAW_RED);
				draw_y += (RECORDING_UNAVAILABLE_HEIGHT + RECORDING_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - RECORDING_Y_END), 0);
#else
			Draw_c("☢Screen recorder is disabled\non this app.☢", 10, 25, FONT_SIZE_DISABLED_MSG, DEF_DRAW_RED);
			sem_y_min = 0;
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
		}
		else if (sem_selected_menu_mode == MENU_LICENSE)
		{
			draw_x = LICENSE_X;
			draw_y = (sem_y_offset + LICENSE_Y);

			//This app.
			Util_str_format(&format_str, "%s v%s", DEF_MENU_CURRENT_APP_NAME_PLAIN, DEF_MENU_CURRENT_APP_VER);
			Sem_sub_title(&format_str, draw_x, draw_y, color, LICENSE_X_START, LICENSE_X_END, LICENSE_Y_START, LICENSE_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LICENSE_SPACE_Y);
			draw_x += LICENSE_SUB_APP_SPACE_X;

			//Sub app.
			Util_str_format(&format_str, "+ %s %s", DEF_VID_NAME_PLAIN, DEF_VID_VER);
			Sem_sub_title(&format_str, draw_x, draw_y, color, LICENSE_X_START, LICENSE_X_END, LICENSE_Y_START, LICENSE_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LICENSE_SPACE_Y);
			Util_str_format(&format_str, "+ %s %s", DEF_FTPD_NAME_PLAIN, DEF_FTPD_VER);
			Sem_sub_title(&format_str, draw_x, draw_y, color, LICENSE_X_START, LICENSE_X_END, LICENSE_Y_START, LICENSE_Y_END);
			draw_y += (SUB_TITLE_HEIGHT + LICENSE_SPACE_Y);
			draw_x -= LICENSE_SUB_APP_SPACE_X;

			//License name.
			Sem_license_button(&sem_license_this_app, draw_x, draw_y, color);
			draw_y += (LICENSE_HEIGHT + LICENSE_SPACE_Y);

			for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
			{
				//Library info.
				Util_str_format(&format_str, "%s v%s", sem_licenses[i].lib_info->name, sem_licenses[i].lib_info->ver);
				Sem_sub_title(&format_str, draw_x, draw_y, color, LICENSE_X_START, LICENSE_X_END, LICENSE_Y_START, LICENSE_Y_END);
				draw_y += (SUB_TITLE_HEIGHT + LICENSE_SPACE_Y);

				//License name.
				Sem_license_button(&sem_licenses[i], draw_x, draw_y, color);
				draw_y += (LICENSE_HEIGHT + LICENSE_SPACE_Y);
			}

			//Update scroll limit.
			sem_y_min = Util_min_d(-(draw_y - sem_y_offset - LICENSE_Y_END), 0);
		}

		if(Util_err_query_show_flag())
			Util_err_draw();

		Draw_bot_ui();

		Draw_apply_draw();
		Util_str_free(&format_str);
	}
	else
		gspWaitForVBlank();
}

void Sem_hid(const Hid_info* key)
{
	Sem_config config = { 0, };
	Sem_state state = { 0, };

	if(!key)
		return;

	if(aptShouldJumpToHome())
		return;

	Sem_get_config(&config);
	Sem_get_state(&state);

	if (Util_err_query_show_flag())
		Util_err_main(key);
	else
	{
		bool is_exfont_busy = (Exfont_is_loading_external_font() || Exfont_is_unloading_external_font());
		bool record_request = false;
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
		const bool is_available[EDITION_MAX] = { sem_is_3dsx_available, sem_is_cia_available, };
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
		bool can_record = (config.screen_mode == DEF_SEM_SCREEN_MODE_400PX || config.screen_mode == DEF_SEM_SCREEN_MODE_3D);

		record_request = sem_record_request;
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

		//Notify user that button is being pressed.
		if(HID_SYSTEM_UI_SEL(*key))
			Draw_get_bot_ui_button()->selected = true;
		else if (sem_selected_menu_mode == MENU_TOP)
		{
			for(uint32_t i = 0; i < MENU_MAX; i++)
			{
				if(HID_SUB_MENU_SEL(*key, i))
					sem_menu_button[i].selected = true;
			}

			if(HID_SCROLL_MODE_SEL(*key))
				sem_scroll_mode = true;
		}
		else if(sem_selected_menu_mode > MENU_TOP && sem_selected_menu_mode < MENU_MAX)
		{
			if (HID_BACK_SEL(*key))
				sem_back_button.selected = true;
			else if(sem_y_min < 0 && HID_SCROLL_BAR_SEL(*key))
				sem_scroll_bar.selected = true;
			else if (sem_selected_menu_mode == MENU_UPDATE)
			{
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
				if(sem_update_progress == UPDATE_STATE_CHECK_SUCCESS || sem_update_progress == UPDATE_STATE_UPDATE_FAILURE)
				{
					if (HID_UPDATE_3DSX_SEL(*key) && sem_is_3dsx_available)
						sem_3dsx_button.selected = true;
					if (HID_UPDATE_CIA_SEL(*key) && sem_is_cia_available)
						sem_cia_button.selected = true;
					if (HID_UPDATE_DL_INSTALL_SEL(*key) && sem_selected_edition != EDITION_NONE && is_available[sem_selected_edition])
						sem_dl_install_button.selected = true;
				}
				else if(sem_update_progress == UPDATE_STATE_UPDATE_SUCCESS)
				{
					if(HID_UPDATE_CLOSE_APP_SEL(*key))
						sem_close_app_button.selected = true;
				}
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
			}
			else if (sem_selected_menu_mode == MENU_LANGUAGES)
			{
				if(!sem_reload_msg_request)
				{
					if(HID_LANG_EN_SEL(*key))
						sem_english_button.selected = true;
					if(HID_LANG_JP_SEL(*key))
						sem_japanese_button.selected = true;
					if(HID_LANG_HU_SEL(*key))
						sem_hungarian_button.selected = true;
					if(HID_LANG_ZHS_SEL(*key))
						sem_chinese_button.selected = true;
					if(HID_LANG_IT_SEL(*key))
						sem_italian_button.selected = true;
					if(HID_LANG_ES_SEL(*key))
						sem_spanish_button.selected = true;
					if(HID_LANG_RO_SEL(*key))
						sem_romanian_button.selected = true;
					if(HID_LANG_PO_SEL(*key))
						sem_polish_button.selected = true;
					if(HID_LANG_RYU_SEL(*key))
						sem_ryukyuan_button.selected = true;
					if(HID_LANG_DE_SEL(*key))
						sem_german_button.selected = true;
				}
			}
			else if (sem_selected_menu_mode == MENU_LCD)
			{
				if(HID_LCD_NIGHT_ON_SEL(*key))
					sem_night_mode_on_button.selected = true;
				if(HID_LCD_NIGHT_OFF_SEL(*key))
					sem_night_mode_off_button.selected = true;
				if(HID_LCD_FLASH_SEL(*key))
					sem_flash_mode_button.selected = true;
				if(HID_LCD_BRIGHTNESS_BAR_SEL(*key))
					sem_screen_brightness_bar.selected = true;
				if(HID_LCD_LCD_OFF_BAR_SEL(*key))
					sem_screen_off_time_bar.selected = true;
				if(HID_LCD_SLEEP_BAR_SEL(*key))
					sem_sleep_time_bar.selected = true;
				if(HID_LCD_800PX_SEL(*key) && !record_request && state.console_model != DEF_SEM_MODEL_OLD2DS)
					sem_800px_mode_button.selected = true;
				if(HID_LCD_3D_SEL(*key) && !record_request && state.console_model != DEF_SEM_MODEL_OLD2DS
				&& state.console_model != DEF_SEM_MODEL_NEW2DSXL)
					sem_3d_mode_button.selected = true;
				if(HID_LCD_400PX_SEL(*key) && !record_request)
					sem_400px_mode_button.selected = true;
				if(HID_LCD_AUTO_SEL(*key) && !record_request)
					sem_auto_mode_button.selected = true;
			}
			else if (sem_selected_menu_mode == MENU_CONTROL)
			{
				if(HID_CTRL_SCROLL_SPEED_BAR_SEL(*key))
					sem_scroll_speed_bar.selected = true;
			}
			else if (sem_selected_menu_mode == MENU_FONT)
			{
				if(HID_FONT_LOAD_ALL_SEL(*key) && !is_exfont_busy)
					sem_load_all_ex_font_button.selected = true;
				if(HID_FONT_UNLOAD_ALL_SEL(*key) && !is_exfont_busy)
					sem_unload_all_ex_font_button.selected = true;

				for (uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
				{
					if (HID_FONT_LOAD_UNLOAD_SEL(*key, i) && !is_exfont_busy)
						sem_ex_font_button[i].selected = true;
				}
			}
			else if (sem_selected_menu_mode == MENU_WIFI)
			{
				if(HID_WIRELESS_WIFI_ON_SEL(*key))
					sem_wifi_on_button.selected = true;
				if(HID_WIRELESS_WIFI_OFF_SEL(*key))
					sem_wifi_off_button.selected = true;
			}
			else if (sem_selected_menu_mode == MENU_ADVANCED)
			{
				if(HID_ADVANCED_SEND_INFO_ON_SEL(*key))
					sem_allow_send_info_button.selected = true;
				if(HID_ADVANCED_SEND_INFO_OFF_SEL(*key))
					sem_deny_send_info_button.selected = true;
				if(HID_ADVANCED_DEBUG_ON_SEL(*key))
					sem_debug_mode_on_button.selected = true;
				if(HID_ADVANCED_DEBUG_OFF_SEL(*key))
					sem_debug_mode_off_button.selected = true;
				if(HID_ADVANCED_FAKE_MODEL_SEL(*key))
					sem_use_fake_model_button.selected = true;
				if(HID_ADVANCED_LOG_DUMP_SEL(*key) && !sem_dump_log_request)
					sem_dump_log_button.selected = true;
#if DEF_CPU_USAGE_API_ENABLE
				if(HID_ADVANCED_CPU_ON_SEL(*key))
					sem_monitor_cpu_usage_on_button.selected = true;
				if(HID_ADVANCED_CPU_OFF_SEL(*key))
					sem_monitor_cpu_usage_off_button.selected = true;
#endif //DEF_CPU_USAGE_API_ENABLE
#if DEF_GPU_USAGE_API_ENABLE
				if(HID_ADVANCED_GPU_ON_SEL(*key))
					sem_monitor_gpu_usage_on_button.selected = true;
				if(HID_ADVANCED_GPU_OFF_SEL(*key))
					sem_monitor_gpu_usage_off_button.selected = true;
#endif //DEF_GPU_USAGE_API_ENABLE
#if DEF_NET_USAGE_API_ENABLE
				if(HID_ADVANCED_NET_ON_SEL(*key))
					sem_monitor_net_usage_on_button.selected = true;
				if(HID_ADVANCED_NET_OFF_SEL(*key))
					sem_monitor_net_usage_off_button.selected = true;
#endif //DEF_NET_USAGE_API_ENABLE
#if DEF_NVS_USAGE_API_ENABLE
				if(HID_ADVANCED_NVS_ON_SEL(*key))
					sem_monitor_nvs_usage_on_button.selected = true;
				if(HID_ADVANCED_NVS_OFF_SEL(*key))
					sem_monitor_nvs_usage_off_button.selected = true;
#endif //DEF_NVS_USAGE_API_ENABLE
#if DEF_RAM_USAGE_API_ENABLE
				if(HID_ADVANCED_RAM_ON_SEL(*key))
					sem_monitor_ram_usage_on_button.selected = true;
				if(HID_ADVANCED_RAM_OFF_SEL(*key))
					sem_monitor_ram_usage_off_button.selected = true;
#endif //DEF_RAM_USAGE_API_ENABLE
			}
			else if (sem_selected_menu_mode == MENU_BATTERY)
			{
				if(HID_BAT_ECO_ON_SEL(*key))
					sem_eco_mode_on_button.selected = true;
				if(HID_BAT_ECO_OFF_SEL(*key))
					sem_eco_mode_off_button.selected = true;
			}
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
			else if (sem_selected_menu_mode == MENU_RECORDING)
			{
				if(HID_REC_BOTH_SEL(*key) && can_record)
					sem_record_both_lcd_button.selected = true;
				if(HID_REC_TOP_SEL(*key) && can_record)
					sem_record_top_lcd_button.selected = true;
				if(HID_REC_BOT_SEL(*key) && can_record)
					sem_record_bottom_lcd_button.selected = true;
			}
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
			else if (sem_selected_menu_mode == MENU_LICENSE)
			{
				if(HID_LICENSE_FULL_SEL(*key))
					sem_license_this_app.button->selected = true;
				for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
				{
					if(HID_LICENSE_LIB_FULL_SEL(*key, i))
						sem_licenses[i].button->selected = true;
				}
			}

			if(HID_SCROLL_MODE_SEL(*key))
				sem_scroll_mode = true;
		}

		//Execute functions if conditions are satisfied.
		if(HID_SYSTEM_UI_CFM(*key))
			Sem_suspend();
		else if(!sem_scroll_mode)
		{
			if (sem_selected_menu_mode == MENU_TOP)
			{
				for(uint32_t i = 0; i < MENU_MAX; i++)
				{
					if(HID_SUB_MENU_CFM(*key, i))
					{
						//Go to selected page.
						sem_y_offset = 0.0;
						sem_selected_menu_mode = (Sem_menu)i;
						if (sem_selected_menu_mode == MENU_UPDATE)
						{
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
							if(sem_update_progress != UPDATE_STATE_CHECKING && sem_update_progress != UPDATE_STATE_DOWNLOADING
							&& sem_update_progress != UPDATE_STATE_INSTALLING)
								sem_check_update_request = true;
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
						}

						//Reset key state on scene change.
						Util_hid_reset_key_state(HID_KEY_BIT_ALL);
						break;
					}
				}
			}
			else if(sem_selected_menu_mode > MENU_TOP && sem_selected_menu_mode < MENU_MAX)
			{
				if (HID_BACK_CFM(*key))
				{
					//Back to top page.
					sem_y_offset = 0.0;
					sem_selected_menu_mode = MENU_TOP;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
				else if (sem_selected_menu_mode == MENU_UPDATE)
				{
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
					if(sem_update_progress == UPDATE_STATE_CHECK_SUCCESS || sem_update_progress == UPDATE_STATE_UPDATE_FAILURE)
					{
						if (HID_UPDATE_3DSX_CFM(*key) && sem_is_3dsx_available)
							sem_selected_edition = EDITION_3DSX;
						else if (HID_UPDATE_CIA_CFM(*key) && sem_is_cia_available)
							sem_selected_edition = EDITION_CIA;
						else if (HID_UPDATE_DL_INSTALL_CFM(*key) && sem_selected_edition != EDITION_NONE && is_available[sem_selected_edition])
							sem_dl_file_request = true;
					}
					else if(sem_update_progress == UPDATE_STATE_UPDATE_SUCCESS)
					{
						if(HID_UPDATE_CLOSE_APP_CFM(*key))
							Menu_set_must_exit_flag(true);
					}
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
				}
				else if (sem_selected_menu_mode == MENU_LANGUAGES)
				{
					if(!sem_reload_msg_request)
					{
						if(HID_LANG_EN_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "en");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_JP_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "jp");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_HU_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "hu");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_ZHS_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "zh-cn");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_IT_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "it");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_ES_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "es");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_RO_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "ro");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_PO_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "pl");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_RYU_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "ryu");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
						else if(HID_LANG_DE_CFM(*key))
						{
							snprintf(config.lang, sizeof(config.lang), "de");
							Sem_set_config(&config);
							sem_reload_msg_request = true;
						}
					}
				}
				else if (sem_selected_menu_mode == MENU_LCD)
				{
					if(HID_LCD_NIGHT_ON_CFM(*key))
					{
						config.is_night = true;
						Sem_set_config(&config);
					}
					else if(HID_LCD_NIGHT_OFF_CFM(*key))
					{
						config.is_night = false;
						Sem_set_config(&config);
					}
					else if(HID_LCD_FLASH_CFM(*key))
					{
						config.is_flash = !config.is_flash;
						Sem_set_config(&config);
					}
					else if(HID_LCD_BRIGHTNESS_BAR_CFM(*key))
					{
						//Update screen brightness.
						int32_t new_brightness = 180 * ((key->touch_x - 15) / 290.0);

						if(new_brightness < 0)
							new_brightness = 0;
						else if(new_brightness > 180)
							new_brightness = 180;

						config.top_lcd_brightness = new_brightness;
						config.bottom_lcd_brightness = new_brightness;
						Sem_set_config(&config);
					}
					else if(HID_LCD_LCD_OFF_BAR_CFM(*key))
					{
						//Update time to turn off LCD.
						uint16_t new_time = (580 * ((key->touch_x - 15) / 290.0)) + 20;

						if(new_time < 20)
							new_time = 20;
						else if(new_time > 600)
							new_time = 0;//Never turn off.

						config.time_to_turn_off_lcd = new_time;
						if(config.time_to_turn_off_lcd > 0 && config.time_to_enter_sleep > 0 && (config.time_to_turn_off_lcd > config.time_to_enter_sleep))
							config.time_to_enter_sleep = config.time_to_turn_off_lcd;

						Sem_set_config(&config);
					}
					else if(HID_LCD_SLEEP_BAR_CFM(*key))
					{
						//Update time enter sleep.
						uint16_t new_time = (580 * ((key->touch_x - 15) / 290.0)) + 20;

						if(new_time < 20)
							new_time = 20;
						else if(new_time > 600)
							new_time = 0;//Never enter sleep.

						config.time_to_enter_sleep = new_time;
						if(config.time_to_enter_sleep > 0 && config.time_to_turn_off_lcd > 0 && (config.time_to_enter_sleep < config.time_to_turn_off_lcd))
							config.time_to_turn_off_lcd = config.time_to_enter_sleep;

						Sem_set_config(&config);
					}
					else if (HID_LCD_800PX_CFM(*key) && !record_request && state.console_model != DEF_SEM_MODEL_OLD2DS)
					{
						config.screen_mode = DEF_SEM_SCREEN_MODE_800PX;
						Sem_set_config(&config);
					}
					else if (HID_LCD_3D_CFM(*key) && !record_request && state.console_model != DEF_SEM_MODEL_OLD2DS
					&& state.console_model != DEF_SEM_MODEL_NEW2DSXL)
					{
						config.screen_mode = DEF_SEM_SCREEN_MODE_3D;
						Sem_set_config(&config);
					}
					else if (HID_LCD_400PX_CFM(*key) && !record_request)
					{
						config.screen_mode = DEF_SEM_SCREEN_MODE_400PX;
						Sem_set_config(&config);
					}
					else if (HID_LCD_AUTO_CFM(*key) && !record_request)
					{
						config.screen_mode = DEF_SEM_SCREEN_MODE_AUTO;
						Sem_set_config(&config);
					}
				}
				else if (sem_selected_menu_mode == MENU_CONTROL)
				{
					if (HID_CTRL_SCROLL_SPEED_BAR_CFM(*key))
					{
						//Update time to turn off LCD.
						double new_speed = (1.95 * ((key->touch_x - 15) / 290.0)) + 0.05;

						if(new_speed < 0.05)
							new_speed = 0.05;
						else if(new_speed > 2)
							new_speed = 2;

						config.scroll_speed = new_speed;
						Sem_set_config(&config);
					}
				}
				else if (sem_selected_menu_mode == MENU_FONT)
				{
					if (HID_FONT_LOAD_ALL_CFM(*key) && !is_exfont_busy)
					{
						for (uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
							Exfont_set_external_font_request_state(i ,true);

						Exfont_request_load_external_font();
					}
					else if (HID_FONT_UNLOAD_ALL_CFM(*key) && !is_exfont_busy)
					{
						for (uint16_t i = 1; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
							Exfont_set_external_font_request_state(i ,false);

						Exfont_request_unload_external_font();
					}
					else
					{
						for (uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
						{
							if (HID_FONT_LOAD_UNLOAD_CFM(*key, i) && !is_exfont_busy)
							{
								if (Exfont_is_loaded_external_font(i))
								{
									if(i != 0)
									{
										Exfont_set_external_font_request_state(i ,false);
										Exfont_request_unload_external_font();
									}
								}
								else
								{
									Exfont_set_external_font_request_state(i ,true);
									Exfont_request_load_external_font();
								}

								break;
							}
						}
					}
				}
				else if (sem_selected_menu_mode == MENU_WIFI)
				{
					if (HID_WIRELESS_WIFI_ON_CFM(*key))
						sem_should_wifi_enabled = true;
					else if (HID_WIRELESS_WIFI_OFF_CFM(*key))
						sem_should_wifi_enabled = false;
				}
				else if (sem_selected_menu_mode == MENU_ADVANCED)
				{
					if (HID_ADVANCED_SEND_INFO_ON_CFM(*key))
					{
						config.is_send_info_allowed = true;
						Sem_set_config(&config);
					}
					else if (HID_ADVANCED_SEND_INFO_OFF_CFM(*key))
					{
						config.is_send_info_allowed = false;
						Sem_set_config(&config);
					}
					else if (HID_ADVANCED_DEBUG_ON_CFM(*key))
					{
						config.is_debug = true;
						Sem_set_config(&config);
					}
					else if (HID_ADVANCED_DEBUG_OFF_CFM(*key))
					{
						config.is_debug = false;
						Sem_set_config(&config);
					}
					else if (HID_ADVANCED_FAKE_MODEL_CFM(*key))
					{
						if(sem_internal_state.fake_model == DEF_SEM_MODEL_MAX)
							sem_internal_state.fake_model = DEF_SEM_MODEL_OLD3DS;
						else if((sem_internal_state.fake_model + 1) >= DEF_SEM_MODEL_MAX)
							sem_internal_state.fake_model = DEF_SEM_MODEL_MAX;//OFF.
						else
							sem_internal_state.fake_model++;

						Draw_set_refresh_needed(true);
					}
					else if(HID_ADVANCED_LOG_DUMP_CFM(*key) && !sem_dump_log_request)
						sem_dump_log_request = true;
#if DEF_CPU_USAGE_API_ENABLE
					else if (HID_ADVANCED_CPU_ON_CFM(*key))
						sem_should_cpu_usage_monitor_running = true;
					else if (HID_ADVANCED_CPU_OFF_CFM(*key))
						sem_should_cpu_usage_monitor_running = false;
#endif //DEF_CPU_USAGE_API_ENABLE
#if DEF_GPU_USAGE_API_ENABLE
					else if (HID_ADVANCED_GPU_ON_CFM(*key))
						sem_should_gpu_usage_monitor_running = true;
					else if (HID_ADVANCED_GPU_OFF_CFM(*key))
						sem_should_gpu_usage_monitor_running = false;
#endif //DEF_GPU_USAGE_API_ENABLE
#if DEF_NET_USAGE_API_ENABLE
					else if (HID_ADVANCED_NET_ON_CFM(*key))
						sem_should_net_usage_monitor_running = true;
					else if (HID_ADVANCED_NET_OFF_CFM(*key))
						sem_should_net_usage_monitor_running = false;
#endif //DEF_NET_USAGE_API_ENABLE
#if DEF_NVS_USAGE_API_ENABLE
					else if (HID_ADVANCED_NVS_ON_CFM(*key))
						sem_should_nvs_usage_monitor_running = true;
					else if (HID_ADVANCED_NVS_OFF_CFM(*key))
						sem_should_nvs_usage_monitor_running = false;
#endif //DEF_NVS_USAGE_API_ENABLE
#if DEF_RAM_USAGE_API_ENABLE
					else if (HID_ADVANCED_RAM_ON_CFM(*key))
						sem_should_ram_usage_monitor_running = true;
					else if (HID_ADVANCED_RAM_OFF_CFM(*key))
						sem_should_ram_usage_monitor_running = false;
#endif //DEF_RAM_USAGE_API_ENABLE
				}
				else if (sem_selected_menu_mode == MENU_BATTERY)
				{
					if (HID_BAT_ECO_ON_CFM(*key))
					{
						config.is_eco = true;
						Sem_set_config(&config);
					}
					else if (HID_BAT_ECO_OFF_CFM(*key))
					{
						config.is_eco = false;
						Sem_set_config(&config);
					}
				}
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
				else if (sem_selected_menu_mode == MENU_RECORDING)
				{
					if (HID_REC_BOTH_CFM(*key) && can_record)
					{
						if(sem_record_request)
							sem_stop_record_request = true;
						else
						{
							sem_selected_recording_mode = RECORD_BOTH;
							sem_record_request = true;
						}
					}
					else if (HID_REC_TOP_CFM(*key) && can_record)
					{
						if(sem_record_request)
							sem_stop_record_request = true;
						else
						{
							sem_selected_recording_mode = RECORD_TOP;
							sem_record_request = true;
						}
					}
					else if (HID_REC_BOT_CFM(*key) && can_record)
					{
						if(sem_record_request)
							sem_stop_record_request = true;
						else
						{
							sem_selected_recording_mode = RECORD_BOTTOM;
							sem_record_request = true;
						}
					}
				}
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
				else if (sem_selected_menu_mode == MENU_LICENSE)
				{
					if(HID_LICENSE_FULL_CFM(*key))
						Sem_open_web(sem_license_this_app.lib_info->full_license_url);
					else
					{
						for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
						{
							if(HID_LICENSE_LIB_FULL_CFM(*key, i))
							{
								Sem_open_web(sem_licenses[i].lib_info->full_license_url);
								break;
							}
						}
					}
				}
			}
		}

		//Scroll.
		if(HID_SCROLL_BAR_CFM(*key))
		{
			double temp = (SCROLL_BAR_Y_END - SCROLL_BAR_Y - (SCROLL_BAR_HEIGHT / 2));

			sem_touch_x_move_left = 0;
			sem_touch_y_move_left = 0;

			sem_y_offset = ((key->touch_y / temp) * sem_y_min);
		}
		else if(DEF_HID_PHY_PR(key->touch) || DEF_HID_PHY_HE(key->touch))
		{
			sem_touch_x_move_left = 0;
			sem_touch_y_move_left = 0;

			if(sem_scroll_mode)
			{
				sem_touch_x_move_left = key->touch_x_move;
				sem_touch_y_move_left = key->touch_y_move;
			}
		}
		else
		{
			sem_touch_x_move_left -= (sem_touch_x_move_left * 0.025);
			sem_touch_y_move_left -= (sem_touch_y_move_left * 0.025);
			if (sem_touch_x_move_left < 0.5 && sem_touch_x_move_left > -0.5)
				sem_touch_x_move_left = 0;
			if (sem_touch_y_move_left < 0.5 && sem_touch_y_move_left > -0.5)
				sem_touch_y_move_left = 0;
		}

		if((sem_touch_y_move_left * config.scroll_speed) != 0)
			sem_y_offset -= (sem_touch_y_move_left * config.scroll_speed);

		if (sem_y_offset >= 0)
			sem_y_offset = 0.0;
		else if (sem_y_offset <= sem_y_min)
			sem_y_offset = sem_y_min;

		//Notify user that button is NOT being pressed anymore.
		if(HID_SCROLL_MODE_DESEL(*key))
			sem_scroll_mode = false;
		if(HID_SCROLL_BAR_DESEL(*key))
			sem_scroll_bar.selected = false;
		if(HID_SYSTEM_UI_DESEL(*key) || sem_scroll_mode)
			Draw_get_bot_ui_button()->selected = false;
		if(HID_SUB_MENU_DESEL(*key) || sem_scroll_mode)
		{
			for(uint32_t i = 0; i < MENU_MAX; i++)
				sem_menu_button[i].selected = false;
		}
		if(HID_BACK_DESEL(*key) || sem_scroll_mode)
			sem_back_button.selected = false;
#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
		if(HID_UPDATE_3DSX_DESEL(*key) || sem_scroll_mode)
			sem_3dsx_button.selected = false;
		if(HID_UPDATE_CIA_DESEL(*key) || sem_scroll_mode)
			sem_cia_button.selected = false;
		if(HID_UPDATE_DL_INSTALL_DESEL(*key) || sem_scroll_mode)
			sem_dl_install_button.selected = false;
		if(HID_UPDATE_CLOSE_APP_DESEL(*key) || sem_scroll_mode)
			sem_close_app_button.selected = false;
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
		if(HID_LANG_EN_DESEL(*key) || sem_scroll_mode)
			sem_english_button.selected = false;
		if(HID_LANG_JP_DESEL(*key) || sem_scroll_mode)
			sem_japanese_button.selected = false;
		if(HID_LANG_HU_DESEL(*key) || sem_scroll_mode)
			sem_hungarian_button.selected = false;
		if(HID_LANG_ZHS_DESEL(*key) || sem_scroll_mode)
			sem_chinese_button.selected = false;
		if(HID_LANG_IT_DESEL(*key) || sem_scroll_mode)
			sem_italian_button.selected = false;
		if(HID_LANG_ES_DESEL(*key) || sem_scroll_mode)
			sem_spanish_button.selected = false;
		if(HID_LANG_RO_DESEL(*key) || sem_scroll_mode)
			sem_romanian_button.selected = false;
		if(HID_LANG_PO_DESEL(*key) || sem_scroll_mode)
			sem_polish_button.selected = false;
		if(HID_LANG_RYU_DESEL(*key) || sem_scroll_mode)
			sem_ryukyuan_button.selected = false;
		if(HID_LANG_DE_DESEL(*key) || sem_scroll_mode)
			sem_german_button.selected = false;
		if(HID_LCD_NIGHT_ON_DESEL(*key) || sem_scroll_mode)
			sem_night_mode_on_button.selected = false;
		if(HID_LCD_NIGHT_OFF_DESEL(*key) || sem_scroll_mode)
			sem_night_mode_off_button.selected = false;
		if(HID_LCD_FLASH_DESEL(*key) || sem_scroll_mode)
			sem_flash_mode_button.selected = false;
		if(HID_LCD_BRIGHTNESS_BAR_DESEL(*key) || sem_scroll_mode)
			sem_screen_brightness_bar.selected = false;
		if(HID_LCD_LCD_OFF_BAR_DESEL(*key) || sem_scroll_mode)
			sem_screen_off_time_bar.selected = false;
		if(HID_LCD_SLEEP_BAR_DESEL(*key) || sem_scroll_mode)
			sem_sleep_time_bar.selected = false;
		if(HID_LCD_800PX_DESEL(*key) || sem_scroll_mode)
			sem_800px_mode_button.selected = false;
		if(HID_LCD_3D_DESEL(*key) || sem_scroll_mode)
			sem_3d_mode_button.selected = false;
		if(HID_LCD_400PX_DESEL(*key) || sem_scroll_mode)
			sem_400px_mode_button.selected = false;
		if(HID_LCD_AUTO_DESEL(*key) || sem_scroll_mode)
			sem_auto_mode_button.selected = false;
		if(HID_CTRL_SCROLL_SPEED_BAR_DESEL(*key) || sem_scroll_mode)
			sem_scroll_speed_bar.selected = false;
		if(HID_FONT_LOAD_ALL_DESEL(*key) || sem_scroll_mode)
			sem_load_all_ex_font_button.selected = false;
		if(HID_FONT_UNLOAD_ALL_DESEL(*key) || sem_scroll_mode)
			sem_unload_all_ex_font_button.selected = false;
		if(HID_FONT_LOAD_UNLOAD_DESEL(*key) || sem_scroll_mode)
		{
			for (uint16_t i = 0; i < DEF_EXFONT_NUM_OF_FONT_NAME; i++)
				sem_ex_font_button[i].selected = false;
		}
		if(HID_WIRELESS_WIFI_ON_DESEL(*key) || sem_scroll_mode)
			sem_wifi_on_button.selected = false;
		if(HID_WIRELESS_WIFI_OFF_DESEL(*key) || sem_scroll_mode)
			sem_wifi_off_button.selected = false;
		if(HID_ADVANCED_SEND_INFO_ON_DESEL(*key) || sem_scroll_mode)
			sem_allow_send_info_button.selected = false;
		if(HID_ADVANCED_SEND_INFO_OFF_DESEL(*key) || sem_scroll_mode)
			sem_deny_send_info_button.selected = false;
		if(HID_ADVANCED_DEBUG_ON_DESEL(*key) || sem_scroll_mode)
			sem_debug_mode_on_button.selected = false;
		if(HID_ADVANCED_DEBUG_OFF_DESEL(*key) || sem_scroll_mode)
			sem_debug_mode_off_button.selected = false;
		if(HID_ADVANCED_FAKE_MODEL_DESEL(*key) || sem_scroll_mode)
			sem_use_fake_model_button.selected = false;
		if(HID_ADVANCED_LOG_DUMP_DESEL(*key) || sem_scroll_mode)
			sem_dump_log_button.selected = false;
#if DEF_CPU_USAGE_API_ENABLE
		if(HID_ADVANCED_CPU_ON_DESEL(*key) || sem_scroll_mode)
			sem_monitor_cpu_usage_on_button.selected = false;
		if(HID_ADVANCED_CPU_OFF_DESEL(*key) || sem_scroll_mode)
			sem_monitor_cpu_usage_off_button.selected = false;
#endif //DEF_CPU_USAGE_API_ENABLE
#if DEF_GPU_USAGE_API_ENABLE
		if(HID_ADVANCED_GPU_ON_DESEL(*key) || sem_scroll_mode)
			sem_monitor_gpu_usage_on_button.selected = false;
		if(HID_ADVANCED_GPU_OFF_DESEL(*key) || sem_scroll_mode)
			sem_monitor_gpu_usage_off_button.selected = false;
#endif //DEF_GPU_USAGE_API_ENABLE
#if DEF_NET_USAGE_API_ENABLE
		if(HID_ADVANCED_NET_ON_DESEL(*key) || sem_scroll_mode)
			sem_monitor_net_usage_on_button.selected = false;
		if(HID_ADVANCED_NET_OFF_DESEL(*key) || sem_scroll_mode)
			sem_monitor_net_usage_off_button.selected = false;
#endif //DEF_NET_USAGE_API_ENABLE
#if DEF_NVS_USAGE_API_ENABLE
		if(HID_ADVANCED_NVS_ON_DESEL(*key) || sem_scroll_mode)
			sem_monitor_nvs_usage_on_button.selected = false;
		if(HID_ADVANCED_NVS_OFF_DESEL(*key) || sem_scroll_mode)
			sem_monitor_nvs_usage_off_button.selected = false;
#endif //DEF_NVS_USAGE_API_ENABLE
#if DEF_RAM_USAGE_API_ENABLE
		if(HID_ADVANCED_RAM_ON_DESEL(*key) || sem_scroll_mode)
			sem_monitor_ram_usage_on_button.selected = false;
		if(HID_ADVANCED_RAM_OFF_DESEL(*key) || sem_scroll_mode)
			sem_monitor_ram_usage_off_button.selected = false;
#endif //DEF_RAM_USAGE_API_ENABLE
		if(HID_BAT_ECO_ON_DESEL(*key) || sem_scroll_mode)
			sem_eco_mode_on_button.selected = false;
		if(HID_BAT_ECO_OFF_DESEL(*key) || sem_scroll_mode)
			sem_eco_mode_off_button.selected = false;
#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
		if(HID_REC_BOTH_DESEL(*key) || sem_scroll_mode)
			sem_record_both_lcd_button.selected = false;
		if(HID_REC_TOP_DESEL(*key) || sem_scroll_mode)
			sem_record_top_lcd_button.selected = false;
		if(HID_REC_BOT_DESEL(*key) || sem_scroll_mode)
			sem_record_bottom_lcd_button.selected = false;
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
		if(HID_LICENSE_LIB_FULL_DESEL(*key) || sem_scroll_mode)
		{
			for(uint8_t i = 0; i < DEF_UTIL_LIB_INFO_COUNT; i++)
				sem_licenses[i].button->selected = false;
		}
		if(HID_LICENSE_FULL_DESEL(*key) || sem_scroll_mode)
			sem_license_this_app.button->selected = false;
	}

	if(Util_log_query_show_flag())
		Util_log_main(key);
}

static void Sem_scroll_bar(Draw_image_data* bar, double current_pos, double min_pos)
{
	uint32_t button_color = (bar->selected ? DEF_DRAW_BLUE : DEF_DRAW_WEAK_BLUE);
	double y = SCROLL_BAR_Y;

	if(min_pos != 0)
		y += ((SCROLL_BAR_Y_END - SCROLL_BAR_HEIGHT) * (current_pos / min_pos));

	Draw_texture(bar, button_color, SCROLL_BAR_X, y, SCROLL_BAR_WIDTH, SCROLL_BAR_HEIGHT);
}

static void Sem_sub_menu_button(const Sem_sub_menu* sub_menu, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, SUB_MENU_WIDTH, SUB_MENU_X_START,
	SUB_MENU_X_END, y, SUB_MENU_HEIGHT, SUB_MENU_Y_START, SUB_MENU_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (sem_menu_button[sub_menu->menu_id].selected ? DEF_DRAW_CYAN : DEF_DRAW_WEAK_CYAN);
		Draw_image_data* button = &sem_menu_button[sub_menu->menu_id];
		Str_data* msg = &sem_msg[sub_menu->msg];

		Draw_with_background(msg, x, y, FONT_SIZE_SUB_MENU, color, DRAW_X_ALIGN_LEFT, DRAW_Y_ALIGN_CENTER,
		SUB_MENU_WIDTH, SUB_MENU_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, button, button_color);
	}
}

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
static void Sem_updater_status(Sem_update_state state, bool is_new_ver_available, const Str_data* additional_text, double x, double y, uint32_t color)
{
	double height = (state == UPDATE_STATE_UPDATE_SUCCESS ? UPDATER_STATUS_SUCCESS_HEIGHT : UPDATER_STATUS_HEIGHT);
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_STATUS_WIDTH,
	UPDATER_X_START, UPDATER_X_END, y, height, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		Str_data msg = { 0, };
		Sem_msg msg_id = MSG_CHECKING_UPDATE;

		Util_str_init(&msg);

		if(state == UPDATE_STATE_CHECKING)
			msg_id = MSG_CHECKING_UPDATE;
		else if(state == UPDATE_STATE_CHECK_FAILURE)
			msg_id = MSG_CHECKING_UPDATE_FAILED;
		else if (state == UPDATE_STATE_CHECK_SUCCESS)
		{
			if(is_new_ver_available)
				msg_id = MSG_NEW_VERSION_AVAILABLE;
			else
				msg_id = MSG_UP_TO_DATE;
		}
		else if(sem_update_progress == UPDATE_STATE_DOWNLOADING)
			msg_id = MSG_DOWNLOADING;
		else if(sem_update_progress == UPDATE_STATE_INSTALLING)
			msg_id = MSG_INSTALLING;
		else if (sem_update_progress == UPDATE_STATE_UPDATE_SUCCESS)
			msg_id = MSG_SUCCESS;
		else if (sem_update_progress == UPDATE_STATE_UPDATE_FAILURE)
			msg_id = MSG_FAILURE;

		Util_str_format(&msg, "%s %s", DEF_STR_NEVER_NULL(&sem_msg[msg_id]), DEF_STR_NEVER_NULL(additional_text));

		Draw(&msg, x, y, FONT_SIZE_UPDATER_STATE, color);
		Util_str_free(&msg);
	}
}

static void Sem_updater_close_button(Draw_image_data* button, Sem_msg msg_id, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_CLOSE_WIDTH, UPDATER_X_START,
	UPDATER_X_END, y, UPDATER_CLOSE_HEIGHT, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (button->selected ? DEF_DRAW_ORANGE : DEF_DRAW_WEAK_ORANGE);
		Str_data* msg = &sem_msg[msg_id];

		Draw_with_background(msg, x, y, FONT_SIZE_UPDATER_CLOSE, color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		UPDATER_CLOSE_WIDTH, UPDATER_CLOSE_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, button, button_color);
	}
}

static void Sem_updater_edition_button(const Sem_updater_edition* edition, Sem_edition selected_edition, double x, double y, uint32_t color, uint32_t disabled_color, uint32_t selected_color)
{
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_EDITION_WIDTH, UPDATER_X_START,
	UPDATER_X_END, y, UPDATER_EDITION_HEIGHT, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (edition->button->selected ? DEF_DRAW_RED : DEF_DRAW_WEAK_RED);
		Str_data* msg = &sem_msg[edition->msg];
		Draw_image_data* button = edition->button;

		if(edition->edition_id == selected_edition)
			color = selected_color;
		else if(!edition->is_available)
			color = disabled_color;

		Draw_with_background(msg, x, y, FONT_SIZE_UPDATER_EDITION, color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		UPDATER_EDITION_WIDTH, UPDATER_EDITION_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, button, button_color);
	}
}

static void Sem_updater_3dsx_path(Sem_msg msg_id, const Str_data* path, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_3DSX_PATH_WIDTH, UPDATER_X_START,
	UPDATER_X_END, y, UPDATER_3DSX_PATH_HEIGHT, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		Str_data* msg = &sem_msg[msg_id];

		Draw(msg, x, y, FONT_SIZE_UPDATER_3DSX_PATH, color);
		Draw(path, x, (y + (UPDATER_3DSX_PATH_HEIGHT / 2)), FONT_SIZE_UPDATER_3DSX_PATH, DEF_DRAW_RED);
	}
}

static void Sem_updater_install_button(Draw_image_data* button, Sem_msg msg_id, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_INSTALL_WIDTH, UPDATER_X_START,
	UPDATER_X_END, y, UPDATER_INSTALL_HEIGHT, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (button->selected ? DEF_DRAW_LIME : DEF_DRAW_WEAK_LIME);
		Str_data* msg = &sem_msg[msg_id];

		Draw_with_background(msg, x, y, FONT_SIZE_UPDATER_INSTALL, color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		UPDATER_INSTALL_WIDTH, UPDATER_INSTALL_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, button, button_color);
	}
}

static void Sem_updater_patch_note(const Str_data* patch_note, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, UPDATER_PATCH_NOTE_WIDTH, UPDATER_X_START,
	UPDATER_X_END, y, UPDATER_PATCH_NOTE_HEIGHT, UPDATER_Y_START, UPDATER_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		Draw_image_data background = Draw_get_empty_image();

		Draw_with_scale(patch_note, x, y, FONT_SIZE_UPDATER_PATCH_NOTE, DEF_DRAW_NORMAL_SCALE_AND_COMPACT,
		color, DRAW_X_ALIGN_LEFT, DRAW_Y_ALIGN_TOP, UPDATER_PATCH_NOTE_WIDTH, UPDATER_PATCH_NOTE_HEIGHT,
		DRAW_BACKGROUND_ENTIRE_BOX_CROP, &background, DEF_DRAW_WEAK_LIME);
	}
}
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)

static void Sem_language_button(const Sem_language* language, const char* current_lang, double x, double y, uint32_t color, uint32_t selected_color)
{
	Draw_visibility visibility = Draw_visibility_check(x, LANG_WIDTH,
	LANG_X_START, LANG_X_END, y, LANG_HEIGHT, LANG_Y_START, LANG_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (language->button->selected ? DEF_DRAW_CYAN : DEF_DRAW_WEAK_CYAN);
		float font_size = FONT_SIZE_LANG;
		Str_data* msg = &sem_msg[language->msg];

		color = ((strcmp(current_lang, language->lang) == 0) ? selected_color : color);
		//Temporal workaround for UI overflow.
		if(strcmp(current_lang, "de") == 0 && strcmp(language->lang, "zh-cn") == 0)
			font_size = FONT_SIZE_LANG_CN_DE_WORKAROUND;

		Draw_with_background(msg, x, y, font_size, color, DRAW_X_ALIGN_LEFT, DRAW_Y_ALIGN_CENTER,
		LANG_WIDTH, LANG_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, language->button, button_color);
	}
}

static void Sem_font_button(Draw_image_data* button, uint8_t index, uint32_t color, double x, double y)
{
	Draw_visibility visibility = Draw_visibility_check(x, FONT_WIDTH,
	FONT_X_START, FONT_X_END, y, FONT_HEIGHT, FONT_Y_START, FONT_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (button->selected ? DEF_DRAW_CYAN : DEF_DRAW_WEAK_CYAN);
		float font_size = FONT_SIZE_FONT_NAME;
		const char* text = Exfont_query_external_font_name(index);

		Draw_with_background_c(text, x, y, font_size, color, DRAW_X_ALIGN_LEFT, DRAW_Y_ALIGN_CENTER,
		FONT_WIDTH, FONT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);
	}
}

static void Sem_license_button(const Sem_license* license, double x, double y, uint32_t color)
{
	Draw_visibility visibility = Draw_visibility_check(x, LICENSE_WIDTH,
	LICENSE_X_START, LICENSE_X_END, y, LICENSE_HEIGHT, LICENSE_Y_START, LICENSE_Y_END);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (license->button->selected ? DEF_DRAW_CYAN : DEF_DRAW_WEAK_CYAN);
		float font_size = FONT_SIZE_LICENSE;
		const char* msg = license->lib_info->license;

		Draw_with_background_c(msg, x, y, font_size, color, DRAW_X_ALIGN_LEFT, DRAW_Y_ALIGN_CENTER,
		LICENSE_WIDTH, LICENSE_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX_CROP, license->button, button_color);
	}
}

static void Sem_sub_title(const Str_data* msg, double x, double y, uint32_t color, double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, SUB_TITLE_WIDTH,
	x_start, x_end, y, SUB_TITLE_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
		Draw(msg, x, y, FONT_SIZE_SUB_TITLE, color);
}

static void Sem_select_button_1(const Sem_select_1* select, bool is_active, double x, double y, uint32_t color,
uint32_t selected_color, double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, SELECT_1_WIDTH, x_start, x_end, y, SELECT_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (select->button->selected ? select->selected_color : select->color);
		uint32_t text_color = (is_active ? selected_color : color);
		Str_data* msg = &sem_msg[select->msg];
		Draw_image_data* button = select->button;

		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_1_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);
	}
}

static void Sem_select_button_2(const Sem_select_2* select, uint8_t active_index, double x, double y, const uint32_t color[2],
const uint32_t selected_color[2], double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, SELECT_2_WIDTH, x_start, x_end, y, SELECT_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (select->left.button->selected ? select->left.selected_color : select->left.color);
		uint32_t text_color = ((active_index == 0) ? selected_color[0] : color[0]);
		Str_data* msg = &sem_msg[select->left.msg];
		Draw_image_data* button = select->left.button;

		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_2_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);

		button_color = (select->right.button->selected ? select->right.selected_color : select->right.color);
		text_color = ((active_index == 1) ? selected_color[1] : color[1]);
		msg = &sem_msg[select->right.msg];
		button = select->right.button;

		x += (SELECT_2_WIDTH + SELECT_2_SPACE_X);
		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_2_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);
	}
}

static void Sem_select_button_4(const Sem_select_4* select, uint8_t active_index, double x, double y, const uint32_t color[4],
const uint32_t selected_color[4], double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, SELECT_4_WIDTH, x_start, x_end, y, SELECT_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		uint32_t button_color = (select->left.button->selected ? select->left.selected_color : select->left.color);
		uint32_t text_color = ((active_index == 0) ? selected_color[0] : color[0]);
		Str_data* msg = &sem_msg[select->left.msg];
		Draw_image_data* button = select->left.button;

		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_4_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);

		button_color = (select->center_left.button->selected ? select->center_left.selected_color : select->center_left.color);
		text_color = ((active_index == 1) ? selected_color[1] : color[1]);
		msg = &sem_msg[select->center_left.msg];
		button = select->center_left.button;

		x += (SELECT_4_WIDTH + SELECT_4_SPACE_X);
		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_4_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);

		button_color = (select->center_right.button->selected ? select->center_right.selected_color : select->center_right.color);
		text_color = ((active_index == 2) ? selected_color[2] : color[2]);
		msg = &sem_msg[select->center_right.msg];
		button = select->center_right.button;

		x += (SELECT_4_WIDTH + SELECT_4_SPACE_X);
		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_4_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);

		button_color = (select->right.button->selected ? select->right.selected_color : select->right.color);
		text_color = ((active_index == 3) ? selected_color[3] : color[3]);
		msg = &sem_msg[select->right.msg];
		button = select->right.button;

		x += (SELECT_4_WIDTH + SELECT_4_SPACE_X);
		Draw_with_background(msg, x, y, FONT_SIZE_SELECT, text_color, DRAW_X_ALIGN_CENTER, DRAW_Y_ALIGN_CENTER,
		SELECT_4_WIDTH, SELECT_HEIGHT, DRAW_BACKGROUND_ENTIRE_BOX, button, button_color);
	}
}

static void Sem_slider_bar(const Sem_slider* slider, double min, double max, double current,
double x, double y, double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, SLIDER_BAR_WIDTH, x_start, x_end, y, SLIDER_BAR_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		double bar_x = 0;
		double slider_y = (y + ((BAR_HEIGHT - SLIDER_HEIGHT) / 2));
		uint32_t bar_color = (slider->bar->selected ? slider->selected_color : slider->color);
		uint32_t color = slider->slider_color;
		Draw_image_data* bar = slider->bar;
		Draw_image_data* slider_ = slider->slider;

		if(current <= min)
			bar_x = x;
		else if(current >= max)
			bar_x = (x + (SLIDER_WIDTH - BAR_WIDTH));
		else
		{
			current -= min;//Convert to range.
			bar_x = (x + ((SLIDER_WIDTH - BAR_WIDTH) * (current / (max - min))));
		}

		Draw_texture(slider_, color, x, slider_y, SLIDER_WIDTH, SLIDER_HEIGHT);
		Draw_texture(bar, bar_color, bar_x, y, BAR_WIDTH, BAR_HEIGHT);
	}
}

static void Sem_info_bar(const Sem_bar* bar, double min, double max, double current,
double x, double y, double x_start, double x_end, double y_start, double y_end)
{
	Draw_visibility visibility = Draw_visibility_check(x, INFO_BAR_WIDTH, x_start, x_end, y, INFO_BAR_HEIGHT, y_start, y_end);

	if(visibility == DRAW_VISIBILITY_FULLY_VISIBLE || visibility == DRAW_VISIBILITY_PARTIALLY_VISIBLE)
	{
		double x_inactive_start = x;
		double x_inactive_end = (x + INFO_BAR_WIDTH);
		double x_active_start = x;
		double x_active_end = (x + INFO_BAR_WIDTH);

		if(current <= min)
			x_inactive_start += 0;
		else if(current >= max)
			x_inactive_start += INFO_BAR_WIDTH;
		else
		{
			current -= min;//Convert to range.
			x_inactive_start += (INFO_BAR_WIDTH * (current / (max - min)));
		}
		y += (INFO_BAR_HEIGHT / 2);

		Draw_line(x_active_start, y, bar->active_color_left, x_active_end, y, bar->active_color_right, INFO_BAR_HEIGHT);
		Draw_line(x_inactive_start, y, bar->color, x_inactive_end, y, bar->color, INFO_BAR_HEIGHT);
	}
}

static double Sem_estimate_battery_time(bool was_charging, bool is_charging, double battery_level)
{
	uint64_t current_ts = osGetTime();

	if(was_charging != is_charging)
	{
		uint16_t data_index = sem_battery_data.index;

		if(data_index == 0)
			data_index = (DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_battery_data.history) - 1);
		else
			data_index--;

		//Charger state has changed, invalidate estimated time.
		sem_battery_data.estimated_time = -1;
		sem_battery_data.history[data_index].level = -1;
	}

	if(current_ts >= (sem_battery_data.timestamp + DEF_UTIL_S_TO_MS(60)))
	{
		uint16_t valid_count = 0;
		uint16_t data_index = 0;
		double start_level = -1;
		double end_level = -1;

		//Update history.
		sem_battery_data.history[sem_battery_data.index].is_charging = is_charging;
		sem_battery_data.history[sem_battery_data.index].level = battery_level;

		sem_battery_data.timestamp += DEF_UTIL_S_TO_MS(60);
		if((sem_battery_data.index + 1) >= DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_battery_data.history))
			sem_battery_data.index = 0;
		else
			sem_battery_data.index++;

		if(sem_battery_data.count < DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_battery_data.history))
			sem_battery_data.count++;

		//Estimate remaining time.
		data_index = sem_battery_data.index;
		for(uint16_t i = 0; i < sem_battery_data.count; i++)
		{
			if(data_index == 0)
				data_index = (DEF_UTIL_ARRAY_NUM_OF_ELEMENTS(sem_battery_data.history) - 1);
			else
				data_index--;

			if(is_charging != sem_battery_data.history[data_index].is_charging || sem_battery_data.history[data_index].level < 0)
				break;

			if(start_level < 0)
				start_level = sem_battery_data.history[data_index].level;

			end_level = sem_battery_data.history[data_index].level;
			valid_count++;
		}

		sem_battery_data.estimated_time = -1;
		if(valid_count > 1)
		{
			double diff = 0;
			double remaining = 0;

			if(start_level >= end_level)//Charging.
			{
				diff = (start_level - end_level);
				remaining = (100 - battery_level);
			}
			else//Discharging.
			{
				diff = (end_level - start_level);
				remaining = battery_level;
			}

			if(diff >= BATTERY_ESTIMATE_MIN_DIFF)
				sem_battery_data.estimated_time = (remaining / (diff / valid_count));
		}
	}

	return sem_battery_data.estimated_time;
}

static void Sem_get_system_info(void)
{
	bool was_charging = false;
	uint8_t is_charging = 0;
    uint8_t temp[4] = { 0, };
	uint32_t result = DEF_ERR_OTHER;
	char ssid[33] = { 0, };
	time_t unix_time = time(NULL);
	const struct tm* time = gmtime(&unix_time);
	Sem_config config = { 0, };
	Sem_state state = { 0, };

	Sem_get_config(&config);
	Sem_get_state(&state);

	was_charging = state.is_charging;
	result = PTMU_GetBatteryChargeState(&is_charging);//Charger state.
	if(result == DEF_SUCCESS)
		state.is_charging = (bool)is_charging;

	//Original: https://github.com/LumaTeam/Luma3DS/blob/v13.4/sysmodules/rosalina/source/menu.c#L224-L237
    result = MCUHWC_ReadRegister(0x0A, temp, sizeof(temp));
	if(result == DEF_SUCCESS)
    {
        state.battery_temp = temp[0];
        state.battery_level = ((temp[1] + (temp[2] / 256.0)) + 0.05);
		state.battery_level = (state.battery_level >= 100 ? 100 : state.battery_level);
        state.battery_voltage = ((0.02 * temp[3]) + 0.005);
    }
	else
	{
		uint8_t ptmu_battery_level = 0;

		result = PTMU_GetBatteryLevel(&ptmu_battery_level);
		if(result == DEF_SUCCESS)
		{
			if (ptmu_battery_level == 0)
				state.battery_level = 0;
			else if (ptmu_battery_level == 1)
				state.battery_level = 5;
			else if (ptmu_battery_level == 2)
				state.battery_level = 10;
			else if (ptmu_battery_level == 3)
				state.battery_level = 30;
			else if (ptmu_battery_level == 4)
				state.battery_level = 60;
			else if (ptmu_battery_level == 5)
				state.battery_level = 100;
		}
	}
	state.battery_remaining = Sem_estimate_battery_time(was_charging, state.is_charging, state.battery_level);

	//Connected SSID.
	memset(state.connected_wifi, 0x00, sizeof(state.connected_wifi));
	result = ACU_GetSSID(ssid);
	if(result == DEF_SUCCESS)
	{
		uint8_t length = Util_min(strlen(ssid), (sizeof(state.connected_wifi) - 1));
		memcpy(state.connected_wifi, ssid, length);
	}

	state.wifi_signal = osGetWifiStrength();
	//Get Wi-Fi state from shared memory #0x1FF81067.
	sem_internal_state.wifi_state = *(uint8_t*)0x1FF81067;
	if(sem_internal_state.wifi_state == 2)
	{
#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
		if (!sem_internal_state.is_connect_test_success)
			state.wifi_signal += 4;//Without Internet access.
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
	}
	else
	{
		state.wifi_signal = DEF_SEM_WIFI_SIGNAL_DISABLED;
		sem_internal_state.is_connect_test_success = false;
	}

	//Get time.
	state.time.years = (time->tm_year + 1900);
	state.time.months = (time->tm_mon + 1);
	state.time.days = time->tm_mday;
	state.time.hours = time->tm_hour;
	state.time.minutes = time->tm_min;
	state.time.seconds = time->tm_sec;

	if (config.is_debug)
	{
		//Check for free RAM.
		state.free_ram = Util_check_free_ram();
		state.free_linear_ram = Util_check_free_linear_space();
	}

	snprintf(state.msg, sizeof(state.msg), "%02" PRIu32 "fps %04" PRIu16 "/%02" PRIu8 "/%02" PRIu8 " %02" PRIu8 ":%02" PRIu8 ":%02" PRIu8 " ",
	(uint32_t)Draw_query_fps(), state.time.years, state.time.months, state.time.days, state.time.hours, state.time.minutes, state.time.seconds);

	Util_sync_lock(&sem_config_state_mutex, UINT64_MAX);
	sem_state = state;
	Util_sync_unlock(&sem_config_state_mutex);
}

static void Sem_open_web(const char* url)
{
	uint16_t size = 0;
	uint8_t* buffer = NULL;

	if(!url)
		return;

	size = (strlen(url) + 1);
	buffer = (uint8_t*)malloc(size);

	if(!buffer)
		return;

	memcpy(buffer, url, (size - 1));
	buffer[size - 1] = 0x00;
	aptLaunchSystemApplet(APPID_WEB, buffer, size, 0);
	free(buffer);
}

static void Sem_worker_callback(void)
{
	if (sem_already_init)
	{
		uint32_t result = DEF_ERR_OTHER;

		if (sem_reload_msg_request)
		{
			Sem_config config = { 0, };

			Sem_get_config(&config);

			//Try to load specified language messages, if it fails
			//(i.e. no translation available), load English messages.
			DEF_LOG_RESULT_SMART(result, Sem_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sem_load_msg("en"), (result == DEF_SUCCESS), result);

			DEF_LOG_RESULT_SMART(result, Menu_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Menu_load_msg("en"), (result == DEF_SUCCESS), result);

#ifdef DEF_VID_ENABLE
			DEF_LOG_RESULT_SMART(result, Vid_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Vid_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_VID_ENABLE

#ifdef DEF_FTPD_ENABLE
			DEF_LOG_RESULT_SMART(result, Ftpd_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Ftpd_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_FTPD_ENABLE

#ifdef DEF_SAPP2_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp2_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp2_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP2_ENABLE

#ifdef DEF_SAPP3_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp3_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp3_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP3_ENABLE

#ifdef DEF_SAPP4_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp4_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp4_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP4_ENABLE

#ifdef DEF_SAPP5_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp5_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp5_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP5_ENABLE

#ifdef DEF_SAPP6_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp6_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp6_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP6_ENABLE

#ifdef DEF_SAPP7_ENABLE
			DEF_LOG_RESULT_SMART(result, Sapp7_load_msg(config.lang), (result == DEF_SUCCESS), result);
			if (result != DEF_SUCCESS)
				DEF_LOG_RESULT_SMART(result, Sapp7_load_msg("en"), (result == DEF_SUCCESS), result);
#endif //DEF_SAPP7_ENABLE

			sem_reload_msg_request = false;
			Draw_set_refresh_needed(true);
		}
#if DEF_CPU_USAGE_API_ENABLE
		else if(sem_is_cpu_usage_monitor_running != sem_should_cpu_usage_monitor_running)
		{
			if(sem_should_cpu_usage_monitor_running)
			{
				DEF_LOG_RESULT_SMART(result, Util_cpu_usage_init(), (result == DEF_SUCCESS), result);
				if(result == DEF_SUCCESS || result == DEF_ERR_ALREADY_INITIALIZED)
				{
					Util_cpu_usage_set_show_flag(true);
					sem_is_cpu_usage_monitor_running = true;
				}
				else
				{
					Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't start CPU usage module!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
					Util_err_set_show_flag(true);
					sem_should_cpu_usage_monitor_running = false;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
			}
			else
			{
				Util_cpu_usage_set_show_flag(false);
				Util_cpu_usage_exit();
				sem_is_cpu_usage_monitor_running = false;
				//Reset key state on scene change.
				Util_hid_reset_key_state(HID_KEY_BIT_ALL);
			}
		}
#endif //DEF_CPU_USAGE_API_ENABLE
#if DEF_GPU_USAGE_API_ENABLE
		else if(sem_is_gpu_usage_monitor_running != sem_should_gpu_usage_monitor_running)
		{
			if(sem_should_gpu_usage_monitor_running)
			{
				DEF_LOG_RESULT_SMART(result, Util_gpu_usage_init(), (result == DEF_SUCCESS), result);
				if(result == DEF_SUCCESS || result == DEF_ERR_ALREADY_INITIALIZED)
				{
					Util_gpu_usage_set_show_flag(true);
					sem_is_gpu_usage_monitor_running = true;
				}
				else
				{
					Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't start GPU usage module!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
					Util_err_set_show_flag(true);
					sem_should_gpu_usage_monitor_running = false;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
			}
			else
			{
				Util_gpu_usage_set_show_flag(false);
				Util_gpu_usage_exit();
				sem_is_gpu_usage_monitor_running = false;
				//Reset key state on scene change.
				Util_hid_reset_key_state(HID_KEY_BIT_ALL);
			}
		}
#endif //DEF_GPU_USAGE_API_ENABLE
#if DEF_NET_USAGE_API_ENABLE
		else if(sem_is_net_usage_monitor_running != sem_should_net_usage_monitor_running)
		{
			if(sem_should_net_usage_monitor_running)
			{
				DEF_LOG_RESULT_SMART(result, Util_net_usage_init(), (result == DEF_SUCCESS), result);
				if(result == DEF_SUCCESS || result == DEF_ERR_ALREADY_INITIALIZED)
				{
					Util_net_usage_set_show_flag(true);
					sem_is_net_usage_monitor_running = true;
				}
				else
				{
					Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't start NET usage module!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
					Util_err_set_show_flag(true);
					sem_should_net_usage_monitor_running = false;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
			}
			else
			{
				Util_net_usage_set_show_flag(false);
				Util_net_usage_exit();
				sem_is_net_usage_monitor_running = false;
				//Reset key state on scene change.
				Util_hid_reset_key_state(HID_KEY_BIT_ALL);
			}
		}
#endif //DEF_NET_USAGE_API_ENABLE
#if DEF_NVS_USAGE_API_ENABLE
		else if(sem_is_nvs_usage_monitor_running != sem_should_nvs_usage_monitor_running)
		{
			if(sem_should_nvs_usage_monitor_running)
			{
				DEF_LOG_RESULT_SMART(result, Util_nvs_usage_init(), (result == DEF_SUCCESS), result);
				if(result == DEF_SUCCESS || result == DEF_ERR_ALREADY_INITIALIZED)
				{
					Util_nvs_usage_set_show_flag(true);
					sem_is_nvs_usage_monitor_running = true;
				}
				else
				{
					Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't start NVS usage module!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
					Util_err_set_show_flag(true);
					sem_should_nvs_usage_monitor_running = false;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
			}
			else
			{
				Util_nvs_usage_set_show_flag(false);
				Util_nvs_usage_exit();
				sem_is_nvs_usage_monitor_running = false;
				//Reset key state on scene change.
				Util_hid_reset_key_state(HID_KEY_BIT_ALL);
			}
		}
#endif //DEF_NVS_USAGE_API_ENABLE
#if DEF_RAM_USAGE_API_ENABLE
		else if(sem_is_ram_usage_monitor_running != sem_should_ram_usage_monitor_running)
		{
			if(sem_should_ram_usage_monitor_running)
			{
				DEF_LOG_RESULT_SMART(result, Util_ram_usage_init(), (result == DEF_SUCCESS), result);
				if(result == DEF_SUCCESS || result == DEF_ERR_ALREADY_INITIALIZED)
				{
					Util_ram_usage_set_show_flag(true);
					sem_is_ram_usage_monitor_running = true;
				}
				else
				{
					Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't start RAM usage module!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
					Util_err_set_show_flag(true);
					sem_should_ram_usage_monitor_running = false;
					//Reset key state on scene change.
					Util_hid_reset_key_state(HID_KEY_BIT_ALL);
				}
			}
			else
			{
				Util_ram_usage_set_show_flag(false);
				Util_ram_usage_exit();
				sem_is_ram_usage_monitor_running = false;
				//Reset key state on scene change.
				Util_hid_reset_key_state(HID_KEY_BIT_ALL);
			}
		}
#endif //DEF_RAM_USAGE_API_ENABLE
		else if(sem_dump_log_request)
		{
			char file_name[64] = { 0, };
			char dir_name[64] = { 0, };
			Sem_state state = { 0, };

			Sem_get_state(&state);

			snprintf(file_name, sizeof(file_name), "%04" PRIu16 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 ".txt",
			state.time.years, state.time.months, state.time.days, state.time.hours, state.time.minutes, state.time.seconds);
			snprintf(dir_name, sizeof(dir_name), "%slogs/", DEF_MENU_MAIN_DIR);

			DEF_LOG_RESULT_SMART(result, Util_log_dump(file_name, dir_name), (result == DEF_SUCCESS), result);
			if(result == DEF_SUCCESS)
				DEF_LOG_FORMAT("Log file was dumped at: %s%s", dir_name, file_name);

			sem_dump_log_request = false;
		}
	}
}

void Sem_hw_config_thread(void* arg)
{
	(void)arg;
	DEF_LOG_STRING("Thread started.");
	uint64_t previous_flash_ts = 0;
	uint64_t previous_system_info_ts = 0;
	uint64_t previous_draw_ts = 0;

	//Waiting for initialization to finish because some APIs (e.g. Sem_get_config()) can't be used if not initialized.
	while(!sem_already_init)
		Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);

	while (sem_thread_run)
	{
		uint32_t result = DEF_ERR_OTHER;
		uint64_t current_ts = osGetTime();
		Sem_config config = { 0, };
		//Reduce stack usage.
		static Hid_info hid_info = { 0, };

		Sem_get_config(&config);
		Util_hid_query_key_state(&hid_info);

		//Check for flash update.
		if((previous_flash_ts + UPDATE_FLASH_INTERVAL_MS) <= current_ts)
		{
			if(config.is_flash)
			{
				config.is_night = !config.is_night;
				Sem_set_config(&config);

				Draw_set_refresh_needed(true);
			}

			//Update timestamp.
			if((previous_flash_ts + (UPDATE_FLASH_INTERVAL_MS * 1.5)) >= current_ts)
				previous_flash_ts += UPDATE_FLASH_INTERVAL_MS;
			else
				previous_flash_ts = current_ts;//We are too late, reset the time base.
		}

		//Check for system info update.
		if((previous_system_info_ts + UPDATE_SYSTEM_INFO_INTERVAL_MS) <= current_ts)
		{
			Sem_get_system_info();

			//Update timestamp.
			if((previous_system_info_ts + (UPDATE_SYSTEM_INFO_INTERVAL_MS * 1.5)) >= current_ts)
				previous_system_info_ts += UPDATE_SYSTEM_INFO_INTERVAL_MS;
			else
				previous_system_info_ts = current_ts;//We are too late, reset the time base.
		}

		//Check for draw update.
		if((previous_draw_ts + UPDATE_DRAW_INTERVAL_MS) <= current_ts)
		{
			//Re-draw screen to update time.
			Draw_set_refresh_needed(true);

			//Update timestamp.
			if((previous_draw_ts + (UPDATE_DRAW_INTERVAL_MS * 1.5)) >= current_ts)
				previous_draw_ts += UPDATE_DRAW_INTERVAL_MS;
			else
				previous_draw_ts = current_ts;//We are too late, reset the time base.
		}

		if(sem_should_wifi_enabled != config.is_wifi_on)
		{
			result = Util_hw_config_set_wifi_state(sem_should_wifi_enabled);
			if(result == DEF_SUCCESS || result == 0xC8A06C0D)//0xC8A06C0D means "already requested state".
			{
				//We need to directly update Wi-Fi state here, otherwise
				//(i.e. with Sem_set_config()) it'll try to send a request again.
				Util_sync_lock(&sem_config_state_mutex, UINT64_MAX);
				sem_config.is_wifi_on = sem_should_wifi_enabled;
				Util_sync_unlock(&sem_config_state_mutex);
			}
			else
				sem_should_wifi_enabled = !sem_should_wifi_enabled;
		}

		//If config.time_to_turn_off_lcd == 0, it means automatic turn off LCD feature has been disabled.
		if(config.time_to_turn_off_lcd > 0 && DEF_UTIL_MS_TO_S(hid_info.afk_time_ms) > config.time_to_turn_off_lcd)
		{
			result = Util_hw_config_set_screen_state(true, true, false);
			if(result != DEF_SUCCESS)
				DEF_LOG_RESULT(Util_hw_config_set_screen_state, false, result);
		}
		else if(config.time_to_turn_off_lcd > 0 && DEF_UTIL_MS_TO_S(hid_info.afk_time_ms) > (uint16_t)(config.time_to_turn_off_lcd - 10))
		{
			result = Util_hw_config_set_screen_brightness(true, true, 10);
			if(result != DEF_SUCCESS)
				DEF_LOG_RESULT(Util_hw_config_set_screen_brightness, false, result);
		}
		else
		{
			result = Util_hw_config_set_screen_state(true, false, config.is_top_lcd_on);
			if(result != DEF_SUCCESS)
				DEF_LOG_RESULT(Util_hw_config_set_screen_state, false, result);

			result = Util_hw_config_set_screen_state(false, true, config.is_bottom_lcd_on);
			if(result != DEF_SUCCESS)
				DEF_LOG_RESULT(Util_hw_config_set_screen_state, false, result);

			if(config.top_lcd_brightness == config.bottom_lcd_brightness)
			{
				result = Util_hw_config_set_screen_brightness(true, true, config.top_lcd_brightness);
				if(result != DEF_SUCCESS)
					DEF_LOG_RESULT(Util_hw_config_set_screen_brightness, false, result);
			}
			else
			{
				result = Util_hw_config_set_screen_brightness(true, false, config.top_lcd_brightness);
				if(result != DEF_SUCCESS)
					DEF_LOG_RESULT(Util_hw_config_set_screen_brightness, false, result);

				result = Util_hw_config_set_screen_brightness(false, true, config.bottom_lcd_brightness);
				if(result != DEF_SUCCESS)
					DEF_LOG_RESULT(Util_hw_config_set_screen_brightness, false, result);
			}
		}

		//If config.time_to_enter_sleep == 0, it means automatic sleep feature has been disabled.
		if(config.time_to_enter_sleep > 0 && DEF_UTIL_MS_TO_S(hid_info.afk_time_ms) > config.time_to_enter_sleep)
		{
			result = Util_hw_config_sleep_system((HW_CONFIG_WAKEUP_BIT_OPEN_SHELL | HW_CONFIG_WAKEUP_BIT_PRESS_HOME_BUTTON));
			if(result == DEF_SUCCESS)
			{
				//We woke up from sleep.
				Util_hid_reset_afk_time();
			}
			else
				DEF_LOG_RESULT(Util_hw_config_sleep_system, false, result);
		}

		Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);
	}

	DEF_LOG_STRING("Thread exit.");
	threadExit(0);
}

#if (DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)
void Sem_encode_thread(void* arg)
{
	(void)arg;
	DEF_LOG_STRING("Thread started.");

	while (sem_thread_run)
	{
		while(sem_record_request)
		{
			if(sem_encode_request)
			{
				uint8_t* yuv420p = NULL;

				sem_wait_request = true;
				sem_encode_request = false;
				yuv420p = (uint8_t*)linearAlloc(sem_rec_width * sem_rec_height * 1.5);
				if(!yuv420p)
					sem_stop_record_request = true;
				else
				{
					uint32_t result = DEF_ERR_OTHER;

					memcpy(yuv420p, sem_yuv420p, sem_rec_width * sem_rec_height * 1.5);

					result = Util_encoder_video_encode(yuv420p, 0);
					if(result != DEF_SUCCESS)
					{
						DEF_LOG_RESULT(Util_encoder_video_encode, false, result);
						break;
					}
				}

				free(yuv420p);
				yuv420p = NULL;
				sem_wait_request = false;
			}
			else
				Util_sleep(1000);
		}

		Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);
	}

	DEF_LOG_STRING("Thread exit.");
	threadExit(0);
}

void Sem_record_thread(void* arg)
{
	(void)arg;
	DEF_LOG_STRING("Thread started.");
	bool new_3ds = false;
	TickCounter counter = { 0, };
	APT_CheckNew3DS(&new_3ds);
	osTickCounterStart(&counter);

	while (sem_thread_run)
	{
		if (sem_record_request)
		{
			uint8_t rec_framerate = 10;
			uint8_t* top_bgr = NULL;
			uint8_t* bot_bgr = NULL;
			uint8_t* both_bgr = NULL;
			uint16_t rec_width = 400;
			uint16_t rec_height = 480;
			uint32_t result = DEF_ERR_OTHER;
			Sem_record mode = 0;
			Str_data path = { 0, };
			Sem_state state = { 0, };

			Sem_get_state(&state);
			Util_str_init(&path);

			if(DEF_SEM_MODEL_IS_NEW(state.console_model))
				APT_SetAppCpuTimeLimit(80);
			else
				APT_SetAppCpuTimeLimit(70);

			mode = sem_selected_recording_mode;
			if(mode == RECORD_BOTH)
			{
				rec_width = 400;
				rec_height = 480;
				if(new_3ds)
					rec_framerate = 15;
				else
					rec_framerate = 5;
			}
			else if(mode == RECORD_TOP)
			{
				rec_width = 400;
				rec_height = 240;
				if(new_3ds)
					rec_framerate = 30;
				else
					rec_framerate = 10;
			}
			else if(mode == RECORD_BOTTOM)
			{
				rec_width = 320;
				rec_height = 240;
				if(new_3ds)
					rec_framerate = 30;
				else
					rec_framerate = 10;
			}
			sem_rec_width = rec_width;
			sem_rec_height = rec_height;
			Util_str_format(&path, DEF_MENU_MAIN_DIR "screen_recording/%04" PRIu16 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 "_%02" PRIu8 ".mp4",
			state.time.years, state.time.months, state.time.days, state.time.hours, state.time.minutes, state.time.seconds);

			DEF_LOG_RESULT_SMART(result, Util_encoder_create_output_file(path.buffer, 0), (result == DEF_SUCCESS), result);
			if(result != DEF_SUCCESS)
				sem_record_request = false;

			DEF_LOG_RESULT_SMART(result, Util_encoder_video_init(MEDIA_V_CODEC_MJPEG, rec_width, rec_height, 1500000, rec_framerate, 0), (result == DEF_SUCCESS), result);
			if(result != DEF_SUCCESS)
				sem_record_request = false;

			DEF_LOG_RESULT_SMART(result, Util_encoder_write_header(0), (result == DEF_SUCCESS), result);
			if(result != DEF_SUCCESS)
				sem_record_request = false;

			sem_yuv420p = (uint8_t*)linearAlloc(rec_width * rec_height * 1.5);
			if(sem_yuv420p == NULL)
				sem_stop_record_request = true;

			Util_str_free(&path);

			while(sem_record_request)
			{
				uint8_t* top_framebuffer = NULL;
				uint8_t* bot_framebuffer = NULL;
				uint16_t width = 0;
				uint16_t height = 0;
				uint32_t new_width = 0;
				uint32_t new_height = 0;
				double time = 0;
				Converter_color_parameters parameters = { 0, };

				if(sem_stop_record_request)
					break;

				osTickCounterUpdate(&counter);

				if(mode == RECORD_BOTH)
				{
					uint32_t offset = (400 * 240 * 3);
					uint32_t bot_bgr_offset = 0;

					top_framebuffer = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &width, &height);
					result = Util_converter_rgb888_rotate_90_degree(top_framebuffer, &top_bgr, width, height, &new_width, &new_height);
					if(result != DEF_SUCCESS)
					{
						DEF_LOG_RESULT(Util_converter_rgb888_rotate_90_degree, false, result);
						break;
					}

					bot_framebuffer = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &width, &height);
					result = Util_converter_rgb888_rotate_90_degree(bot_framebuffer, &bot_bgr, width, height, &new_width, &new_height);
					if(result != DEF_SUCCESS)
					{
						DEF_LOG_RESULT(Util_converter_rgb888_rotate_90_degree, false, result);
						break;
					}

					both_bgr = (uint8_t*)linearAlloc(rec_width * rec_height * 3);
					if(both_bgr == NULL)
						break;

					memcpy(both_bgr, top_bgr, 400 * 240 * 3);
					free(top_bgr);
					top_bgr = NULL;

					for(uint16_t i = 0; i < 240; i++)
					{
						memset(&both_bgr[offset], 0x00, 40 * 3);
						offset += 40 * 3;
						memcpy(&both_bgr[offset], &bot_bgr[bot_bgr_offset], 320 * 3);
						offset += 320 * 3;
						bot_bgr_offset += 320 * 3;
						memset(&both_bgr[offset], 0x00, 40 * 3);
						offset += 40 * 3;
					}
					free(bot_bgr);
					bot_bgr = NULL;
				}
				else if(mode == RECORD_TOP)
				{
					top_framebuffer = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &width, &height);
					result = Util_converter_rgb888_rotate_90_degree(top_framebuffer, &both_bgr, width, height, &new_width, &new_height);
					if(result != DEF_SUCCESS)
					{
						DEF_LOG_RESULT(Util_converter_rgb888_rotate_90_degree, false, result);
						break;
					}
				}
				else if(mode == RECORD_BOTTOM)
				{
					bot_framebuffer = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &width, &height);
					result = Util_converter_rgb888_rotate_90_degree(bot_framebuffer, &both_bgr, width, height, &new_width, &new_height);
					if(result != DEF_SUCCESS)
					{
						DEF_LOG_RESULT(Util_converter_rgb888_rotate_90_degree, false, result);
						break;
					}
				}

				parameters.converted = NULL;
				parameters.in_color_format = RAW_PIXEL_BGR888;
				parameters.in_height = rec_height;
				parameters.in_width = rec_width;
				parameters.out_color_format = RAW_PIXEL_YUV420P;
				parameters.out_height = rec_height;
				parameters.out_width = rec_width;
				parameters.source = both_bgr;

				result = Util_converter_convert_color(&parameters);
				free(both_bgr);
				both_bgr = NULL;
				if(result != DEF_SUCCESS)
				{
					DEF_LOG_RESULT(Util_converter_convert_color, false, result);
					break;
				}
				memcpy(sem_yuv420p, parameters.converted, rec_width * rec_height * 1.5);
				free(parameters.converted);
				parameters.converted = NULL;

				sem_encode_request = true;
				osTickCounterUpdate(&counter);
				time = osTickCounterRead(&counter);
				if(1000.0 / rec_framerate > time)
					Util_sleep(((1000.0 / rec_framerate) - time) * 1000);
			}

			while(sem_wait_request)
				Util_sleep(100000);

			Util_encoder_close_output_file(0);
			free(both_bgr);
			free(bot_bgr);
			free(top_bgr);
			free(sem_yuv420p);
			both_bgr = NULL;
			bot_bgr = NULL;
			top_bgr = NULL;
			sem_yuv420p = NULL;
			sem_record_request = false;
			sem_stop_record_request = false;
			Draw_set_refresh_needed(true);
			APT_SetAppCpuTimeLimit(30);
		}
		else
			Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);
	}

	DEF_LOG_STRING("Thread exit.");
	threadExit(0);
}
#endif //(DEF_ENCODER_VIDEO_AUDIO_API_ENABLE && DEF_CONVERTER_SW_API_ENABLE && DEF_SEM_ENABLE_SCREEN_RECORDER)

#if (DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)
void Sem_check_connectivity_thread(void* arg)
{
	(void)arg;
	DEF_LOG_STRING("Thread started.");
	uint32_t count = (CHECK_INTERNET_INTERVAL_MS / DEF_UTIL_US_TO_MS(DEF_THREAD_ACTIVE_SLEEP_TIME));

	while (sem_thread_run)
	{
		if (count >= (CHECK_INTERNET_INTERVAL_MS / DEF_UTIL_US_TO_MS(DEF_THREAD_ACTIVE_SLEEP_TIME)))
		{
			Sem_state state = { 0, };

			Sem_get_state(&state);
			count = 0;

			if(state.wifi_signal != DEF_SEM_WIFI_SIGNAL_DISABLED)
			{
				uint32_t dl_size = 0;
				uint32_t result = DEF_ERR_OTHER;
				Net_dl_parameters dl_parameters = { 0, };

				dl_parameters.url = CHECK_INTERNET_URL;
				dl_parameters.max_redirect = 0;
				dl_parameters.max_size = 0x1000;
				dl_parameters.downloaded_size = &dl_size;

#if DEF_HTTPC_API_ENABLE//Curl uses more CPU so prefer to use httpc module here.
				result = Util_httpc_dl_data(&dl_parameters);
#else
				result = Util_curl_dl_data(&dl_parameters);
#endif //DEF_HTTPC_API_ENABLE

				if(result == DEF_SUCCESS && (dl_size - 1) == strlen(CHECK_INTERNET_SUCCESS_TEXT)
				&& strncmp((char*)dl_parameters.data, CHECK_INTERNET_SUCCESS_TEXT, (dl_size - 1)) == 0)
					sem_internal_state.is_connect_test_success = true;
				else
					sem_internal_state.is_connect_test_success = false;

				free(dl_parameters.data);
				dl_parameters.data = NULL;
			}
			else
				sem_internal_state.is_connect_test_success = false;//Wi-Fi is disabled.
		}
		else
			Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);

		count++;
	}

	DEF_LOG_STRING("Thread exit.");
	threadExit(0);
}
#endif //(DEF_CURL_API_ENABLE || DEF_HTTPC_API_ENABLE)

#if (DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
void Sem_update_thread(void* arg)
{
	(void)arg;
	DEF_LOG_STRING("Thread started.");

	while (sem_thread_run)
	{
		if (sem_check_update_request || sem_dl_file_request)
		{
			uint8_t* buffer = NULL;
			uint32_t result = DEF_ERR_OTHER;
			Str_data dir_path = { 0, };
			Str_data filename = { 0, };
			Str_data url = { 0, };

			sem_dled_size = 0;
			sem_installed_size = 0;
			sem_total_cia_size = 0;
			Util_str_init(&url);
			Util_str_init(&dir_path);
			Util_str_init(&filename);

			if (sem_check_update_request)
			{
				sem_update_progress = UPDATE_STATE_CHECKING;
				sem_selected_edition = EDITION_NONE;
				Util_str_set(&url, DEF_SEM_CHECK_UPDATE_URL);
				sem_new_version_available = false;
				for (uint32_t i = 0; i < UPDATE_DATA_MAX; i++)
					Util_str_clear(&sem_newest_ver_data[i]);
			}
			else if (sem_dl_file_request)
			{
				sem_update_progress = UPDATE_STATE_DOWNLOADING;
				Util_str_set(&url, DEF_STR_NEVER_NULL(&sem_newest_ver_data[UPDATE_DATA_URL_BASE + sem_selected_edition]));
			}
			Draw_set_refresh_needed(true);

			if(sem_dl_file_request)
			{
				Util_str_set(&dir_path, DEF_MENU_MAIN_DIR "ver/");

				Util_str_format(&filename, UPDATE_FILE_PREFIX "%s.", DEF_STR_NEVER_NULL(&sem_newest_ver_data[UPDATE_DATA_NEWEST_VERSION]));
				if(sem_selected_edition == EDITION_3DSX)
					Util_str_format_append(&filename, "3dsx");
				else if(sem_selected_edition == EDITION_CIA)
					Util_str_format_append(&filename, "cia");

				Util_file_delete_file(filename.buffer, dir_path.buffer);//Delete old file if exist.
			}

			if(sem_dl_file_request)
			{
				Net_save_parameters save_parameters = { 0, };

				save_parameters.url = url.buffer;
				save_parameters.dir_path = dir_path.buffer;
				save_parameters.filename = filename.buffer;
				save_parameters.max_redirect = 5;
				save_parameters.buffer_size = 0x20000;
				save_parameters.downloaded_size = &sem_dled_size;

				DEF_LOG_RESULT_SMART(result, Util_curl_save_data(&save_parameters), (result == DEF_SUCCESS), result);
			}
			else
			{
				Net_dl_parameters dl_parameters = { 0, };

				dl_parameters.url = url.buffer;
				dl_parameters.max_redirect = 5;
				dl_parameters.max_size = 0x20000;
				dl_parameters.downloaded_size = &sem_dled_size;

				DEF_LOG_RESULT_SMART(result, Util_curl_dl_data(&dl_parameters), (result == DEF_SUCCESS), result);

				buffer = dl_parameters.data;
			}

			Util_str_free(&url);

			if (result != DEF_SUCCESS)
			{
				Util_err_set_error_message(Util_err_get_error_msg(result), "Couldn't download the data!!!!!", DEF_LOG_GET_FUNCTION_NAME(), result);
				Util_err_set_show_flag(true);
				if (sem_check_update_request)
					sem_update_progress = UPDATE_STATE_CHECK_FAILURE;
				else if (sem_dl_file_request)
					sem_update_progress = UPDATE_STATE_UPDATE_FAILURE;

				Draw_set_refresh_needed(true);
			}
			else
			{
				if (sem_check_update_request && buffer)
				{
					const char* parse_start[6] = {"<newest>", "<3dsx_available>", "<cia_available>", "<3dsx_url>", "<cia_url>", "<patch_note>", };
					const char* parse_end[6] = { "</newest>", "</3dsx_available>", "</cia_available>", "</3dsx_url>", "</cia_url>", "</patch_note>", };

					for (uint32_t i = 0; i < UPDATE_DATA_MAX; i++)
					{
						bool is_error = true;
						const char* start_pos = strstr((char*)buffer, parse_start[i]);
						const char* end_pos = strstr((char*)buffer, parse_end[i]);

						if(start_pos && end_pos)
						{
							uint32_t size = 0;

							start_pos += strlen(parse_start[i]);
							size = (end_pos - start_pos);
							if(end_pos > start_pos && size < 16384)
							{
								//We can't get rid of this "int" because "*" specifier expects "int".
								Util_str_format(&sem_newest_ver_data[i], "%.*s", (int)size, start_pos);
								is_error = false;
							}
						}

						if(is_error)
						{
							sem_update_progress = UPDATE_STATE_CHECK_FAILURE;
							break;
						}
					}

					if(sem_update_progress != UPDATE_STATE_CHECK_FAILURE)
					{
						if (DEF_MENU_CURRENT_APP_VER_INT < (uint32_t)strtoul(DEF_STR_NEVER_NULL(&sem_newest_ver_data[UPDATE_DATA_NEWEST_VERSION]), NULL, 10))
							sem_new_version_available = true;
						else
							sem_new_version_available = false;

						sem_is_3dsx_available = Util_str_is_same_c(&sem_newest_ver_data[UPDATE_DATA_3DSX_AVAILABLE], "1");
						sem_is_cia_available = Util_str_is_same_c(&sem_newest_ver_data[UPDATE_DATA_CIA_AVAILABLE], "1");

						if(envIsHomebrew() && sem_is_3dsx_available)
							sem_selected_edition = EDITION_3DSX;
						else if(sem_is_cia_available)
							sem_selected_edition = EDITION_CIA;
					}

					sem_update_progress = UPDATE_STATE_CHECK_SUCCESS;
					Draw_set_refresh_needed(true);
				}
				else if (sem_dl_file_request)
				{
					sem_update_progress = UPDATE_STATE_INSTALLING;
					if (sem_selected_edition == EDITION_3DSX)
						sem_update_progress = UPDATE_STATE_UPDATE_SUCCESS;

					Draw_set_refresh_needed(true);
					if (sem_selected_edition == EDITION_CIA)
					{
						uint64_t offset = 0;
						Handle am_handle = 0;

						sem_total_cia_size = sem_dled_size;
						DEF_LOG_RESULT_SMART(result, AM_StartCiaInstall(MEDIATYPE_SD, &am_handle), (result == DEF_SUCCESS), result);

						while (true)
						{
							uint32_t write_size = 0;
							uint32_t read_size = 0;

							free(buffer);
							buffer = NULL;

							DEF_LOG_RESULT_SMART(result, Util_file_load_from_file(filename.buffer, dir_path.buffer, &buffer, 0x20000, offset, &read_size), (result == DEF_SUCCESS), result);
							if(result != DEF_SUCCESS || read_size == 0)
								break;

							DEF_LOG_RESULT_SMART(result, FSFILE_Write(am_handle, &write_size, offset, buffer, read_size, FS_WRITE_FLUSH), (result == DEF_SUCCESS), result);
							if(result != DEF_SUCCESS)
								break;

							offset += write_size;
							sem_installed_size += write_size;
						}

						DEF_LOG_RESULT_SMART(result, AM_FinishCiaInstall(am_handle), (result == DEF_SUCCESS), result);
						if (result == DEF_SUCCESS)
							sem_update_progress = UPDATE_STATE_UPDATE_SUCCESS;
						else
							sem_update_progress = UPDATE_STATE_UPDATE_FAILURE;

						Draw_set_refresh_needed(true);
					}
				}
			}

			Util_str_free(&dir_path);
			Util_str_free(&filename);

			free(buffer);
			buffer = NULL;
			if(sem_check_update_request)
				sem_check_update_request = false;
			else if(sem_dl_file_request)
				sem_dl_file_request = false;
		}
		else
			Util_sleep(DEF_THREAD_ACTIVE_SLEEP_TIME);

		while (sem_thread_suspend)
			Util_sleep(DEF_THREAD_INACTIVE_SLEEP_TIME);
	}
	DEF_LOG_STRING("Thread exit.");
	threadExit(0);
}
#endif //(DEF_CURL_API_ENABLE && DEF_SEM_ENABLE_UPDATER)
